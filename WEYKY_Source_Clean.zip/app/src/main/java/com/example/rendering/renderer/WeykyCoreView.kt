package com.example.rendering.renderer

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.rendering.visual_state.CoreVisualState
import kotlin.math.cos
import kotlin.math.sin

/**
 * Central WEYKY Core Renderer ("Living Luminous Energy Sphere").
 * Features rich, multi-layered procedural 2D shader-like rendering that reacts fluidly to:
 * 1. User Speech & Microphone Input (`isVoiceListening` + `voiceEnergyLevel`)
 * 2. WEYKY Assistant Speech (`isSpeakingAloud` / `RESPONDING`)
 * 3. External Media & Music Playback (`isMusicPlaying` / `MUSIC`)
 * 4. Battery charging and energy absorption
 */
@Composable
fun WeykyCoreView(
  visualState: CoreVisualState,
  modifier: Modifier = Modifier,
  sizeDp: Dp,
  isPowerSaving: Boolean = false,
  isVoiceListening: Boolean = false,
  isSpeakingAloud: Boolean = false,
  isMusicPlaying: Boolean = false,
  isCharging: Boolean = false,
  batteryPercentage: Int = 100,
  voiceEnergyLevel: Float = 0f,
  onClick: () -> Unit = {}
) {
  val effectiveSpeed = visualState.speedMultiplier *
    (if (isVoiceListening || isSpeakingAloud) 1.35f else if (isMusicPlaying) 1.2f else if (isCharging) 1.15f else 1.0f) *
    (if (isPowerSaving) 0.52f else 1.0f)

  val smoothedSpeed by animateFloatAsState(
    targetValue = effectiveSpeed,
    animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
    label = "SmoothedCoreSpeed"
  )

  var continuousTimeSec by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(Unit) {
    var lastFrameMs = -1L
    while (true) {
      withInfiniteAnimationFrameMillis { frameMs ->
        if (lastFrameMs >= 0L) {
          val dtSec = ((frameMs - lastFrameMs).coerceIn(0L, 64L)) / 1000f
          continuousTimeSec += dtSec * smoothedSpeed
        }
        lastFrameMs = frameMs
      }
    }
  }

  val driftPhase = continuousTimeSec * 0.85f
  val breathPhase = continuousTimeSec * 0.618034f
  val musicColorPhase = continuousTimeSec * 0.78f
  val pulsePhase = continuousTimeSec * 3.6f
  val wavePhase = continuousTimeSec * 5.8f

  val smoothedVoiceEnergy by animateFloatAsState(
    targetValue = if (isVoiceListening) voiceEnergyLevel.coerceIn(0.08f, 1f) else 0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioLowBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "SmoothedVoiceEnergy"
  )

  val speakingPresence by animateFloatAsState(
    targetValue = if (isSpeakingAloud || visualState == CoreVisualState.RESPONDING) 1f else 0f,
    animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
    label = "SpeakingPresence"
  )

  val listeningPresence by animateFloatAsState(
    targetValue = if (isVoiceListening || visualState == CoreVisualState.LISTENING) 1f else 0f,
    animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
    label = "ListeningPresence"
  )

  val musicPresence by animateFloatAsState(
    targetValue = if (isMusicPlaying || visualState == CoreVisualState.MUSIC) 1f else 0f,
    animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
    label = "MusicPresence"
  )

  val chargingPresence by animateFloatAsState(
    targetValue = if (isCharging || visualState == CoreVisualState.CHARGING) 1f else 0f,
    animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
    label = "ChargingPresence"
  )

  val normalizedBatteryLevel by animateFloatAsState(
    targetValue = (batteryPercentage.coerceIn(0, 100) / 100f),
    animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
    label = "NormalizedBatteryLevel"
  )

  val musicColorNorm = (musicColorPhase / (2 * Math.PI).toFloat()) % 1.0f
  val isIdleOrChargingState = (visualState == CoreVisualState.IDLE || visualState == CoreVisualState.CHARGING) &&
    !isVoiceListening && !isSpeakingAloud && !isMusicPlaying

  val targetPrimary = when {
    visualState == CoreVisualState.MUSIC || (isMusicPlaying && !isVoiceListening && !isSpeakingAloud) ->
      getDynamicMusicColor(musicColorNorm)
    isCharging && isIdleOrChargingState ->
      getDynamicChargingColor(normalizedBatteryLevel, driftPhase, 0f)
    else ->
      visualState.primaryColor
  }

  val targetSecondary = when {
    visualState == CoreVisualState.MUSIC || (isMusicPlaying && !isVoiceListening && !isSpeakingAloud) ->
      getDynamicMusicColor(musicColorNorm + 0.28f)
    isCharging && isIdleOrChargingState ->
      getDynamicChargingColor(normalizedBatteryLevel, driftPhase, 0.33f)
    else ->
      visualState.secondaryColor
  }

  val targetAccent = when {
    visualState == CoreVisualState.MUSIC || (isMusicPlaying && !isVoiceListening && !isSpeakingAloud) ->
      getDynamicMusicColor(musicColorNorm + 0.58f)
    isCharging && isIdleOrChargingState ->
      getDynamicChargingColor(normalizedBatteryLevel, driftPhase, 0.66f)
    else ->
      visualState.accentColor
  }

  val animatedPrimary by animateColorAsState(
    targetValue = targetPrimary,
    animationSpec = tween(durationMillis = 450),
    label = "CorePrimaryColor"
  )

  val animatedSecondary by animateColorAsState(
    targetValue = targetSecondary,
    animationSpec = tween(durationMillis = 450),
    label = "CoreSecondaryColor"
  )

  val animatedAccent by animateColorAsState(
    targetValue = targetAccent,
    animationSpec = tween(durationMillis = 450),
    label = "CoreAccentColor"
  )

  val circlePath = remember { Path() }
  val liquidFillPath = remember { Path() }
  val dropletPath = remember { Path() }
  val density = LocalDensity.current
  val configuration = LocalConfiguration.current
  val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }
  var canvasRootTopY by remember { mutableFloatStateOf(-1f) }

  Box(
    modifier = modifier
      .size(sizeDp)
      .onGloballyPositioned { coordinates ->
        canvasRootTopY = coordinates.positionInRoot().y
      }
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
      )
      .testTag("weyky_core_view"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(sizeDp)) {
      val w = size.width
      val h = size.height
      val minDim = minOf(w, h)
      val baseRadius = (minDim / 2f) * 0.86f
      val center = Offset(w / 2f, h / 2f)

      val bassBeat = ((sin(pulsePhase.toDouble()) + 1.0) * 0.5).toFloat()
      val midGroove = sin((pulsePhase * 2.0f + 0.8f).toDouble()).toFloat() * 0.4f
      val highShimmer = cos((wavePhase * 2.0f).toDouble()).toFloat() * 0.25f
      val musicBeatEnergy = ((bassBeat * 0.65f + (midGroove + 0.4f) * 0.35f + highShimmer * 0.2f)).coerceIn(0f, 1f)

      val syllable1 = ((sin(wavePhase.toDouble() * 2.0) + 1.0) * 0.5).toFloat()
      val syllable2 = ((cos(pulsePhase.toDouble() * 3.0 + 1.3) + 1.0) * 0.5).toFloat()
      val speechCadenceEnergy = (syllable1 * 0.65f + syllable2 * 0.35f).coerceIn(0.15f, 1f)

      val micLiveEnergy = (smoothedVoiceEnergy * 0.82f + syllable1 * 0.25f * listeningPresence).coerceIn(0f, 1f)
      val chargeSurge = ((sin((pulsePhase * 0.75f).toDouble()) + 1.0) * 0.5).toFloat()

      val activePulseBoost = (
        micLiveEnergy * 0.085f * listeningPresence +
        speechCadenceEnergy * 0.065f * speakingPresence +
        musicBeatEnergy * 0.055f * musicPresence +
        chargeSurge * 0.038f * chargingPresence +
        sin(breathPhase) * 0.015f
      )
      val radius = baseRadius * (1.0f + activePulseBoost)

      val liveMusicHighlight = getDynamicMusicColor(musicColorNorm + 0.15f)
      val liveMusicSecondary = getDynamicMusicColor(musicColorNorm + 0.45f)
      val chargeVoltColor = Color(0xFF39FF14)
      val chargeCyanColor = Color(0xFF00F5D4)
      val chargeHighlight = lerpColor(chargeVoltColor, chargeCyanColor, chargeSurge)

      val outerBloomRadius = radius * (1.16f + 0.08f * maxOf(
        listeningPresence * micLiveEnergy,
        speakingPresence * speechCadenceEnergy,
        musicPresence * musicBeatEnergy,
        chargingPresence * (0.4f + 0.5f * chargeSurge)
      ))
      val effectiveGlow = maxOf(visualState.glowIntensity, chargingPresence * 0.82f)
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            animatedAccent.copy(alpha = 0.34f * effectiveGlow),
            animatedPrimary.copy(alpha = 0.15f * effectiveGlow),
            Color.Transparent
          ),
          center = center,
          radius = outerBloomRadius
        ),
        radius = outerBloomRadius,
        center = center
      )

      if (chargingPresence > 0.01f) {
        val bottomPoleY = center.y + radius * 0.96f
        val portStartY = if (canvasRootTopY >= 0f && screenHeightPx > canvasRootTopY + center.y) {
          (screenHeightPx - canvasRootTopY) + 18f
        } else {
          center.y + radius * 4.2f
        }
        val portVisibleY = portStartY - 18f

        val portGlowRadius = radius * (0.36f + 0.08f * chargeSurge) * chargingPresence
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(
              Color.White.copy(alpha = 0.72f * chargingPresence),
              chargeHighlight.copy(alpha = 0.45f * chargingPresence),
              Color.Transparent
            ),
            center = Offset(center.x, portVisibleY),
            radius = portGlowRadius
          ),
          radius = portGlowRadius,
          center = Offset(center.x, portVisibleY),
          blendMode = BlendMode.Plus
        )

        val dropletCount = if (isPowerSaving) 5 else 9
        for (d in 0 until dropletCount) {
          val seed = d * 0.618034f
          val speed = 0.40f + (d % 3) * 0.07f
          val rawProgress = (continuousTimeSec * speed + seed) % 1.0f
          val pullCurve = 0.28f * rawProgress + 0.72f * (rawProgress * rawProgress)
          val targetMergeY = center.y + radius * 0.58f
          val currentY = portStartY + (targetMergeY - portStartY) * pullCurve

          val midFlightEnvelope = sin((pullCurve * Math.PI).toDouble()).toFloat().coerceIn(0f, 1f)
          val xSway = sin(driftPhase * 2.2f + d * 2.1f + rawProgress * 5.5f) * (radius * 0.24f * midFlightEnvelope)
          val currentX = center.x + xSway

          val fadeIn = (rawProgress / 0.08f).coerceIn(0f, 1f)
          val mergeFade = ((1.0f - rawProgress) / 0.16f).coerceIn(0f, 1f)
          val dropletAlpha = fadeIn * mergeFade * chargingPresence

          val proximityToRim = 1.0f - (kotlin.math.abs(currentY - bottomPoleY) / (radius * 0.48f)).coerceIn(0f, 1f)
          val dropRadius = (4.6f + (d % 3) * 1.5f) * (1.0f - 0.22f * proximityToRim) * chargingPresence
          val tailLength = dropRadius * (2.8f + 2.4f * proximityToRim)
          val dropColor = if (d % 2 == 0) chargeVoltColor else chargeCyanColor

          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(
                Color.White.copy(alpha = 0.92f * dropletAlpha),
                dropColor.copy(alpha = 0.72f * dropletAlpha),
                Color.Transparent
              ),
              center = Offset(currentX, currentY),
              radius = dropRadius * 3.0f
            ),
            radius = dropRadius * 3.0f,
            center = Offset(currentX, currentY),
            blendMode = BlendMode.Plus
          )

          dropletPath.reset()
          dropletPath.moveTo(currentX, currentY - dropRadius * 1.15f)
          dropletPath.cubicTo(
            currentX + dropRadius * 1.25f, currentY - dropRadius * 0.3f,
            currentX + dropRadius * 0.65f, currentY + tailLength * 0.45f,
            currentX, currentY + tailLength
          )
          dropletPath.cubicTo(
            currentX - dropRadius * 0.65f, currentY + tailLength * 0.45f,
            currentX - dropRadius * 1.25f, currentY - dropRadius * 0.3f,
            currentX, currentY - dropRadius * 1.15f
          )
          dropletPath.close()

          drawPath(
            path = dropletPath,
            brush = Brush.verticalGradient(
              colors = listOf(
                Color.White.copy(alpha = 0.96f * dropletAlpha),
                dropColor.copy(alpha = 0.88f * dropletAlpha),
                Color.Transparent
              ),
              startY = currentY - dropRadius,
              endY = currentY + tailLength
            ),
            blendMode = BlendMode.Plus
          )

          if (proximityToRim > 0.35f) {
            val impactAlpha = ((proximityToRim - 0.35f) / 0.65f) * dropletAlpha
            val impactCenter = Offset(center.x + xSway * 0.35f, bottomPoleY)
            val impactRadius = radius * (0.14f + 0.16f * (1f - proximityToRim))
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(
                  Color.White.copy(alpha = 0.75f * impactAlpha),
                  dropColor.copy(alpha = 0.55f * impactAlpha),
                  Color.Transparent
                ),
                center = impactCenter,
                radius = impactRadius
              ),
              radius = impactRadius,
              center = impactCenter,
              blendMode = BlendMode.Plus
            )
          }
        }
      }

      if (musicPresence > 0.01f) {
        val haloRadius = radius * (1.045f + 0.055f * musicBeatEnergy * musicPresence)
        val haloAlpha = (0.38f + 0.35f * musicBeatEnergy) * musicPresence
        drawCircle(
          brush = Brush.sweepGradient(
            colors = listOf(
              liveMusicHighlight.copy(alpha = haloAlpha),
              liveMusicSecondary.copy(alpha = haloAlpha * 0.75f),
              animatedAccent.copy(alpha = haloAlpha * 0.9f),
              liveMusicSecondary.copy(alpha = haloAlpha * 0.75f),
              liveMusicHighlight.copy(alpha = haloAlpha)
            ),
            center = center
          ),
          radius = haloRadius,
          center = center,
          style = Stroke(width = (2.5f + 3.5f * musicBeatEnergy) * musicPresence)
        )

        if (!isPowerSaving) {
          val barCount = 36
          for (i in 0 until barCount) {
            val angle = (i.toFloat() / barCount) * (2f * Math.PI.toFloat()) + driftPhase * 0.35f
            val bandHarmonic = sin(angle * 4f + wavePhase * 2f) * 0.5f +
              cos(angle * 3f - pulsePhase * 2f) * 0.5f
            val barNormalized = ((bandHarmonic + 1f) * 0.5f * (0.45f + 0.55f * musicBeatEnergy)).coerceIn(0.08f, 1f)
            val barLength = radius * (0.025f + 0.095f * barNormalized) * musicPresence
            val innerR = radius * 1.02f
            val outerR = innerR + barLength
            val cosA = cos(angle)
            val sinA = sin(angle)
            val startPt = Offset(center.x + cosA * innerR, center.y + sinA * innerR)
            val endPt = Offset(center.x + cosA * outerR, center.y + sinA * outerR)
            val barColor = if (i % 2 == 0) liveMusicHighlight else liveMusicSecondary
            drawLine(
              color = barColor.copy(alpha = (0.35f + 0.55f * barNormalized) * musicPresence),
              start = startPt,
              end = endPt,
              strokeWidth = 2.6f,
              cap = StrokeCap.Round
            )
          }
        }
      }

      val vocalActivity = maxOf(listeningPresence, speakingPresence)
      if (vocalActivity > 0.01f) {
        val activeVocalEnergy = if (listeningPresence >= speakingPresence) micLiveEnergy else speechCadenceEnergy
        val rippleCount = if (isPowerSaving) 2 else 3
        val rippleBaseProgress = (wavePhase / (2f * Math.PI.toFloat()))
        for (r in 0 until rippleCount) {
          val phaseOffset = (rippleBaseProgress + r.toFloat() / rippleCount) % 1.0f
          val rippleRadius = radius * (1.01f + phaseOffset * (0.14f + 0.10f * activeVocalEnergy))
          val rippleAlpha = (1.0f - phaseOffset) * (0.35f + 0.45f * activeVocalEnergy) * vocalActivity
          val rippleColor = if (listeningPresence >= speakingPresence) {
            Color(0xFF80FFDB)
          } else {
            Color(0xFFFFD166)
          }
          drawCircle(
            color = rippleColor.copy(alpha = rippleAlpha.coerceIn(0f, 0.85f)),
            radius = rippleRadius,
            center = center,
            style = Stroke(width = (1.8f + (1f - phaseOffset) * 2.8f * (0.5f + activeVocalEnergy)))
          )
        }
      }

      circlePath.reset()
      circlePath.addOval(androidx.compose.ui.geometry.Rect(center, radius))
      clipPath(circlePath) {
        drawCircle(
          color = Color(0xFF030712),
          radius = radius,
          center = center
        )

        val bgShiftMultiplier = 0.24f + 0.10f * (musicPresence * musicBeatEnergy + vocalActivity * 0.8f)
        val bgBrush = Brush.radialGradient(
          colors = listOf(
            animatedPrimary.copy(alpha = 0.95f),
            animatedSecondary.copy(alpha = 0.85f),
            Color(0xFF050B18)
          ),
          center = center + Offset(
            x = cos(driftPhase) * radius * bgShiftMultiplier,
            y = sin(breathPhase) * radius * bgShiftMultiplier
          ),
          radius = radius * 1.35f
        )
        drawCircle(brush = bgBrush, radius = radius, center = center)

        val cloud1RadiusScale = 0.86f + 0.14f * (micLiveEnergy * listeningPresence + musicBeatEnergy * musicPresence)
        val cloud1Center = center + Offset(
          x = (cos(driftPhase) * 0.7f + sin(breathPhase) * 0.3f) * radius * 0.42f,
          y = (sin(driftPhase) * 0.7f - cos(breathPhase) * 0.3f) * radius * 0.38f
        )
        val cloud1Brush = Brush.radialGradient(
          colors = listOf(
            animatedAccent.copy(alpha = (0.85f * visualState.glowIntensity).coerceIn(0f, 1f)),
            animatedPrimary.copy(alpha = 0.58f),
            Color.Transparent
          ),
          center = cloud1Center,
          radius = radius * cloud1RadiusScale
        )
        drawCircle(
          brush = cloud1Brush,
          radius = radius * cloud1RadiusScale,
          center = cloud1Center,
          blendMode = BlendMode.Screen
        )

        val cloud2Center = center + Offset(
          x = (-sin(breathPhase) * 0.75f + cos(driftPhase) * 0.25f) * radius * 0.44f,
          y = (cos(breathPhase) * 0.75f + sin(driftPhase) * 0.25f) * radius * 0.36f
        )
        val warmColor = when {
          visualState == CoreVisualState.ERROR -> Color(0xFFFF5252)
          isVoiceListening || visualState == CoreVisualState.LISTENING -> Color(0xFF64DFDF)
          isSpeakingAloud || visualState == CoreVisualState.RESPONDING -> Color(0xFFFFD166)
          visualState == CoreVisualState.PROCESSING -> Color(0xFFFF70A6)
          visualState == CoreVisualState.SUCCESS -> Color(0xFFFFD166)
          visualState == CoreVisualState.CALL -> Color(0xFFFF9E00)
          isMusicPlaying || visualState == CoreVisualState.MUSIC -> liveMusicHighlight
          isCharging || visualState == CoreVisualState.CHARGING -> chargeVoltColor
          visualState == CoreVisualState.NOTIFICATION -> Color(0xFFFFB703)
          else -> Color(0xFFFF9E79)
        }
        val cloud2RadiusScale = 0.78f + 0.14f * (
          speechCadenceEnergy * speakingPresence +
          musicBeatEnergy * musicPresence +
          chargeSurge * chargingPresence * 0.7f
        )
        val cloud2Brush = Brush.radialGradient(
          colors = listOf(
            warmColor.copy(alpha = (0.75f * effectiveGlow).coerceIn(0f, 1f)),
            animatedSecondary.copy(alpha = 0.40f),
            Color.Transparent
          ),
          center = cloud2Center,
          radius = radius * cloud2RadiusScale
        )
        drawCircle(
          brush = cloud2Brush,
          radius = radius * cloud2RadiusScale,
          center = cloud2Center,
          blendMode = BlendMode.Screen
        )

        if (musicPresence > 0.05f && (listeningPresence > 0.05f || speakingPresence > 0.05f)) {
          val musicOrbCenter = center + Offset(
            x = sin(driftPhase + breathPhase) * radius * 0.36f,
            y = -cos(driftPhase + breathPhase) * radius * 0.36f
          )
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(
                liveMusicHighlight.copy(alpha = 0.65f * musicPresence),
                liveMusicSecondary.copy(alpha = 0.35f * musicPresence),
                Color.Transparent
              ),
              center = musicOrbCenter,
              radius = radius * 0.68f
            ),
            radius = radius * 0.68f,
            center = musicOrbCenter,
            blendMode = BlendMode.Screen
          )
        }

        if (chargingPresence > 0.02f) {
          val clampedFill = normalizedBatteryLevel.coerceIn(0.06f, 1.0f)
          val fillSurfaceY = (center.y + radius) - (2f * radius * clampedFill)
          val leftX = center.x - radius * 1.05f
          val rightX = center.x + radius * 1.05f
          val bottomY = center.y + radius * 1.08f
          val waveAmp = radius * (0.035f + 0.020f * chargeSurge) * (1f - 0.6f * (clampedFill - 0.92f).coerceAtLeast(0f) / 0.08f)

          liquidFillPath.reset()
          liquidFillPath.moveTo(leftX, bottomY)
          val segments = 24
          val stepX = (rightX - leftX) / segments
          for (s in 0..segments) {
            val x = leftX + s * stepX
            val normX = s.toFloat() / segments
            val yWave = sin(normX * Math.PI.toFloat() * 2.5f + driftPhase * 3.2f) * waveAmp +
              cos(normX * Math.PI.toFloat() * 1.5f - breathPhase * 2.8f) * (waveAmp * 0.55f)
            val y = fillSurfaceY + yWave
            liquidFillPath.lineTo(x, y)
          }
          liquidFillPath.lineTo(rightX, bottomY)
          liquidFillPath.close()

          drawPath(
            path = liquidFillPath,
            brush = Brush.verticalGradient(
              colors = listOf(
                chargeHighlight.copy(alpha = 0.72f * chargingPresence),
                chargeCyanColor.copy(alpha = 0.52f * chargingPresence),
                chargeVoltColor.copy(alpha = 0.66f * chargingPresence)
              ),
              startY = fillSurfaceY - waveAmp,
              endY = bottomY
            ),
            blendMode = BlendMode.Plus
          )

          drawPath(
            path = liquidFillPath,
            brush = Brush.horizontalGradient(
              colors = listOf(
                Color.Transparent,
                chargeCyanColor.copy(alpha = 0.85f * chargingPresence),
                Color.White.copy(alpha = 0.92f * chargingPresence),
                chargeVoltColor.copy(alpha = 0.85f * chargingPresence),
                Color.Transparent
              ),
              startX = center.x - radius,
              endX = center.x + radius
            ),
            style = Stroke(width = (2.6f + 1.4f * chargeSurge) * chargingPresence, cap = StrokeCap.Round),
            blendMode = BlendMode.Plus
          )

          if (!isPowerSaving) {
            val bubbleCount = 8
            for (ionIdx in 0 until bubbleCount) {
              val ionSeed = ionIdx * 0.618034f
              val ascendProgress = (continuousTimeSec * (0.50f + (ionIdx % 3) * 0.12f) + ionSeed) % 1.0f
              val envelope = sin(ascendProgress * Math.PI.toFloat()).coerceIn(0f, 1f)
              val startPoleY = center.y + radius * 0.92f
              val targetTopY = minOf(fillSurfaceY + radius * 0.05f, center.y + radius * 0.4f)
              val currentBubbleY = startPoleY + (targetTopY - startPoleY) * ascendProgress
              val horizontalSpread = (1.0f - ascendProgress * 0.5f) * radius * 0.38f
              val xWave = sin(driftPhase * 2.0f + ionIdx * 1.7f + ascendProgress * 4.0f) * horizontalSpread
              val ionPos = Offset(center.x + xWave, currentBubbleY)
              val ionRadius = (2.8f + 3.0f * envelope) * chargingPresence
              val ionColor = if (ionIdx % 2 == 0) chargeVoltColor else chargeCyanColor
              drawCircle(
                brush = Brush.radialGradient(
                  colors = listOf(
                    Color.White.copy(alpha = 0.88f * envelope * chargingPresence),
                    ionColor.copy(alpha = 0.62f * envelope * chargingPresence),
                    Color.Transparent
                  ),
                  center = ionPos,
                  radius = ionRadius * 2.5f
                ),
                radius = ionRadius * 2.5f,
                center = ionPos,
                blendMode = BlendMode.Plus
              )
            }
          }
        }

        val nucleusScale = 0.24f +
          0.18f * micLiveEnergy * listeningPresence +
          0.15f * speechCadenceEnergy * speakingPresence +
          0.12f * musicBeatEnergy * musicPresence +
          0.10f * chargeSurge * chargingPresence +
          0.03f * sin(breathPhase)
        val nucleusRadius = radius * nucleusScale.coerceIn(0.18f, 0.58f)
        val nucleusOffset = Offset(
          x = cos(breathPhase) * radius * 0.055f,
          y = sin(driftPhase) * radius * 0.055f
        )
        val nucleusAlpha = (0.34f + 0.45f * maxOf(
          micLiveEnergy * listeningPresence,
          speechCadenceEnergy * speakingPresence,
          musicBeatEnergy * musicPresence,
          (0.45f + 0.45f * chargeSurge) * chargingPresence
        )).coerceIn(0.25f, 0.90f)

        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(
              Color.White.copy(alpha = nucleusAlpha * 0.85f),
              animatedAccent.copy(alpha = nucleusAlpha * 0.65f),
              warmColor.copy(alpha = nucleusAlpha * 0.25f),
              Color.Transparent
            ),
            center = center + nucleusOffset,
            radius = nucleusRadius
          ),
          radius = nucleusRadius,
          center = center + nucleusOffset,
          blendMode = BlendMode.Plus
        )

        if (!isPowerSaving) {
          val moteCount = 8
          for (m in 0 until moteCount) {
            val seed = m * 1.37f
            val speedFactor = 0.55f + (m % 3) * 0.18f
            val orbitAngle = driftPhase * speedFactor * (if (m % 2 == 0) 1f else -1f) + seed * 2.1f
            val radialBreath = (sin(breathPhase + seed) + 1f) * 0.5f
            val orbitDistX = radius * (0.24f + 0.44f * radialBreath)
            val orbitDistY = radius * (0.22f + 0.40f * ((cos(breathPhase * 0.8f + seed) + 1f) * 0.5f))
            val motePos = Offset(
              x = center.x + cos(orbitAngle) * orbitDistX,
              y = center.y + sin(orbitAngle) * orbitDistY
            )
            val motePulse = ((sin(pulsePhase * 0.5f + seed * 3f) + 1f) * 0.5f)
            val moteRadius = (2.2f + 3.0f * motePulse) * (1f + 0.4f * maxOf(vocalActivity, musicPresence))
            val moteColor = if (m % 2 == 0) Color.White else animatedAccent
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(
                  moteColor.copy(alpha = 0.50f + 0.35f * motePulse),
                  moteColor.copy(alpha = 0.14f),
                  Color.Transparent
                ),
                center = motePos,
                radius = moteRadius * 2.4f
              ),
              radius = moteRadius * 2.4f,
              center = motePos,
              blendMode = BlendMode.Plus
            )
          }
        }

        val horizonOffset = Offset(
          x = cos(breathPhase) * radius * 0.14f,
          y = sin(driftPhase) * radius * 0.14f
        )
        val energyBrush = Brush.linearGradient(
          colors = listOf(
            Color.Transparent,
            animatedAccent.copy(alpha = 0.38f * visualState.glowIntensity),
            Color.White.copy(alpha = 0.24f * visualState.glowIntensity),
            Color.Transparent
          ),
          start = center + horizonOffset - Offset(radius * 0.8f, radius * 0.3f),
          end = center + horizonOffset + Offset(radius * 0.8f, radius * 0.3f)
        )
        drawCircle(
          brush = energyBrush,
          radius = radius,
          center = center,
          blendMode = BlendMode.Plus
        )

        val specularCenter = center - Offset(radius * 0.32f, radius * 0.35f)
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(
              Color.White.copy(alpha = 0.18f),
              Color.White.copy(alpha = 0.05f),
              Color.Transparent
            ),
            center = specularCenter,
            radius = radius * 0.55f
          ),
          radius = radius * 0.55f,
          center = specularCenter,
          blendMode = BlendMode.Screen
        )

        val vignetteBrush = Brush.radialGradient(
          colorStops = arrayOf(
            0.0f to Color.Transparent,
            0.74f to Color.Transparent,
            0.91f to Color(0x66000000),
            1.0f to Color(0xCC000000)
          ),
          center = center,
          radius = radius
        )
        drawCircle(brush = vignetteBrush, radius = radius, center = center)
      }

      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            animatedAccent.copy(alpha = 0.55f * visualState.glowIntensity),
            animatedPrimary.copy(alpha = 0.25f),
            Color.Transparent
          ),
          center = center,
          radius = radius * 1.05f
        ),
        radius = radius * 1.02f,
        center = center,
        style = Stroke(width = 2.6f)
      )
      drawCircle(
        color = Color(0x40FFFFFF),
        radius = radius,
        center = center,
        style = Stroke(width = 1.1f)
      )
    }
  }
}

private fun getDynamicMusicColor(progress: Float): Color {
  val p = (progress % 1.0f + 1.0f) % 1.0f
  return when {
    p < 0.2f -> lerpColor(Color(0xFF8338EC), Color(0xFFFF006E), p / 0.2f)
    p < 0.4f -> lerpColor(Color(0xFFFF006E), Color(0xFFFF70A6), (p - 0.2f) / 0.2f)
    p < 0.6f -> lerpColor(Color(0xFFFF70A6), Color(0xFFFFD166), (p - 0.4f) / 0.2f)
    p < 0.8f -> lerpColor(Color(0xFFFFD166), Color(0xFF00F5D4), (p - 0.6f) / 0.2f)
    else -> lerpColor(Color(0xFF00F5D4), Color(0xFF8338EC), (p - 0.8f) / 0.2f)
  }
}

private fun getDynamicChargingColor(batteryNorm: Float, phase: Float, offset: Float): Color {
  val wave = ((sin((phase + offset * 6.283185f).toDouble()) + 1.0) * 0.5).toFloat()
  val cyan = Color(0xFF00B4D8)
  val emerald = Color(0xFF06D6A0)
  val neonVolt = Color(0xFF39FF14)
  val solarGold = Color(0xFFFFEA00)
  val base = lerpColor(cyan, emerald, wave)
  val energized = lerpColor(emerald, neonVolt, ((cos((phase * 0.7f + offset * 3.14f).toDouble()) + 1.0) * 0.5).toFloat())
  val blended = lerpColor(base, energized, 0.55f)
  val fullChargeBoost = ((batteryNorm - 0.75f).coerceAtLeast(0f) / 0.25f) * 0.35f
  return lerpColor(blended, solarGold, fullChargeBoost)
}

private fun lerpColor(start: Color, end: Color, fraction: Float): Color {
  val f = fraction.coerceIn(0f, 1f)
  return Color(
    red = start.red + (end.red - start.red) * f,
    green = start.green + (end.green - start.green) * f,
    blue = start.blue + (end.blue - start.blue) * f,
    alpha = start.alpha + (end.alpha - start.alpha) * f
  )
}
