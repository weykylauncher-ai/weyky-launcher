package com.example.device.weather

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class DeviceLocation(
  val latitude: Double,
  val longitude: Double,
  val city: String? = null,
  val address: String? = null,
  val accuracyMeters: Float? = null,
  val timestampMillis: Long = System.currentTimeMillis()
)

sealed class LocationResult {
  data class Success(val location: DeviceLocation) : LocationResult()
  object PermissionRequired : LocationResult()
  object LocationDisabledOrUnavailable : LocationResult()
}

data class HourlyForecastItem(
  val hourLabel: String,
  val temperature: Float,
  val condition: String,
  val precipitationProbability: Int,
  val precipitationMm: Float = 0f
)

data class DailyForecastItem(
  val dayLabel: String,
  val maxTemp: Float,
  val minTemp: Float,
  val condition: String,
  val precipitationProbabilityMax: Int,
  val maxWindSpeedKmH: Float? = null,
  val maxWindGustsKmH: Float? = null
)

data class WeatherSnapshot(
  val isAvailable: Boolean = false,
  val statusMessage: String? = null,
  val temperatureCelsius: Float? = null,
  val apparentTemperatureCelsius: Float? = null,
  val condition: String? = null,
  val maxTempToday: Float? = null,
  val minTempToday: Float? = null,
  val maxTempTomorrow: Float? = null,
  val minTempTomorrow: Float? = null,
  val conditionTomorrow: String? = null,
  val rainProbTodayMax: Int? = null,
  val rainProbTomorrowMax: Int? = null,
  val windSpeedKmH: Float? = null,
  val windSpeedTomorrowMax: Float? = null,
  val windDirectionCompass: String? = null,
  val humidityPercent: Int? = null,
  val uvIndex: Float? = null,
  val isCached: Boolean = false,
  val lastUpdatedMillis: Long = System.currentTimeMillis(),
  val lastUpdatedFormatted: String = "",
  val hourlyForecast: List<HourlyForecastItem> = emptyList(),
  val dailyForecast: List<DailyForecastItem> = emptyList()
)

class LocationProvider(private val context: Context) {
  private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

  fun hasLocationPermission(): Boolean {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    return fine || coarse
  }

  suspend fun getCurrentLocation(): LocationResult = withContext(Dispatchers.IO) {
    if (!hasLocationPermission()) {
      return@withContext LocationResult.PermissionRequired
    }
    val lm = locationManager ?: return@withContext LocationResult.LocationDisabledOrUnavailable

    try {
      val providers = lm.getProviders(true)
      if (providers.isEmpty()) {
        return@withContext LocationResult.LocationDisabledOrUnavailable
      }

      var bestLocation: Location? = null
      for (provider in providers) {
        try {
          val loc = lm.getLastKnownLocation(provider) ?: continue
          if (bestLocation == null || loc.time > bestLocation.time) {
            bestLocation = loc
          }
        } catch (_: SecurityException) {}
      }

      if (bestLocation != null) {
        return@withContext LocationResult.Success(
          DeviceLocation(
            latitude = bestLocation.latitude,
            longitude = bestLocation.longitude,
            accuracyMeters = bestLocation.accuracy,
            timestampMillis = bestLocation.time
          )
        )
      }

      // If no last known location, attempt quick single update
      suspendCancellableCoroutine<LocationResult> { continuation ->
        val provider = if (providers.contains(LocationManager.NETWORK_PROVIDER)) {
          LocationManager.NETWORK_PROVIDER
        } else {
          providers.first()
        }

        val listener = object : LocationListener {
          override fun onLocationChanged(loc: Location) {
            lm.removeUpdates(this)
            if (continuation.isActive) {
              continuation.resume(
                LocationResult.Success(
                  DeviceLocation(
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    accuracyMeters = loc.accuracy,
                    timestampMillis = loc.time
                  )
                )
              )
            }
          }
          override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {}
          override fun onProviderEnabled(p0: String) {}
          override fun onProviderDisabled(p0: String) {
            lm.removeUpdates(this)
            if (continuation.isActive) {
              continuation.resume(LocationResult.LocationDisabledOrUnavailable)
            }
          }
        }

        try {
          lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
          continuation.invokeOnCancellation { lm.removeUpdates(listener) }
        } catch (_: SecurityException) {
          if (continuation.isActive) continuation.resume(LocationResult.PermissionRequired)
        } catch (_: Exception) {
          if (continuation.isActive) continuation.resume(LocationResult.LocationDisabledOrUnavailable)
        }
      }
    } catch (_: Exception) {
      LocationResult.LocationDisabledOrUnavailable
    }
  }
}

class WeatherProvider(
  private val context: Context,
  private val locationProvider: LocationProvider
) {
  private val client = OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)
    .readTimeout(5, TimeUnit.SECONDS)
    .build()

  private var cachedSnapshot: WeatherSnapshot? = null
  private var lastFetchMillis: Long = 0

  suspend fun fetchWeather(): WeatherSnapshot = withContext(Dispatchers.IO) {
    val now = System.currentTimeMillis()
    // Return cached if within 15 minutes
    cachedSnapshot?.let { cached ->
      if (now - lastFetchMillis < 15 * 60 * 1000) {
        return@withContext cached.copy(isCached = true)
      }
    }

    val locResult = locationProvider.getCurrentLocation()
    val (lat, lon) = when (locResult) {
      is LocationResult.Success -> Pair(locResult.location.latitude, locResult.location.longitude)
      else -> Pair(24.7136, 46.6753) // Riyadh fallback if GPS off
    }

    try {
      val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,precipitation_probability,precipitation,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,uv_index_max&timezone=auto&forecast_days=7"
      val request = Request.Builder().url(url).build()
      val response = client.newCall(request).execute()
      if (!response.isSuccessful) {
        return@withContext cachedSnapshot?.copy(isCached = true) ?: WeatherSnapshot(isAvailable = false, statusMessage = "HTTP ${response.code}")
      }

      val jsonStr = response.body?.string() ?: return@withContext WeatherSnapshot(isAvailable = false, statusMessage = "Empty response")
      val root = JSONObject(jsonStr)

      val current = root.optJSONObject("current")
      val hourly = root.optJSONObject("hourly")
      val daily = root.optJSONObject("daily")

      val temp = current?.optDouble("temperature_2m")?.toFloat()
      val appTemp = current?.optDouble("apparent_temperature")?.toFloat()
      val humidity = current?.optInt("relative_humidity_2m")
      val windSpeed = current?.optDouble("wind_speed_10m")?.toFloat()
      val windDirDeg = current?.optDouble("wind_direction_10m")
      val weatherCode = current?.optInt("weather_code", 0) ?: 0
      val condition = mapWmoCode(weatherCode)

      val windDirCompass = windDirDeg?.let { degToCompass(it) }

      // Daily
      val dailyTimes = daily?.optJSONArray("time")
      val maxTemps = daily?.optJSONArray("temperature_2m_max")
      val minTemps = daily?.optJSONArray("temperature_2m_min")
      val rainProbs = daily?.optJSONArray("precipitation_probability_max")
      val windMaxs = daily?.optJSONArray("wind_speed_10m_max")
      val windGusts = daily?.optJSONArray("wind_gusts_10m_max")
      val dailyCodes = daily?.optJSONArray("weather_code")
      val uvMaxs = daily?.optJSONArray("uv_index_max")

      val maxToday = maxTemps?.optDouble(0)?.toFloat()
      val minToday = minTemps?.optDouble(0)?.toFloat()
      val maxTom = maxTemps?.optDouble(1)?.toFloat()
      val minTom = minTemps?.optDouble(1)?.toFloat()
      val rainTodayMax = rainProbs?.optInt(0)
      val rainTomMax = rainProbs?.optInt(1)
      val windTomMax = windMaxs?.optDouble(1)?.toFloat()
      val condTom = dailyCodes?.optInt(1)?.let { mapWmoCode(it) }
      val uvToday = uvMaxs?.optDouble(0)?.toFloat()

      // Daily items
      val dailyList = mutableListOf<DailyForecastItem>()
      if (dailyTimes != null) {
        for (i in 0 until dailyTimes.length()) {
          val dateStr = dailyTimes.optString(i)
          val dayName = getDayLabel(dateStr, i)
          dailyList.add(
            DailyForecastItem(
              dayLabel = dayName,
              maxTemp = maxTemps?.optDouble(i)?.toFloat() ?: 0f,
              minTemp = minTemps?.optDouble(i)?.toFloat() ?: 0f,
              condition = mapWmoCode(dailyCodes?.optInt(i) ?: 0),
              precipitationProbabilityMax = rainProbs?.optInt(i) ?: 0,
              maxWindSpeedKmH = windMaxs?.optDouble(i)?.toFloat(),
              maxWindGustsKmH = windGusts?.optDouble(i)?.toFloat()
            )
          )
        }
      }

      // Hourly items (next 24 hours)
      val hourlyList = mutableListOf<HourlyForecastItem>()
      val hourlyTimes = hourly?.optJSONArray("time")
      val hourlyTemps = hourly?.optJSONArray("temperature_2m")
      val hourlyProbs = hourly?.optJSONArray("precipitation_probability")
      val hourlyPrecip = hourly?.optJSONArray("precipitation")
      val hourlyCodes = hourly?.optJSONArray("weather_code")

      val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())
      val sdfParse = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.getDefault())

      if (hourlyTimes != null) {
        val currentHourMillis = System.currentTimeMillis() - 3600 * 1000
        for (i in 0 until hourlyTimes.length()) {
          val timeStr = hourlyTimes.optString(i)
          val date = try { sdfParse.parse(timeStr) } catch (_: Exception) { null }
          if (date != null && date.time >= currentHourMillis && hourlyList.size < 24) {
            hourlyList.add(
              HourlyForecastItem(
                hourLabel = sdfHour.format(date),
                temperature = hourlyTemps?.optDouble(i)?.toFloat() ?: 0f,
                condition = mapWmoCode(hourlyCodes?.optInt(i) ?: 0),
                precipitationProbability = hourlyProbs?.optInt(i) ?: 0,
                precipitationMm = hourlyPrecip?.optDouble(i)?.toFloat() ?: 0f
              )
            )
          }
        }
      }

      val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
      val snapshot = WeatherSnapshot(
        isAvailable = true,
        temperatureCelsius = temp,
        apparentTemperatureCelsius = appTemp,
        condition = condition,
        maxTempToday = maxToday,
        minTempToday = minToday,
        maxTempTomorrow = maxTom,
        minTempTomorrow = minTom,
        conditionTomorrow = condTom,
        rainProbTodayMax = rainTodayMax,
        rainProbTomorrowMax = rainTomMax,
        windSpeedKmH = windSpeed,
        windSpeedTomorrowMax = windTomMax,
        windDirectionCompass = windDirCompass,
        humidityPercent = humidity,
        uvIndex = uvToday,
        isCached = false,
        lastUpdatedMillis = now,
        lastUpdatedFormatted = sdf.format(Date(now)),
        hourlyForecast = hourlyList,
        dailyForecast = dailyList
      )

      cachedSnapshot = snapshot
      lastFetchMillis = now
      snapshot
    } catch (e: Exception) {
      cachedSnapshot?.copy(isCached = true) ?: WeatherSnapshot(isAvailable = false, statusMessage = e.message)
    }
  }

  private fun degToCompass(deg: Double): String {
    val directions = arrayOf("شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب")
    val idx = (((deg + 22.5) % 360) / 45.0).toInt().coerceIn(0, 7)
    return directions[idx]
  }

  private fun getDayLabel(dateStr: String, index: Int): String {
    return when (index) {
      0 -> "اليوم"
      1 -> "غداً"
      else -> {
        try {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
          val d = sdf.parse(dateStr)
          if (d != null) SimpleDateFormat("EEEE", Locale("ar")).format(d) else dateStr
        } catch (_: Exception) {
          dateStr
        }
      }
    }
  }

  private fun mapWmoCode(code: Int): String {
    return when (code) {
      0 -> "صافٍ مشمس"
      1 -> "غالباً صافٍ"
      2 -> "غائم جزئياً"
      3 -> "غائم كلياً"
      45, 48 -> "ضباب"
      51, 53, 55 -> "رذاذ خفيف"
      61, 63 -> "أمطار معتدلة"
      65 -> "أمطار غزيرة"
      71, 73, 75 -> "ثلوج"
      80, 81, 82 -> "زخات مطر"
      95 -> "عاصفة رعدية"
      96, 99 -> "عواصف رعدية مع بَرَد"
      else -> "معتدل"
    }
  }
}
