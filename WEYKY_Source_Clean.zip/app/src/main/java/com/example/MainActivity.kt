package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.core.capabilities.CapabilityDetector
import com.example.core.context.ContextEngine
import com.example.core.context.ContextSnapshot
import com.example.core.context.ContextState
import com.example.core.intelligence.ContextReasoningEngine
import com.example.core.intelligence.ContextRequirementsRegistry
import com.example.core.intelligence.SituationSnapshotBuilder
import com.example.core.intelligence.conversation.ActionableOption
import com.example.core.intelligence.conversation.LocalConversationalEngine
import com.example.core.intent.ExecutionResult
import com.example.core.intent.IntentExecutor
import com.example.core.intent.IntentParser
import com.example.core.intent.handlers.AppActionHandler
import com.example.core.intent.handlers.AudioActionHandler
import com.example.core.intent.handlers.BatteryActionHandler
import com.example.core.intent.handlers.CallActionHandler
import com.example.core.intent.handlers.ContextActionHandler
import com.example.core.intent.handlers.FlashlightActionHandler
import com.example.core.intent.handlers.MediaActionHandler
import com.example.core.intent.handlers.NetworkActionHandler
import com.example.core.intent.handlers.NotificationActionHandler
import com.example.core.intent.handlers.SettingsActionHandler
import com.example.core.intent.handlers.StorageMemoryActionHandler
import com.example.core.intent.handlers.WeatherActionHandler
import com.example.core.voice.VoicePipeline
import com.example.core.voice.WeykySpeechSynthesizer
import com.example.device.apps.AppResolver
import com.example.device.audio.AudioController
import com.example.device.battery.BatteryProvider
import com.example.device.battery.ChargingState
import com.example.device.calendar.CalendarProvider
import com.example.device.calls.CallLogProvider
import com.example.device.calls.ContactLookupProvider
import com.example.device.flashlight.FlashlightController
import com.example.device.info.DeviceInfoProvider
import com.example.device.media.MediaPlaybackController
import com.example.device.memory.MemoryProvider
import com.example.device.network.NetworkProvider
import com.example.device.storage.StorageProvider
import com.example.device.weather.LocationProvider
import com.example.device.weather.WeatherProvider
import com.example.rendering.renderer.WeykyCoreView
import com.example.rendering.visual_state.CoreVisualState
import com.example.ui.theme.HudTabPosition
import com.example.ui.theme.JarvisHudBadge
import com.example.ui.theme.JarvisHudCard
import com.example.ui.theme.JarvisHudColors
import com.example.ui.theme.jarvisTacticalBackground
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      WeykyMainAppScreen()
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WeykyMainAppScreen() {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current

  // Capability and hardware providers
  val capabilityDetector = remember { CapabilityDetector(context) }
  val batteryProvider = remember { BatteryProvider(context) }
  val networkProvider = remember { NetworkProvider(context) }
  val storageProvider = remember { StorageProvider() }
  val memoryProvider = remember { MemoryProvider(context) }
  val flashlightController = remember { FlashlightController(context) }
  val audioController = remember { AudioController(context) }
  val mediaController = remember { MediaPlaybackController(context) }
  val appResolver = remember { AppResolver(context) }
  val callLogProvider = remember { CallLogProvider(context) }
  val contactLookupProvider = remember { ContactLookupProvider(context) }
  val calendarProvider = remember { CalendarProvider(context) }
  val deviceInfoProvider = remember { DeviceInfoProvider(context) }
  val locationProvider = remember { LocationProvider(context) }
  val weatherProvider = remember { WeatherProvider(context, locationProvider) }
  val contextEngine = remember { ContextEngine(context) }

  // Action Handlers
  val batteryHandler = remember { BatteryActionHandler(batteryProvider) }
  val storageMemoryHandler = remember { StorageMemoryActionHandler(memoryProvider, storageProvider) }
  val flashlightHandler = remember { FlashlightActionHandler(capabilityDetector, flashlightController) }
  val audioHandler = remember { AudioActionHandler(audioController) }
  val mediaHandler = remember { MediaActionHandler(mediaController) }
  val appHandler = remember { AppActionHandler(appResolver) }
  val callHandler = remember { CallActionHandler(context, callLogProvider, contactLookupProvider) }
  val weatherHandler = remember { WeatherActionHandler(weatherProvider, locationProvider) }
  val networkHandler = remember { NetworkActionHandler(context, networkProvider) }
  val notificationHandler = remember { NotificationActionHandler(context, capabilityDetector) }
  val settingsHandler = remember { SettingsActionHandler(context) }

  val snapshotBuilder = remember {
    SituationSnapshotBuilder(
      batteryProvider = batteryProvider,
      networkProvider = networkProvider,
      contextEngine = contextEngine,
      locationProvider = locationProvider,
      weatherProvider = weatherProvider,
      calendarProvider = calendarProvider,
      mediaController = mediaController,
      callLogProvider = callLogProvider
    )
  }

  val reasoningEngine = remember { ContextReasoningEngine() }
  val contextActionHandler = remember {
    ContextActionHandler(
      getContextSnapshot = { contextEngine.contextState.value },
      situationSnapshotBuilder = snapshotBuilder,
      contextReasoningEngine = reasoningEngine
    )
  }

  val conversationalEngine = remember {
    LocalConversationalEngine(
      situationSnapshotBuilder = snapshotBuilder,
      deviceInfoProvider = deviceInfoProvider
    )
  }

  val intentExecutor = remember {
    IntentExecutor(
      batteryActionHandler = batteryHandler,
      storageMemoryActionHandler = storageMemoryHandler,
      flashlightActionHandler = flashlightHandler,
      audioActionHandler = audioHandler,
      mediaActionHandler = mediaHandler,
      appActionHandler = appHandler,
      callActionHandler = callHandler,
      weatherActionHandler = weatherHandler,
      networkActionHandler = networkHandler,
      notificationActionHandler = notificationHandler,
      settingsActionHandler = settingsHandler,
      contextActionHandler = contextActionHandler,
      localConversationalEngine = conversationalEngine,
      deviceInfoProvider = deviceInfoProvider
    )
  }

  // Reactive UI States
  var visualState by remember { mutableStateOf(CoreVisualState.IDLE) }
  var isVoiceListening by remember { mutableStateOf(false) }
  var isSpeakingAloud by remember { mutableStateOf(false) }
  var voiceEnergyLevel by remember { mutableFloatStateOf(0f) }
  var textQueryInput by remember { mutableStateOf("") }
  var transcriptText by remember { mutableStateOf("") }
  var responseText by remember { mutableStateOf("WEYKY Core جاهز لاستقبال الأوامر والأسئلة الصوتية والتفاعلية.") }
  var actionBadgeText by remember { mutableStateOf("CORE READY") }
  var suggestions by remember { mutableStateOf(listOf<ActionableOption>()) }
  var isTtsEnabled by remember { mutableStateOf(true) }
  var showSettingsDialog by remember { mutableStateOf(false) }
  var selectedBgIndex by remember { mutableIntStateOf(0) }
  var selectedBorderIndex by remember { mutableIntStateOf(0) }

  val currentBgColor = Color(JarvisHudColors.BackgroundPresets[selectedBgIndex].second)
  val currentAccentColor = Color(JarvisHudColors.BorderPresets[selectedBorderIndex].second)

  // Speech Synthesizer
  val speechSynthesizer = remember {
    WeykySpeechSynthesizer(context) { speaking ->
      isSpeakingAloud = speaking
      if (speaking) {
        visualState = CoreVisualState.RESPONDING
      } else {
        if (!isVoiceListening) {
          visualState = CoreVisualState.IDLE
        }
      }
    }
  }

  // Clean up speech on leave
  DisposableEffect(Unit) {
    onDispose {
      speechSynthesizer.shutdown()
      contextEngine.stop()
    }
  }

  // Telemetry state flows
  val batteryState by batteryProvider.batteryState.collectAsState()
  val contextState by contextEngine.contextState.collectAsState()
  val networkState by networkProvider.networkState.collectAsState()

  val isBatteryCharging = batteryState?.chargingState == ChargingState.CHARGING
  val batteryPercentage = batteryState?.percentage ?: 100

  // Function to process query (text or speech)
  fun executeUserCommand(query: String) {
    if (query.isBlank()) return
    coroutineScope.launch {
      transcriptText = query
      visualState = CoreVisualState.PROCESSING
      actionBadgeText = "PROCESSING..."

      try {
        val parsedIntent = withContext(Dispatchers.Default) {
          IntentParser.parse(query, conversationalEngine.session)
        }
        val outcome = intentExecutor.execute(parsedIntent)

        when (outcome) {
          is ExecutionResult.Success -> {
            responseText = outcome.speech
            actionBadgeText = outcome.actionTaken ?: "SUCCESS"
            visualState = outcome.visualState
            suggestions = outcome.proactiveSuggestions

            if (isTtsEnabled) {
              speechSynthesizer.speak(outcome.speech)
            }
          }
          is ExecutionResult.Fallback -> {
            responseText = outcome.explanation
            actionBadgeText = "FALLBACK"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.explanation)
          }
          is ExecutionResult.Unavailable -> {
            responseText = outcome.reason
            actionBadgeText = "UNAVAILABLE"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.reason)
          }
          is ExecutionResult.RequiresPermission -> {
            responseText = outcome.rationale
            actionBadgeText = "PERMISSION NEEDED"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.rationale)
          }
          is ExecutionResult.Error -> {
            responseText = outcome.friendlyMessage
            actionBadgeText = "ERROR"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.friendlyMessage)
          }
          is ExecutionResult.NeedsConfirmation -> {
            responseText = outcome.prompt
            actionBadgeText = "CONFIRMATION"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.prompt)
          }
          is ExecutionResult.NotSupported -> {
            responseText = outcome.reason
            actionBadgeText = "NOT SUPPORTED"
            visualState = outcome.visualState
            if (isTtsEnabled) speechSynthesizer.speak(outcome.reason)
          }
        }
      } catch (e: Exception) {
        responseText = "حدث خطأ أثناء معالجة الأمر: ${e.message}"
        actionBadgeText = "ERROR"
        visualState = CoreVisualState.ERROR
      }
    }
  }

  // Voice Pipeline
  val voicePipeline = remember {
    VoicePipeline(
      context = context,
      onTranscriptReady = { text ->
        isVoiceListening = false
        if (text.isNotBlank()) {
          executeUserCommand(text)
        } else {
          visualState = CoreVisualState.IDLE
        }
      },
      onListeningStateChanged = { listening ->
        isVoiceListening = listening
        if (listening) {
          speechSynthesizer.stopIfSpeaking()
          visualState = CoreVisualState.LISTENING
          actionBadgeText = "LISTENING..."
        }
      },
      onVoiceEnergyChanged = { energy ->
        voiceEnergyLevel = energy
      }
    )
  }

  // Runtime Permissions Launcher
  val permissionsLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.RequestMultiplePermissions()
  ) { grantedMap ->
    val audioGranted = grantedMap[Manifest.permission.RECORD_AUDIO] == true
    if (audioGranted) {
      voicePipeline.startListening()
    } else {
      Toast.makeText(context, "إذن الميكروفون مطلوب للاستماع الصوتي", Toast.LENGTH_SHORT).show()
    }
  }

  fun toggleVoiceListening() {
    if (isVoiceListening) {
      voicePipeline.stopListening()
      visualState = CoreVisualState.IDLE
    } else {
      val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      if (!hasAudio) {
        permissionsLauncher.launch(
          arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA
          )
        )
      } else {
        voicePipeline.startListening()
      }
    }
  }

  // Start sensor monitoring
  LaunchedEffect(Unit) {
    contextEngine.start()
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    modifier = Modifier.fillMaxSize()
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .jarvisTacticalBackground(
          backgroundColor = currentBgColor,
          accentColor = currentAccentColor
        )
    ) {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        item {
          Spacer(modifier = Modifier.statusBarsPadding())
          Spacer(modifier = Modifier.height(6.dp))

          // Top Technical HUD Bar
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(
                      if (visualState == CoreVisualState.ERROR) JarvisHudColors.CrimsonAlert
                      else if (isVoiceListening) JarvisHudColors.TacticalAmber
                      else currentAccentColor
                    )
                )
                Text(
                  text = "WEYKY // QUANTUM CORE",
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = currentAccentColor,
                  letterSpacing = 2.sp
                )
              }
              Text(
                text = "STATUS: ${visualState.name} | CONTEXT: ${contextState.state.name}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = JarvisHudColors.TextSecondary
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              IconButton(
                onClick = {
                  isTtsEnabled = !isTtsEnabled
                  if (!isTtsEnabled) speechSynthesizer.stopIfSpeaking()
                },
                modifier = Modifier.testTag("tts_toggle_button")
              ) {
                Icon(
                  imageVector = if (isTtsEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                  contentDescription = "Toggle TTS",
                  tint = if (isTtsEnabled) currentAccentColor else JarvisHudColors.TextMuted
                )
              }
              IconButton(
                onClick = { showSettingsDialog = true },
                modifier = Modifier.testTag("settings_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Settings,
                  contentDescription = "Settings",
                  tint = currentAccentColor
                )
              }
            }
          }
        }

        // Central Animated Core View
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
          ) {
            WeykyCoreView(
              visualState = visualState,
              sizeDp = 220.dp,
              isVoiceListening = isVoiceListening,
              isSpeakingAloud = isSpeakingAloud,
              isCharging = isBatteryCharging,
              batteryPercentage = batteryPercentage,
              voiceEnergyLevel = voiceEnergyLevel,
              onClick = { toggleVoiceListening() }
            )
          }

          Text(
            text = if (isVoiceListening) "انقر للإيقاف أو تحدث الآن..." else "انقر على الكرة للبدء بالصوت",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = currentAccentColor.copy(alpha = 0.85f),
            letterSpacing = 1.sp
          )
        }

        // Live Response / Transcript HUD Card
        item {
          JarvisHudCard(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("response_hud_card"),
            accentColor = currentAccentColor,
            tabTitle = "WEYKY INTERACTION",
            tabPosition = HudTabPosition.TOP_START
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                JarvisHudBadge(
                  accentColor = currentAccentColor,
                  cutSize = 4.dp
                ) {
                  Text(
                    text = actionBadgeText,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = currentAccentColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                  )
                }

                if (isSpeakingAloud || isVoiceListening) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                  ) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(12.dp),
                      strokeWidth = 1.5.dp,
                      color = currentAccentColor
                    )
                    Text(
                      text = if (isVoiceListening) "MIC ACTIVE" else "SPEAKING",
                      fontSize = 9.sp,
                      fontFamily = FontFamily.Monospace,
                      color = currentAccentColor
                    )
                  }
                }
              }

              if (transcriptText.isNotBlank()) {
                Text(
                  text = "المستخدم: $transcriptText",
                  fontSize = 12.sp,
                  fontFamily = FontFamily.Monospace,
                  color = JarvisHudColors.TacticalAmber,
                  lineHeight = 16.sp
                )
              }

              Text(
                text = responseText,
                fontSize = 14.sp,
                color = JarvisHudColors.TextPrimary,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Medium
              )

              // Proactive follow-up action chips
              if (suggestions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                  verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  suggestions.forEach { option ->
                    JarvisHudBadge(
                      accentColor = currentAccentColor,
                      cutSize = 5.dp,
                      onClick = { executeUserCommand(option.queryToExecute) }
                    ) {
                      Text(
                        text = option.title,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = JarvisHudColors.HologramCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }

        // Live Telemetry HUD Card
        item {
          JarvisHudCard(
            modifier = Modifier.fillMaxWidth(),
            accentColor = currentAccentColor,
            tabTitle = "TELEMETRY & SENSORS",
            tabPosition = HudTabPosition.TOP_START
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                TelemetryMetricItem(
                  label = "BATTERY",
                  value = "$batteryPercentage%",
                  sub = if (isBatteryCharging) "CHARGING" else "DISCHARGING",
                  accentColor = if (batteryPercentage < 20) JarvisHudColors.CrimsonAlert else JarvisHudColors.NeonGreen
                )
                TelemetryMetricItem(
                  label = "PHYSICAL",
                  value = contextState.state.displayName,
                  sub = "${(contextState.confidence * 100).toInt()}% CONF",
                  accentColor = currentAccentColor
                )
                TelemetryMetricItem(
                  label = "NETWORK",
                  value = networkState.typeLabel,
                  sub = if (networkState.isConnected) "ONLINE" else "OFFLINE",
                  accentColor = if (networkState.isConnected) JarvisHudColors.NeonGreen else JarvisHudColors.TacticalAmber
                )
              }
            }
          }
        }

        // Quick Actions Command Grid
        item {
          Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text(
              text = "QUICK INTENT COMMANDS",
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = currentAccentColor,
              letterSpacing = 1.5.sp
            )

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              QuickActionChip("🔋 البطارية", currentAccentColor) {
                executeUserCommand("كم شحن البطارية؟")
              }
              QuickActionChip("💡 الكشاف", currentAccentColor) {
                executeUserCommand("شغل الكشاف")
              }
              QuickActionChip("🌤 الطقس", currentAccentColor) {
                executeUserCommand("كيف الطقس الآن؟")
              }
              QuickActionChip("🧠 تحليل السياق", currentAccentColor) {
                executeUserCommand("ما وضع الهاتف حالياً؟")
              }
              QuickActionChip("📊 الذاكرة والرام", currentAccentColor) {
                executeUserCommand("فحص الرام والذاكرة")
              }
              QuickActionChip("📱 الجهاز", currentAccentColor) {
                executeUserCommand("ما هو موديل جهازي؟")
              }
              QuickActionChip("💬 من أنت؟", currentAccentColor) {
                executeUserCommand("من أنت وما هي قدراتك؟")
              }
            }
          }
        }

        // Bottom Text Input & Mic Control Bar
        item {
          JarvisHudCard(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 16.dp),
            accentColor = currentAccentColor
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedTextField(
                value = textQueryInput,
                onValueChange = { textQueryInput = it },
                modifier = Modifier
                  .weight(1f)
                  .testTag("command_input_field"),
                placeholder = {
                  Text(
                    text = "اكتب لـ WEYKY أو اسأل...",
                    fontSize = 13.sp,
                    color = JarvisHudColors.TextMuted
                  )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                  onSend = {
                    if (textQueryInput.isNotBlank()) {
                      val q = textQueryInput
                      textQueryInput = ""
                      focusManager.clearFocus()
                      executeUserCommand(q)
                    }
                  }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = currentAccentColor,
                  unfocusedBorderColor = currentAccentColor.copy(alpha = 0.35f),
                  focusedTextColor = JarvisHudColors.TextPrimary,
                  unfocusedTextColor = JarvisHudColors.TextPrimary,
                  cursorColor = currentAccentColor
                )
              )

              IconButton(
                onClick = {
                  if (textQueryInput.isNotBlank()) {
                    val q = textQueryInput
                    textQueryInput = ""
                    focusManager.clearFocus()
                    executeUserCommand(q)
                  }
                },
                modifier = Modifier.testTag("send_command_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Send,
                  contentDescription = "Send",
                  tint = currentAccentColor
                )
              }

              IconButton(
                onClick = { toggleVoiceListening() },
                modifier = Modifier
                  .testTag("mic_voice_button")
                  .clip(CircleShape)
                  .background(if (isVoiceListening) JarvisHudColors.TacticalAmber else currentAccentColor.copy(alpha = 0.2f))
              ) {
                Icon(
                  imageVector = if (isVoiceListening) Icons.Default.MicOff else Icons.Default.Mic,
                  contentDescription = "Voice",
                  tint = if (isVoiceListening) JarvisHudColors.PitchBlack else currentAccentColor
                )
              }
            }
          }
        }
      }
    }
  }

  // Settings & Theme Presets Dialog
  if (showSettingsDialog) {
    Dialog(onDismissRequest = { showSettingsDialog = false }) {
      JarvisHudCard(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        accentColor = currentAccentColor,
        tabTitle = "SYSTEM CONFIG"
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = "PRESET ACCENT COLOR",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = currentAccentColor
          )

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            JarvisHudColors.BorderPresets.forEachIndexed { idx, pair ->
              val color = Color(pair.second)
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(color)
                  .clickable { selectedBorderIndex = idx },
                contentAlignment = Alignment.Center
              ) {
                if (selectedBorderIndex == idx) {
                  Box(
                    modifier = Modifier
                      .size(12.dp)
                      .clip(CircleShape)
                      .background(Color.White)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "BACKGROUND VOID",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = currentAccentColor
          )

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            JarvisHudColors.BackgroundPresets.take(6).forEachIndexed { idx, pair ->
              JarvisHudBadge(
                accentColor = if (selectedBgIndex == idx) currentAccentColor else JarvisHudColors.TextMuted,
                cutSize = 4.dp,
                onClick = { selectedBgIndex = idx }
              ) {
                Text(
                  text = pair.first,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  color = if (selectedBgIndex == idx) currentAccentColor else JarvisHudColors.TextSecondary,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          JarvisHudBadge(
            accentColor = currentAccentColor,
            modifier = Modifier.align(Alignment.End),
            onClick = { showSettingsDialog = false }
          ) {
            Text(
              text = "CLOSE [X]",
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = currentAccentColor,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun TelemetryMetricItem(
  label: String,
  value: String,
  sub: String,
  accentColor: Color
) {
  Column {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontSize = 9.sp,
      color = JarvisHudColors.TextMuted,
      letterSpacing = 1.sp
    )
    Text(
      text = value,
      fontFamily = FontFamily.Monospace,
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
      color = accentColor
    )
    Text(
      text = sub,
      fontFamily = FontFamily.Monospace,
      fontSize = 9.sp,
      color = JarvisHudColors.TextSecondary
    )
  }
}

@Composable
fun QuickActionChip(
  label: String,
  accentColor: Color,
  onClick: () -> Unit
) {
  JarvisHudBadge(
    accentColor = accentColor,
    cutSize = 6.dp,
    onClick = onClick,
    modifier = Modifier.testTag("quick_action_${label.filter { it.isLetterOrDigit() }}")
  ) {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontSize = 11.sp,
      color = JarvisHudColors.TextPrimary,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
    )
  }
}
