package com.example.core.voice.model

import com.example.core.voice.engine.EdgeNeuralTtsEngine

/**
 * High-definition Arabic neural voice catalog entry.
 */
data class ArabicVoicePreset(
  val flag: String,
  val name: String,
  val country: String,
  val gender: String,
  val voiceKey: String,
  val previewText: String
) {
  val fullLabel: String
    get() = "$flag $name ($country) - $gender"
}

object ArabicVoiceCatalog {
  val VOICES: List<ArabicVoicePreset> = listOf(
    ArabicVoicePreset(
      flag = "🇪🇬",
      name = "سلمى",
      country = "مصر",
      gender = "أنثى",
      voiceKey = EdgeNeuralTtsEngine.VOICE_SALMA_EGYPT,
      previewText = "مرحباً، أنا سلمى، مساعدك الذكي WEYKY."
    ),
    ArabicVoicePreset(
      flag = "🇸🇦",
      name = "حامد",
      country = "السعودية",
      gender = "ذكر",
      voiceKey = EdgeNeuralTtsEngine.VOICE_HAMED_SAUDI,
      previewText = "أهلاً بك، أنا حامد في خدمتك دائماً."
    ),
    ArabicVoicePreset(
      flag = "🇦🇪",
      name = "فاطمة",
      country = "الإمارات",
      gender = "أنثى",
      voiceKey = EdgeNeuralTtsEngine.VOICE_FATIMA_UAE,
      previewText = "مرحباً بك، أنا فاطمة، كيف أساعدك اليوم؟"
    ),
    ArabicVoicePreset(
      flag = "🇸🇦",
      name = "زارية",
      country = "السعودية",
      gender = "أنثى",
      voiceKey = EdgeNeuralTtsEngine.VOICE_ZARIYAH_SAUDI,
      previewText = "أهلاً، أنا زارية، نواتك الذكية."
    ),
    ArabicVoicePreset(
      flag = "🇹🇳",
      name = "هادي",
      country = "تونس",
      gender = "ذكر",
      voiceKey = EdgeNeuralTtsEngine.VOICE_HEDI_TUNISIA,
      previewText = "أهلاً بك، أنا هادي من تونس، في خدمتك."
    ),
    ArabicVoicePreset(
      flag = "🇹🇳",
      name = "ريم",
      country = "تونس",
      gender = "أنثى",
      voiceKey = EdgeNeuralTtsEngine.VOICE_REEM_TUNISIA,
      previewText = "مرحباً، أنا ريم، مستعدة لأي استفسار."
    )
  )

  fun findByKey(key: String): ArabicVoicePreset? {
    return VOICES.firstOrNull { it.voiceKey == key }
  }
}
