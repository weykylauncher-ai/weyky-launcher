package com.example.core.intent

import com.example.device.audio.VolumeAdjustment
import java.util.Locale

object IntentParser {
  fun normalize(raw: String): String {
    return raw.trim()
      .lowercase(Locale.ROOT)
      .replace(Regex("[\\u064B-\\u065F\\u0670]"), "") // Strip all tashkeel & shaddah
      .replace('أ', 'ا')
      .replace('إ', 'ا')
      .replace('آ', 'ا')
      .replace('ة', 'ه')
      .replace('ى', 'ي')
      .replace('ؤ', 'و')
      .replace('ئ', 'ي')
      .replace(Regex("[\\?\\!\\.\\,\\،\\:]"), " ")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  fun extractContactTarget(rawInput: String): String {
    var query = rawInput.trim()
    val wakePrefixes = listOf("hey weyky ", "هاي ويكي ", "يا ويكي ", "ويكي ", "weyky ", "يا مساعدي ", "مساعدي ")
    for (wp in wakePrefixes) {
      if (query.startsWith(wp, ignoreCase = true)) {
        query = query.substring(wp.length).trim()
        break
      }
    }
    val callPrefixes = listOf(
      "اتصل على ", "اتصل ب ", "اتصل بـ ", "اتصل ",
      "دق على ", "دق لـ ", "دق لي ", "دق ",
      "رن على ", "رن لي ", "خابر ", "اتصال ب ",
      "call ", "dial ", "phone "
    )
    for (prefix in callPrefixes) {
      if (query.startsWith(prefix, ignoreCase = true)) {
        query = query.substring(prefix.length).trim()
        break
      }
    }
    if (query.startsWith("بـ") && query.length > 2) {
      query = query.substring(2).trim()
    } else if (query.startsWith("ب") && query.length > 2 && !query.startsWith("بابا") && !query.startsWith("باسل")) {
      val withoutB = query.substring(1).trim()
      if (withoutB.isNotEmpty()) {
        query = withoutB
      }
    }
    return query.trim()
  }

  /**
   * Checks if input is directly a recognized prominent app name.
   */
  private fun isDirectAppNameQuery(input: String): Boolean {
    val directNames = setOf(
      "واتساب", "الواتساب", "واتس اب", "الواتس", "whatsapp", "whats app",
      "يوتيوب", "اليوتيوب", "youtube", "you tube",
      "تليجرام", "تليغرام", "التليجرام", "التليغرام", "telegram",
      "فيسبوك", "الفيسبوك", "فيس بوك", "facebook",
      "انستغرام", "الانستغرام", "انستقرام", "instagram",
      "تيك توك", "التيك توك", "tiktok",
      "سناب شات", "سناب", "snapchat",
      "كروم", "متصفح كروم", "chrome",
      "جيميل", "gmail",
      "سبوتيفاي", "spotify",
      "نتفلكس", "نتفليكس", "netflix",
      "الكاميرا", "كاميرا", "camera",
      "الاستوديو", "استوديو", "الصور", "صور", "gallery", "photos",
      "الخرائط", "maps",
      "الآلة الحاسبة", "الة حاسبة", "حاسبة", "الحاسبة", "calculator",
      "الساعة", "المنبه", "ساعة", "منبه", "clock",
      "شات جي بي تي", "شات جبت", "chatgpt", "chat gpt"
    )
    return directNames.contains(input)
  }

  /**
   * Extracts application name from an open command.
   * e.g. "افتح واتساب" -> "واتساب", "open WhatsApp" -> "WhatsApp"
   */
  fun extractAppName(rawInput: String): String {
    var query = rawInput.trim()
    val wakePrefixes = listOf("hey weyky ", "هاي ويكي ", "يا ويكي ", "ويكي ", "weyky ", "يا مساعدي ", "مساعدي ")
    for (wp in wakePrefixes) {
      if (query.startsWith(wp, ignoreCase = true)) {
        query = query.substring(wp.length).trim()
        break
      }
    }
    val openPrefixes = listOf(
      "افتح تطبيق ", "افتح لي تطبيق ", "افتح برنامج ", "افتح لي برنامج ",
      "شغل تطبيق ", "شغل برنامج ",
      "فتح تطبيق ", "فتح برنامج ", "افتح لي ", "افتح ",
      "شغل لي ", "شغل ",
      "بدء تطبيق ", "بدء ",
      "open app ", "open application ", "open ",
      "launch app ", "launch application ", "launch ",
      "start app ", "start application ", "start "
    )
    for (prefix in openPrefixes) {
      if (query.startsWith(prefix, ignoreCase = true)) {
        query = query.substring(prefix.length).trim()
        break
      }
    }
    return query.trim()
  }

  private fun extractVolumePercent(input: String): Int? {
    val converted = input.map { char ->
      when (char) {
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> char
      }
    }.joinToString("")

    if (converted.contains("%") || converted.contains("بالمئة") || converted.contains("بالمية") ||
        converted.contains("في المئة") || converted.contains("في المية") || converted.contains("percent")) {
      val regex = Regex("""(\d{1,3})""")
      val match = regex.find(converted)
      if (match != null) {
        val num = match.groupValues[1].toIntOrNull()
        if (num != null && num in 0..100) {
          return num
        }
      }
    }
    val hasSetVerb = converted.contains("اجعل") || converted.contains("خل") || converted.contains("اضبط") || converted.contains("set")
    if (hasSetVerb) {
      val regex = Regex("""(\d{1,3})""")
      val match = regex.find(converted)
      if (match != null) {
        val num = match.groupValues[1].toIntOrNull()
        if (num != null && num in 0..100) {
          return num
        }
      }
    }
    return null
  }

  private fun extractStepCount(input: String): Int {
    return when {
      input.contains("درجتين") || input.contains("خطوتين") || input.contains("مرتين") || input.contains("twice") || input.contains("2 times") || input.contains("2 steps") -> 2
      input.contains("3 درجات") || input.contains("ثلاث درجات") || input.contains("3 خطوات") || input.contains("3 times") || input.contains("3 steps") -> 3
      input.contains("4 درجات") || input.contains("أربع درجات") || input.contains("4 times") -> 4
      else -> 1
    }
  }

  fun parse(rawInput: String, session: com.example.core.intelligence.conversation.ConversationSession? = null): WeykyIntent {
    var input = normalize(rawInput)
    if (input.isBlank()) return WeykyIntent.UnknownIntent("")

    // 0. Wake phrase detection
    if (input == "hey weyky" || input == "هاي ويكي" || input == "يا ويكي" || input == "ويكي" || input == "weyky" || input == "استيقظ" || input == "مرحبا ويكي" || input == "اهلا ويكي") {
      return WeykyIntent.WakeIntent
    }

    // Strip leading wake phrase
    val wakePrefixes = listOf("hey weyky ", "هاي ويكي ", "يا ويكي ", "ويكي ", "weyky ", "يا مساعدي ", "مساعدي ")
    for (wp in wakePrefixes) {
      if (input.startsWith(wp)) {
        input = input.substring(wp.length).trim()
        break
      }
    }

    // 1. Semantic classification & disambiguation: Questions vs Commands vs Hypotheticals
    val classified = MessageIntentClassifier.classify(rawInput, session)
    when (classified.primarySubject) {
      "battery_music_impact" -> return WeykyIntent.HypotheticalBatteryMusicIntent
      "schedule_delay_impact" -> return WeykyIntent.HypotheticalScheduleDelayIntent(classified.extractedDelayMinutes ?: 10)
      "song_title_provided" -> {
        val title = classified.extractedSongTitle ?: rawInput
        return WeykyIntent.PlaySpecificSongIntent(title)
      }
      "request_song_title" -> return WeykyIntent.RequestSongTitleIntent
      "play_specific_song" -> {
        val title = classified.extractedSongTitle ?: rawInput
        return WeykyIntent.PlaySpecificSongIntent(title)
      }
      "user_identity" -> return WeykyIntent.UserIdentityIntent
      "phone_model" -> return WeykyIntent.PhoneModelIntent
      "device_detailed_specs" -> return WeykyIntent.DeviceInfoDetailedIntent
    }

    val isWeatherContext = session?.currentTopic == "weather" || session?.lastReferencedSubject == "weather"

    // Weather follow-ups
    if (input.contains("المساء") || input.contains("مساء اليوم") || input.contains("الليلة") || input.contains("هذا المساء") || input.contains("evening") || input.contains("tonight")) {
      if (input.contains("الطقس") || input.contains("الجو") || input.contains("حرارة") || input.contains("مطر") || isWeatherContext) {
        return WeykyIntent.WeatherIntent(WeatherQueryType.HOURLY_EVENING, rawInput)
      }
    }

    if ((input.contains("مطر") || input.contains("تمطر") || input.contains("أمطار") || input.contains("rain")) &&
      (input.contains("قريبا") || input.contains("قريباً") || input.contains("الساعتين") || input.contains("اليوم") || input.contains("القادمة") || input.contains("soon") || input.contains("hours"))
    ) {
      return WeykyIntent.WeatherIntent(WeatherQueryType.RAIN_SOON, rawInput)
    }

    if ((input.contains("رياح") || input.contains("هواء") || input.contains("عواصف") || input.contains("wind")) &&
      (input.contains("غدا") || input.contains("غداً") || input.contains("بكرة") || input.contains("باكر") || input.contains("tomorrow") || isWeatherContext)
    ) {
      return WeykyIntent.WeatherIntent(WeatherQueryType.WIND_TOMORROW, rawInput)
    }

    if (input.contains("مقارنة") || input.contains("اليوم وغدا") || (input.contains("الفرق") && (input.contains("اليوم") || input.contains("غدا") || input.contains("غداً")))) {
      if (input.contains("الطقس") || input.contains("الحرارة") || isWeatherContext) {
        return WeykyIntent.WeatherIntent(WeatherQueryType.COMPARE_TOMORROW, rawInput)
      }
    }

    if ((input.contains("مطر") || input.contains("أمطار") || input.contains("تمطر") || input.contains("rain")) &&
      (input.contains("الاسبوع") || input.contains("الأسبوع") || input.contains("هذا الاسبوع") || input.contains("week"))
    ) {
      return WeykyIntent.WeatherIntent(WeatherQueryType.WEEK_RAIN, rawInput)
    }

    if ((input.contains("مناسب للخروج") || input.contains("هل اخرج") || isWeatherContext) &&
      (input.contains("طقس") || input.contains("جو") || input.contains("مطر") || input.contains("برا"))
    ) {
      return WeykyIntent.WeatherIntent(WeatherQueryType.OUTDOOR_SUITABILITY, rawInput)
    }

    val isForRingtone = input.contains("النغمة") || input.contains("الرنين") || input.contains("الجرس") || input.contains("ringtone") || input.contains("ring")

    // Contextual Intelligence Domain Queries
    val req = com.example.core.intelligence.ContextRequirementsRegistry.resolve(input)
    if (req.domain != com.example.core.intelligence.IntentDomain.GENERAL &&
      req.domain != com.example.core.intelligence.IntentDomain.WEATHER_ONLY &&
      req.domain != com.example.core.intelligence.IntentDomain.DIRECT_COMMAND
    ) {
      return WeykyIntent.ContextualQueryIntent(rawQuery = rawInput, domain = req.domain)
    }

    return when {
      // 1. Settings, Wifi, Bluetooth commands
      input.contains("wifi") || input.contains("wi-fi") || input.contains("واي فاي") || input.contains("وايفاي") -> {
        WeykyIntent.WifiIntent(openSettings = true)
      }
      input.contains("bluetooth") || input.contains("بلوتوث") -> {
        WeykyIntent.BluetoothIntent
      }
      (input.contains("setting") || input.contains("إعدادات") || input.contains("اعدادات") || (input.contains("ضبط") && !input.contains("صوت"))) && !input.startsWith("افتح ") && !input.startsWith("open ") -> {
        when {
          input.contains("battery") || input.contains("بطارية") || input.contains("البطارية") -> WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.BATTERY)
          input.contains("display") || input.contains("screen") || input.contains("شاشة") || input.contains("الشاشة") -> WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.DISPLAY)
          input.contains("sound") || input.contains("audio") || input.contains("صوت") -> WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.SOUND)
          input.contains("app") || input.contains("تطبيقات") -> WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.APPS)
          else -> WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.GENERAL)
        }
      }
      // 2. Calls: Missed, Outgoing, Incoming, or Specific dial
      input.contains("آخر مكالمة صادرة") || input.contains("المكالمات الصادرة") || input.contains("مين رنيت") || input.contains("لمن اتصلت") || input.contains("last outgoing call") -> {
        WeykyIntent.CallIntent(queryType = CallQueryType.OUTGOING)
      }
      input.contains("آخر مكالمة واردة") || input.contains("المكالمات الواردة") || input.contains("مين اتصل") || input.contains("who called") -> {
        WeykyIntent.CallIntent(queryType = CallQueryType.INCOMING)
      }
      input.contains("سجل المكالمات") || input.contains("المكالمات الأخيرة") || input.contains("سجل الاتصال") -> {
        WeykyIntent.CallIntent(queryType = CallQueryType.ALL)
      }
      input.contains("missed call") || input.contains("مكالمة فائتة") || input.contains("المكالمات الفائتة") ||
      input.contains("مكالمات لم يرد عليها") || input.contains("مكالمات فائتة") || input.contains("فائتة") ||
      input.contains("مين رن علي") || input.contains("مين اتصل فيني") || input.contains("المكالمات الضائعة") -> {
        WeykyIntent.CallIntent(queryType = CallQueryType.MISSED, showMissed = true)
      }
      // Direct Dial
      input.startsWith("call ") || input.startsWith("dial ") ||
      input.startsWith("اتصل ") || input.startsWith("دق على ") || input.startsWith("اتصال بـ ") ||
      input.startsWith("اتصال ب ") || input.startsWith("رن على ") || input.startsWith("phone ") -> {
        val target = extractContactTarget(rawInput)
        WeykyIntent.CallIntent(target = target.ifBlank { null }, queryType = CallQueryType.DIAL_TARGET, showMissed = false)
      }
      // 3. Media Next / Previous Track
      input.contains("التالي") || input.contains("الأغنية التالية") || input.contains("المقطع التالي") ||
      input.contains("تخطي") || input.contains("next track") || input.contains("next song") || input.contains("skip track") ||
      input == "next" -> {
        WeykyIntent.MediaIntent(WeykyIntent.MediaAction.NEXT)
      }
      input.contains("السابق") || input.contains("الأغنية السابقة") || input.contains("المقطع السابق") ||
      input.contains("previous track") || input.contains("previous song") || input == "previous" -> {
        WeykyIntent.MediaIntent(WeykyIntent.MediaAction.PREVIOUS)
      }
      // 4. Volume / Audio with Incremental Steps & Percentage
      input.contains("volume") || input.contains("audio") || input.contains("sound") || input.contains("صوت") || input.contains("الصوت") -> {
        val percent = extractVolumePercent(input)
        val stepCount = extractStepCount(input)
        when {
          percent != null -> WeykyIntent.VolumePercentIntent(percent, forRingtone = isForRingtone)
          (input.contains("mute") && !input.contains("unmute")) || input.contains("كتم") || input.contains("اخرس") ->
            WeykyIntent.VolumeMuteIntent(mute = true, forRingtone = isForRingtone)
          input.contains("unmute") || input.contains("الغاء الكتم") || input.contains("إلغاء الكتم") ->
            WeykyIntent.VolumeMuteIntent(mute = false, forRingtone = isForRingtone)
          input.contains("up") || input.contains("raise") || input.contains("increase") || input.contains("louder") || input.contains("more") ||
          input.contains("ارفع") || input.contains("علي") || input.contains("زيد") || input.contains("أعلى") ->
            WeykyIntent.VolumeStepIntent(increase = true, stepCount = stepCount, forRingtone = isForRingtone)
          input.contains("down") || input.contains("lower") || input.contains("decrease") || input.contains("quieter") || input.contains("less") ||
          input.contains("اخفض") || input.contains("وطي") || input.contains("نقص") || input.contains("قصر") ->
            WeykyIntent.VolumeStepIntent(increase = false, stepCount = stepCount, forRingtone = isForRingtone)
          else -> WeykyIntent.VolumeStepIntent(increase = true, stepCount = 1, forRingtone = isForRingtone)
        }
      }
      // 5. Open Application Commands
      (input.startsWith("افتح ") || input.startsWith("شغل ") || input.startsWith("تشغيل ") ||
       input.startsWith("فتح ") || input.startsWith("open ") || input.startsWith("launch ") ||
       input.startsWith("start ") || isDirectAppNameQuery(input)) &&
      !input.contains("كشاف") && !input.contains("فلاش") && !input.contains("ضوء") &&
      !input.contains("torch") && !input.contains("flashlight") && !input.contains("music") -> {
        val appName = extractAppName(rawInput)
        if (appName.isNotBlank()) {
          WeykyIntent.OpenAppIntent(appName = appName)
        } else {
          WeykyIntent.UnknownIntent(rawInput)
        }
      }
      // 6. Media / Music Play/Pause/Toggle
      (input.contains("music") || input.contains("موسيقى") || input.contains("أغنية") || input.contains("صوت") ||
       input == "شغل" || input == "وقف" || input == "ايقاف" || input == "pause" || input == "play") &&
      (input.contains("pause") || input.contains("stop") || input.contains("play") || input.contains("resume") ||
       input.contains("ايقاف") || input.contains("أوقف") || input.contains("شغل") || input.contains("تابع")) -> {
        when {
          input.contains("pause") || input.contains("stop") || input.contains("ايقاف") || input.contains("أوقف") || input.contains("وقف") ->
            WeykyIntent.MediaIntent(WeykyIntent.MediaAction.PAUSE)
          input.contains("play") || input.contains("resume") || input.contains("شغل") || input.contains("تابع") ->
            WeykyIntent.MediaIntent(WeykyIntent.MediaAction.PLAY)
          else -> WeykyIntent.MediaIntent(WeykyIntent.MediaAction.TOGGLE)
        }
      }
      // 7. Battery
      input.contains("battery") || input.contains("charge") || input.contains("charging") ||
      input.contains("بطارية") || input.contains("البطارية") || input.contains("شحن") -> {
        if (input.contains("setting") || input.contains("إعدادات") || input.contains("اعدادات")) {
          WeykyIntent.SettingsIntent(WeykyIntent.SettingsType.BATTERY)
        } else {
          WeykyIntent.BatteryIntent
        }
      }
      // 8. Storage
      input.contains("storage") || input.contains("disk") || input.contains("free space") || input.contains("space left") ||
      input.contains("التخزين") || input.contains("المساحة") || input.contains("الذاكرة الداخلية") -> {
        WeykyIntent.StorageIntent
      }
      // 9. RAM
      input.contains("ram") || input.contains("memory") || input.contains("الرام") || input.contains("الذاكرة العشوائية") -> {
        WeykyIntent.RamIntent
      }
      // 10. Flashlight
      input.contains("flashlight") || input.contains("torch") || (input.contains("light") && !input.contains("sun")) ||
      input.contains("كشاف") || input.contains("الكشاف") || input.contains("فلاش") || input.contains("ضوء") -> {
        val turnOff = input.contains("off") || input.contains("stop") || input.contains("disable") ||
          input.contains("اطفاء") || input.contains("إطفاء") || input.contains("طفي") || input.contains("أغلق") || input.contains("اغلق")
        val turnOn = input.contains("on") || input.contains("enable") || input.contains("start") ||
          input.contains("تشغيل") || input.contains("شغل") || input.contains("ولع") || input.contains("اضئ") || input.contains("أشعل")
        if (turnOff) WeykyIntent.FlashlightIntent(turnOn = false)
        else if (turnOn) WeykyIntent.FlashlightIntent(turnOn = true)
        else WeykyIntent.FlashlightIntent(turnOn = true)
      }
      // 11. Notifications
      input.contains("notification") || input.contains("اشعارات") || input.contains("إشعارات") || input.contains("تنبيهات") -> {
        val openSettings = input.contains("setting") || input.contains("permission") || input.contains("access") ||
          input.contains("إعدادات") || input.contains("صلاحية") || input.contains("وصول")
        WeykyIntent.NotificationIntent(openSettings = openSettings)
      }
      // 12. Weather General
      input.contains("weather") || input.contains("forecast") || input.contains("rain") || input.contains("sunny") || input.contains("outside") ||
      input.contains("طقس") || input.contains("الطقس") || input.contains("الجو") || input.contains("حرارة") || input.contains("مطر") -> {
        WeykyIntent.WeatherIntent(WeatherQueryType.CURRENT, rawInput)
      }
      // 13. Time and Date
      input.contains("time") || input.contains("clock") || input.contains("date") || input.contains("today") ||
      input.contains("الساعة") || input.contains("الوقت") || input.contains("التاريخ") || input.contains("اليوم") -> {
        WeykyIntent.TimeIntent
      }
      // 14. Context
      input.contains("context") || input.contains("where am i") || input.contains("in pocket") || input.contains("on table") ||
      input.contains("في الجيب") || input.contains("على الطاولة") || input.contains("وضعي") || input.contains("سياق") -> {
        WeykyIntent.ContextIntent
      }
      // 15. Device specs
      input.contains("device") || input.contains("phone") || input.contains("status") || input.contains("specs") || input.contains("info") ||
      input.contains("جهازي") || input.contains("الهاتف") || input.contains("مواصفات") -> {
        WeykyIntent.DeviceInfoIntent
      }
      // 16. Help
      input.contains("help") || input.contains("what can you do") || input.contains("features") || input.contains("hello") || input.contains("hi") ||
      input.contains("مساعدة") || input.contains("تعليمات") || input.contains("ماذا تفعل") || input.contains("اوامرك") -> {
        WeykyIntent.HelpIntent
      }
      else -> WeykyIntent.ConversationalIntent(rawInput)
    }
  }
}
