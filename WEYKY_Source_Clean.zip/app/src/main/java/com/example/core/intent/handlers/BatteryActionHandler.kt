package com.example.core.intent.handlers

import com.example.core.intent.ExecutionResult
import com.example.device.battery.BatteryProvider
import com.example.device.battery.ChargingState
import com.example.rendering.visual_state.CoreVisualState
import java.util.Locale

class BatteryActionHandler(private val batteryProvider: BatteryProvider) {
  fun handle(): ExecutionResult {
    val b = batteryProvider.queryCurrentBattery()
      ?: return ExecutionResult.Unavailable("بيانات البطارية غير متوفرة على هذا الجهاز.")
    if (!b.isAvailable || b.percentage < 0) {
      return ExecutionResult.Unavailable("معلومات البطارية غير متاحة حالياً.")
    }
    val isArabic = Locale.getDefault().language.startsWith("ar")
    if (isArabic) {
      val chargingText = when (b.chargingState) {
        ChargingState.CHARGING -> "والهاتف قيد الشحن حالياً"
        ChargingState.FULL -> "والشحن مكتمل تماماً"
        ChargingState.DISCHARGING -> "والهاتف غير متصل بالشاحن"
        ChargingState.NOT_CHARGING -> "وليس قيد الشحن"
        ChargingState.UNKNOWN -> ""
      }
      val text = "مستوى البطارية هو ${b.percentage}% $chargingText."
      return ExecutionResult.Success(
        speech = text,
        actionTaken = "Queried Battery ($chargingText)",
        visualState = CoreVisualState.RESPONDING
      )
    }
    val chargingText = when (b.chargingState) {
      ChargingState.CHARGING -> "charging via ${b.powerSource.name}"
      ChargingState.FULL -> "fully charged"
      ChargingState.DISCHARGING -> "discharging"
      ChargingState.NOT_CHARGING -> "not charging"
      ChargingState.UNKNOWN -> "battery status unknown"
    }
    val text = "Battery is at ${b.percentage}%, $chargingText."
    return ExecutionResult.Success(
      speech = text,
      actionTaken = "Queried Battery ($chargingText)",
      visualState = CoreVisualState.RESPONDING
    )
  }
}
