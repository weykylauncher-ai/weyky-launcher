package com.example.core.intelligence.conversation

import java.util.Locale

/**
 * Local on-device structured knowledge base and reasoning bank.
 * Provides curated knowledge across science, geography, history, daily life,
 * culture, productivity, mathematics, and language in both Arabic and English.
 */
object LocalKnowledgeBase {

  data class KnowledgeTopic(
    val id: String,
    val keywords: List<String>,
    val arabicSummary: String,
    val englishSummary: String,
    val suggestedFollowUps: List<ActionableOption>
  )

  private val topics = listOf(
    // 1. Identity & WEYKY purpose
    KnowledgeTopic(
      id = "identity",
      keywords = listOf("من أنت", "ما أنت", "عرف بنفسك", "مين انت", "اسمك", "who are you", "what are you", "مساعد", "عن weyky", "ماهو weyky", "برنامج weyky"),
      arabicSummary = "أنا WEYKY (ويكي)، نواتك الذكية على جهازك. أعمل محلياً لتحليل سياق يومك، والتحكم بوظائف هاتفك، والإجابة عن استفساراتك باحترام كامل لخصوصيتك وسرعة فورية.",
      englishSummary = "I am Weyky, your contextual intelligent assistant on this device. I work locally to help you understand your daily context, manage your device, reason together, and provide helpful insights.",
      suggestedFollowUps = listOf(
        ActionableOption("ماذا تستطيع أن تفعل؟", "ماذا تستطيع أن تفعل؟"),
        ActionableOption("تفاصيل عن جهازي", "تفاصيل جهازي"),
        ActionableOption("ما وضعي الآن؟", "ما وضعي الآن؟")
      )
    ),
    // 2. Capabilities
    KnowledgeTopic(
      id = "capabilities",
      keywords = listOf("ماذا تفعل", "ميزاتك", "قدراتك", "شو بتعرف تسوي", "what can you do", "features", "أوامرك", "مساعدتي"),
      arabicSummary = "أستطيع مساعدتك في:\n1. التحكم بالهاتف (فتح التطبيقات، الكشاف، مستوى الصوت، الموسيقى، المكالمات).\n2. التحليل التنبؤي والسياقي (الطقس، البطارية، المواعيد، وتقديم نصائح الخروج).\n3. الحوار المنطقي، الحسابات الرياضية، وتقديم نصائح إنتاجية وصحية.",
      englishSummary = "I can assist you with:\n1. Device controls (apps, flashlight, audio volume, media, calls).\n2. Real-time situational analysis (weather, battery, appointments, departure advice).\n3. Conversational reasoning, calculations, productivity habits, and answering diverse knowledge questions completely offline.",
      suggestedFollowUps = listOf(
        ActionableOption("حالة البطارية", "حالة البطارية"),
        ActionableOption("توقعات الطقس", "توقعات الطقس"),
        ActionableOption("احسب 25 * 4", "احسب 25 * 4")
      )
    ),
    // 3. Sleep & Health
    KnowledgeTopic(
      id = "sleep_wellness",
      keywords = listOf("نصائح نوم", "أرق", "صعوبة نوم", "كيف أنام", "صحة النوم", "sleep", "insomnia", "تعبان", "ارهاق"),
      arabicSummary = "للحصول على نوم عميق ومريح، ينصح الخبراء بـ:\n1. الالتزام بموعد نوم واستيقاظ ثابت يومياً.\n2. إيقاف الشاشات ذات الضوء الأزرق قبل النوم بنصف ساعة على الأقل.\n3. الحفاظ على غرفة نوم مظلمة وباردة نسبياً (~18-20°م).\n4. تجنب المنبهات والوجبات الثقيلة في الساعات المتأخرة من الليل.",
      englishSummary = "To achieve deep and restorative sleep, experts recommend:\n1. Keeping a consistent bedtime and wake-up schedule.\n2. Avoiding blue light screens at least 30 minutes before sleep.\n3. Keeping your bedroom cool and dark (around 18-20°C).\n4. Avoiding caffeine and heavy meals late in the evening.",
      suggestedFollowUps = listOf(
        ActionableOption("أغلق الكشاف", "أغلق الكشاف"),
        ActionableOption("موفر الطاقة", "تفعيل موفر الطاقة"),
        ActionableOption("نصيحة قهوة", "متى أتوقف عن شرب القهوة؟")
      )
    ),
    // 4. Productivity & Time Management (Pomodoro etc.)
    KnowledgeTopic(
      id = "productivity",
      keywords = listOf("زيادة الانتاجية", "إدارة الوقت", "بومودورو", "تنظيم الوقت", "تركيز", "productivity", "time management", "pomodoro", "انجح", "كيف اركز", "تنظيم يومي", "خطة يومية", "انجاز"),
      arabicSummary = "لرفع إنتاجيتك وتركيزك:\n1. تقنية بومودورو: 25 دقيقة تركيز تام تليها 5 دقائق استراحة.\n2. قاعدة إنجاز الضفدع (Eat the Frog): ابدأ بأصعب مهمة وأهمها في بداية يومك.\n3. مصفوفة أيزنهاور: فرّق بين العاجل والمهم، وتخلص من المشتتات.\n4. قسّم المشاريع الكبيرة إلى خطوات صغيرة محددة.",
      englishSummary = "To boost your productivity and focus:\n1. The Pomodoro Technique: 25 minutes of deep work followed by a 5-minute break.\n2. Eat That Frog: Tackle your most demanding task first thing in the morning.\n3. Eisenhower Matrix: Distinguish between urgent and important, eliminate distractions.\n4. Break large projects into bite-sized, immediate action steps.",
      suggestedFollowUps = listOf(
        ActionableOption("نصيحة ثانية", "نصيحة إنتاجية أخرى"),
        ActionableOption("جدول اليوم", "ما هي مواعيدي؟"),
        ActionableOption("فتح التقويم", "افتح التقويم")
      )
    ),
    // 5. Artificial Intelligence & Local Processing
    KnowledgeTopic(
      id = "ai_concept",
      keywords = listOf("الذكاء الاصطناعي", "ai", "artificial intelligence", "ما هو الذكاء الاصطناعي", "تعلم الالة", "machine learning", "محلي", "خصوصية"),
      arabicSummary = "الذكاء الاصطناعي هو محاكاة للقدرات الذهنية البشرية كالتعلم والاستنتاج وفهم اللغة. يتميز WEYKY بالذكاء المحلي (On-Device Intelligence) الذي يعمل مباشرة على هاتفك لحفظ خصوصيتك وسرعة المعالجة الفورية.",
      englishSummary = "Artificial Intelligence simulates human cognitive capabilities such as learning, deduction, and natural language comprehension. In WEYKY, contextual reasoning and on-device knowledge are integrated locally for maximum privacy and instant speed without relying on external servers.",
      suggestedFollowUps = listOf(
        ActionableOption("ميزات الأمان", "ما ميزات خصوصيتي؟"),
        ActionableOption("فحص الجهاز", "تفاصيل جهازي")
      )
    ),
    // 6. Geography: Capitals & Countries
    KnowledgeTopic(
      id = "capitals_arab",
      keywords = listOf("عاصمة", "عواصم", "السعودية", "مصر", "عمان", "الإمارات", "الكويت", "قطر", "فرنسا", "بريطانيا", "اليابان", "capital"),
      arabicSummary = "أهم العواصم:\n- السعودية: الرياض\n- الإمارات: أبوظبي\n- مصر: القاهرة\n- سلطنة عمان: مسقط\n- قطر: الدوحة\n- الكويت: مدينة الكويت\n- فرنسا: باريس\n- بريطانيا: لندن\n- اليابان: طوكيو",
      englishSummary = "Key world capitals:\n- Saudi Arabia: Riyadh\n- UAE: Abu Dhabi\n- Egypt: Cairo\n- Oman: Muscat\n- Qatar: Doha\n- Kuwait: Kuwait City\n- France: Paris\n- United Kingdom: London\n- Japan: Tokyo",
      suggestedFollowUps = listOf(
        ActionableOption("عن صلالة", "حدثني عن صلالة"),
        ActionableOption("الطقس المحلي", "كيف الطقس الآن؟")
      )
    ),
    // 7. Salalah & Tourism / Seasonal Travel
    KnowledgeTopic(
      id = "salalah_tourism",
      keywords = listOf("صلالة", "ظفار", "خريف صلالة", "سياحة عمان", "خريف", "salalah"),
      arabicSummary = "صلالة هي درة محافظة ظفار في سلطنة عمان. تشتهر بموسم الخريف الاستثنائي (أواخر يونيو حتى سبتمبر) حيث تكتسي الجبال بالخضرة ويتساقط الرذاذ بدرجات حرارة معتدلة (~25°م). من أشهر معالمها: وادي دربات، عين أثوم، وشاطئ المغسيل.",
      englishSummary = "Salalah is the jewel of Dhofar, Oman. It is famous for the 'Khareef' monsoon season (late June to September), when the mountains turn lush green under refreshing mist and cool temperatures around 25°C. Top attractions include Wadi Darbat, Ayn Athum, and Mughsail Beach.",
      suggestedFollowUps = listOf(
        ActionableOption("طقس الخريف", "كيف يكون الطقس في خريف صلالة؟"),
        ActionableOption("أفضل وقت للزيارة", "متى أفضل وقت لزيارة صلالة؟")
      )
    ),
    // 8. Science: Speed of light, Solar System, Gravity
    KnowledgeTopic(
      id = "physics_universe",
      keywords = listOf("سرعة الضوء", "المجموعة الشمسية", "الجاذبية", "الكون", "الشمس", "speed of light", "solar system", "gravity", "فيزياء"),
      arabicSummary = "حقائق علمية مذهلة:\n- سرعة الضوء في الفراغ تقارب 300,000 كم/ثانية (299,792 كم/ث).\n- يستغرق ضوء الشمس حوالي 8 دقائق و20 ثانية ليصل للأرض.\n- يضم نظامنا الشمسي 8 كواكب رئيسية، المشتري أكبرها وعطارد أقربها للشمس.\n- الجاذبية هي القوة التي تحافظ على مسار الكواكب حول الشمس وتماسك الغلاف الجوي.",
      englishSummary = "Fascinating cosmic facts:\n- The speed of light in a vacuum is approximately 300,000 km/s (299,792 km/s).\n- Sunlight takes about 8 minutes and 20 seconds to reach Earth.\n- Our solar system contains 8 recognized planets, Jupiter being the largest and Mercury closest to the Sun.\n- Gravity is the fundamental attraction keeping planets in orbit and holding our atmosphere.",
      suggestedFollowUps = listOf(
        ActionableOption("حساب مسافة دقيقة ضوئية", "احسب 300000 * 60"),
        ActionableOption("سؤال علمي آخر", "ما هي الجاذبية؟")
      )
    ),
    // 9. Short Inspirational Story / Wisdom
    KnowledgeTopic(
      id = "short_story",
      keywords = listOf("قصة", "قصة قصيرة", "حكمة", "حكاية", "خبرني قصة", "tell me a story", "عبرة", "موعظة", "قصة ملهمة"),
      arabicSummary = "سُئل مزارع حكيم عن سر فوزه السنوي بجائزة أفضل محصول ذرة مع مشاركته لأجود بذوره مع جيرانه. فقال: 'الرياح تنقل حبوب اللقاح بين حقولنا؛ فإن زرع جيراني حبوباً رديئة ستتدهور جودة محصولي، وبمساعدتهم على النجاح أحمي محصولي'. العبرة: نجاحنا الحقيقي يزدهر عندما نساعد من حولنا على النجاح.",
      englishSummary = "A wise farmer was asked why he always shared his finest seeds with his neighbors. He smiled and said: 'The wind carries pollen from field to field. If my neighbors grow inferior grain, cross-pollination will degrade my own crops. By helping them succeed, I enrich my harvest.' Lesson: True excellence thrives when everyone around us prospers.",
      suggestedFollowUps = listOf(
        ActionableOption("قصة أخرى", "قصة ثانية"),
        ActionableOption("حكمة اليوم", "حكمة اليوم")
      )
    ),
    // 10. Healthy Habits & Water
    KnowledgeTopic(
      id = "hydration_health",
      keywords = listOf("شرب الماء", "فوائد الماء", "كمية الماء", "صحة الجسم", "water intake", "رياضة", "عادات صحية"),
      arabicSummary = "يشكل الماء حوالي 60% من وزن جسم الإنسان، وهو ضروري لوظائف الدماغ وحيوية الدورة الدموية وتنظيم الحرارة. يوصى بشرب 2 إلى 3 لترات يومياً (نحو 8 أكواب)، وتزداد الكمية في الأجواء الحارة أو عند ممارسة الرياضة.",
      englishSummary = "Water constitutes about 60% of body weight and is critical for brain function, circulation, and temperature regulation. It is recommended to drink 2 to 3 liters daily (around 8 glasses), increasing during hot weather or physical exercise.",
      suggestedFollowUps = listOf(
        ActionableOption("نصائح النوم", "نصائح للنوم العميق"),
        ActionableOption("فحص البطارية", "حالة البطارية")
      )
    ),
    // 11. Battery & Device Care
    KnowledgeTopic(
      id = "battery_care",
      keywords = listOf("الحفاظ على البطارية", "عمر البطارية", "اطالة عمر البطارية", "battery health", "صحة البطارية", "توفير الشحن"),
      arabicSummary = "لإطالة العمر الافتراضي لبطارية هاتفك:\n1. حافظ على مستوى الشحن بين 20% و80%، وتجنب نفادها تماماً.\n2. تجنب تعريض الهاتف للحرارة الشديدة أو أشعة الشمس المباشرة أثناء الشحن.\n3. قلل سطوع الشاشة واستخدم الوضع الداكن (Dark Mode).\n4. أوقف البلوتوث وتحديد الموقع عند عدم الحاجة لهما.",
      englishSummary = "To maximize your phone's battery lifespan:\n1. Keep charge levels between 20% and 80%, avoiding complete depletion.\n2. Avoid exposing your device to high heat or direct sunlight while charging.\n3. Lower screen brightness and use Dark Mode.\n4. Disable Bluetooth and GPS when not in active use.",
      suggestedFollowUps = listOf(
        ActionableOption("فحص بطاريتي", "حالة البطارية"),
        ActionableOption("تفعيل موفر الطاقة", "تفعيل موفر الطاقة")
      )
    )
  )

  fun normalizeArabic(raw: String): String {
    return raw.trim()
      .lowercase(Locale.ROOT)
      .replace('أ', 'ا')
      .replace('إ', 'ا')
      .replace('آ', 'ا')
      .replace('ة', 'ه')
      .replace('ى', 'ي')
      .replace('ؤ', 'و')
      .replace('ئ', 'ي')
      .replace('،', ' ')
      .replace('؟', ' ')
      .replace('!', ' ')
      .replace('.', ' ')
      .replace(',', ' ')
  }

  fun findMatchingTopic(query: String): KnowledgeTopic? {
    val normQuery = normalizeArabic(query)
    for (topic in topics) {
      for (kw in topic.keywords) {
        val normKw = normalizeArabic(kw)
        if (normQuery.contains(normKw)) {
          return topic
        }
      }
    }
    return null
  }

  fun evaluateArithmetic(raw: String): String? {
    val clean = raw.replace("احسب", "")
      .replace("كم حاصل", "")
      .replace("ما نتيجة", "")
      .replace("calculate", "", ignoreCase = true)
      .replace("math", "", ignoreCase = true)
      .replace("ضرب", "*")
      .replace("في", "*")
      .replace("×", "*")
      .replace("زائد", "+")
      .replace("ناقص", "-")
      .replace("تقسيم", "/")
      .replace("على", "/")
      .replace("÷", "/")
      .replace("x", "*", ignoreCase = true)
      .replace("X", "*")
      .trim()

    val regex = Regex("""([0-9]+(?:\.[0-9]+)?)\s*([\+\-\*\/])\s*([0-9]+(?:\.[0-9]+)?)""")
    val match = regex.find(clean) ?: return null
    val (num1Str, op, num2Str) = match.destructured
    val n1 = num1Str.toDoubleOrNull() ?: return null
    val n2 = num2Str.toDoubleOrNull() ?: return null
    val res = when (op) {
      "+" -> n1 + n2
      "-" -> n1 - n2
      "*" -> n1 * n2
      "/" -> if (n2 != 0.0) n1 / n2 else return "لا يمكن القسمة على صفر"
      else -> return null
    }
    val isArabic = Locale.getDefault().language.startsWith("ar")
    val formattedResult = if (res == res.toLong().toDouble()) res.toLong().toString() else String.format(Locale.US, "%.2f", res)
    return if (isArabic) {
      "النتيجة: $num1Str $op $num2Str = $formattedResult"
    } else {
      "Result: $num1Str $op $num2Str = $formattedResult"
    }
  }
}
