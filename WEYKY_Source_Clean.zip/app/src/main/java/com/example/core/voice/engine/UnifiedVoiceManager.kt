package com.example.core.voice.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import com.example.core.voice.model.VoiceModelManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class ActiveSttEngineType {
  NONE,
  SYSTEM_ONLINE,
  SYSTEM_ON_DEVICE,
  VOSK_LOCAL_OFFLINE
}

enum class ActiveTtsEngineType {
  NONE,
  HYBRID_CLOUD_EDGE,
  SYSTEM_ENGINE,
  LOCAL_ENGINE
}

data class VoiceEngineStatus(
  val sttEngine: ActiveSttEngineType,
  val ttsEngine: ActiveTtsEngineType,
  val isOnline: Boolean,
  val isArabicSttSupported: Boolean,
  val isArabicTtsSupported: Boolean,
  val isOfflineSttReady: Boolean,
  val isOfflineModelInstalled: Boolean,
  val installedModelName: String?,
  val systemRecognizerPackage: String?,
  val activeTtsPackage: String?
)

/**
 * Unified Voice Engine Coordinator separating STT, TTS, Online, Offline,
 * and reporting real system status without false claims.
 */
class UnifiedVoiceManager(
  private val context: Context,
  val modelManager: VoiceModelManager = VoiceModelManager(context),
  val ttsInspector: TtsEngineInspector = TtsEngineInspector(context)
) {
  private val _status = MutableStateFlow(computeCurrentStatus())
  val status: StateFlow<VoiceEngineStatus> = _status.asStateFlow()

  fun refresh() {
    modelManager.refreshStatus()
    _status.value = computeCurrentStatus()
  }

  fun isNetworkConnected(): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val activeNetwork = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
    val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    if (!hasInternet) return false
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } else {
      true
    }
  }

  fun hasAnyInternetInterface(): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val activeNetwork = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
  }

  fun findInstalledRecognitionServices(): List<String> {
    val pm = context.packageManager
    val intent = Intent(RecognitionService.SERVICE_INTERFACE)
    val services = pm.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY)
    return services.map { it.serviceInfo.packageName }
  }

  fun hasUsableSystemRecognizerForLanguage(languageLocale: String? = null): Boolean {
    if (!isSystemRecognitionAvailable()) return false
    val services = findInstalledRecognitionServices()
    if (services.isEmpty()) {
      val isHuaweiDevice = Build.MANUFACTURER.equals("HUAWEI", ignoreCase = true) ||
        Build.BRAND.equals("HUAWEI", ignoreCase = true) ||
        Build.BRAND.equals("HONOR", ignoreCase = true)
      return !isHuaweiDevice
    }
    val hasGoogleOrSamsungOrAospService = services.any { pkg ->
      val lower = pkg.lowercase(Locale.ROOT)
      lower.contains("google") ||
        lower.contains("samsung") ||
        lower.contains("honeyboard") ||
        lower.contains("bixby") ||
        lower.contains("android.as")
    }
    if (hasGoogleOrSamsungOrAospService) return true

    val requestedLang = (languageLocale ?: Locale.getDefault().language).lowercase(Locale.ROOT)
    val isArabicRequest = requestedLang.startsWith("ar")
    val hasOnlyHuaweiProprietaryServices = services.all { pkg ->
      val lower = pkg.lowercase(Locale.ROOT)
      lower.contains("huawei") || lower.contains("hiai") || lower.contains("hivoice") || lower.contains("vassistant") || lower.contains("honor")
    }

    if (isArabicRequest && hasOnlyHuaweiProprietaryServices) {
      return false
    }
    return true
  }

  fun isSystemRecognitionAvailable(): Boolean {
    return SpeechRecognizer.isRecognitionAvailable(context)
  }

  fun isSystemOnDeviceRecognitionAvailable(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
      SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
  }

  fun getInstalledOfflineSttModel(languageLocale: String? = null): com.example.core.voice.model.VoiceModelInfo? {
    val normalizedLang = languageLocale?.lowercase(Locale.ROOT)?.substringBefore("-")?.substringBefore("_")
    return VoiceModelManager.CATALOG.firstOrNull { info ->
      val isStt = info.type == com.example.core.voice.model.VoiceModelType.STT
      val langMatches = normalizedLang == null || info.languageCode.lowercase(Locale.ROOT) == normalizedLang
      isStt && langMatches && modelManager.isModelInstalled(info)
    }
  }

  fun getInstalledOfflineTtsModel(languageLocale: String? = "ar"): com.example.core.voice.model.VoiceModelInfo? {
    val preferredId = modelManager.getActiveTtsModelId()
    val preferred = VoiceModelManager.CATALOG.firstOrNull {
      it.id == preferredId && it.type == com.example.core.voice.model.VoiceModelType.TTS && modelManager.isModelInstalled(it)
    }
    if (preferred != null) return preferred
    val normalizedLang = languageLocale?.lowercase(Locale.ROOT)?.substringBefore("-")?.substringBefore("_")
    return VoiceModelManager.CATALOG.firstOrNull { info ->
      val isTts = info.type == com.example.core.voice.model.VoiceModelType.TTS
      val langMatches = normalizedLang == null || info.languageCode.lowercase(Locale.ROOT) == normalizedLang
      isTts && langMatches && modelManager.isModelInstalled(info)
    }
  }

  private fun computeCurrentStatus(): VoiceEngineStatus {
    val online = isNetworkConnected()
    val services = findInstalledRecognitionServices()
    val systemRecognizerPkg = services.firstOrNull()
    val hasSystemRecognizer = isSystemRecognitionAvailable()
    val currentLocaleLang = Locale.getDefault().language
    val usableSystemRecognizer = hasUsableSystemRecognizerForLanguage(currentLocaleLang)
    val installedForLocale = getInstalledOfflineSttModel(currentLocaleLang)
    val anyInstalledOfflineModel = getInstalledOfflineSttModel(null)
    val effectiveOfflineModel = installedForLocale ?: anyInstalledOfflineModel
    val isOfflineModelInstalled = anyInstalledOfflineModel != null

    val sttEngine = when {
      online && usableSystemRecognizer -> ActiveSttEngineType.SYSTEM_ONLINE
      effectiveOfflineModel != null -> ActiveSttEngineType.VOSK_LOCAL_OFFLINE
      isSystemOnDeviceRecognitionAvailable() -> ActiveSttEngineType.SYSTEM_ON_DEVICE
      (online || hasAnyInternetInterface()) && hasSystemRecognizer -> ActiveSttEngineType.SYSTEM_ONLINE
      else -> ActiveSttEngineType.NONE
    }

    val installedNeuralTtsModel = getInstalledOfflineTtsModel("ar")
    val defaultTtsPkg = ttsInspector.getDefaultEngineName()
    val hasTtsEngines = ttsInspector.getInstalledEngines().isNotEmpty()

    val ttsEngine = when {
      online -> ActiveTtsEngineType.HYBRID_CLOUD_EDGE
      installedNeuralTtsModel != null -> ActiveTtsEngineType.LOCAL_ENGINE
      hasTtsEngines -> ActiveTtsEngineType.SYSTEM_ENGINE
      else -> ActiveTtsEngineType.LOCAL_ENGINE
    }

    val activeTtsLabel = when {
      online -> "سحابي عصبي (Edge Neural) + محلي"
      installedNeuralTtsModel != null -> "محلي عصبي (Piper VITS): ${installedNeuralTtsModel.nameArabic}"
      hasTtsEngines -> "محرك النظام: $defaultTtsPkg"
      else -> "محلي مدمج"
    }

    return VoiceEngineStatus(
      sttEngine = sttEngine,
      ttsEngine = ttsEngine,
      isOnline = online,
      isArabicSttSupported = (online && usableSystemRecognizer) ||
        getInstalledOfflineSttModel("ar") != null ||
        isSystemOnDeviceRecognitionAvailable(),
      isArabicTtsSupported = true,
      isOfflineSttReady = isOfflineModelInstalled || isSystemOnDeviceRecognitionAvailable(),
      isOfflineModelInstalled = isOfflineModelInstalled,
      installedModelName = effectiveOfflineModel?.nameArabic,
      systemRecognizerPackage = systemRecognizerPkg,
      activeTtsPackage = activeTtsLabel
    )
  }
}
