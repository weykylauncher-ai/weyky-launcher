package com.example.core.voice.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.util.Log
import com.example.core.intent.SpeechResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

/**
 * Embedded On-Device Native Arabic Speech Synthesizer.
 * Functions independently of Google Play Services and system TTS engines.
 */
class LocalArabicTtsEngine(
  private val context: Context,
  private val onSpeechStateChanged: ((Boolean) -> Unit)? = null
) {
  companion object {
    private const val TAG = "WEYKY_LOCAL_TTS"
    const val DEFAULT_SAMPLE_RATE = 16000
    private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_OUT_MONO
    private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
  }

  private val coroutineScope = CoroutineScope(Dispatchers.Default)
  private var playbackJob: Job? = null
  private var currentAudioTrack: AudioTrack? = null
  private var activeModelDir: File? = null

  @Volatile
  var isPlaying: Boolean = false
    private set

  val isModelLoaded: Boolean
    get() = activeModelDir?.exists() == true

  fun loadModel(modelDir: File): Boolean {
    if (!modelDir.exists() || !modelDir.isDirectory) {
      Log.w(TAG, "Cannot load local TTS model: directory not found: ${modelDir.absolutePath}")
      return false
    }
    activeModelDir = modelDir
    Log.i(TAG, "Local Arabic TTS model loaded from ${modelDir.absolutePath}")
    return true
  }

  fun speak(text: String, flush: Boolean = true): SpeechResult {
    if (text.isBlank()) return SpeechResult.Skipped
    if (flush) {
      stop()
    }

    val vocalizedText = ArabicTextDiacritizer.prepareAndDiacritize(text)
    Log.i(TAG, "Synthesizing text: \"$vocalizedText\" (original: \"$text\")")

    playbackJob = coroutineScope.launch {
      try {
        isPlaying = true
        onSpeechStateChanged?.invoke(true)
        val pcmData = generatePcmForText(vocalizedText)
        if (!isActive) return@launch
        playPcmAudio(pcmData)
      } catch (e: Exception) {
        Log.e(TAG, "Local TTS playback failed", e)
      } finally {
        isPlaying = false
        onSpeechStateChanged?.invoke(false)
      }
    }
    return SpeechResult.Success
  }

  fun stop() {
    playbackJob?.cancel()
    playbackJob = null
    try {
      currentAudioTrack?.apply {
        if (playState == AudioTrack.PLAYSTATE_PLAYING) {
          pause()
          flush()
          stop()
        }
        release()
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error stopping AudioTrack", e)
    } finally {
      currentAudioTrack = null
      if (isPlaying) {
        isPlaying = false
        onSpeechStateChanged?.invoke(false)
      }
    }
  }

  fun shutdown() {
    stop()
    activeModelDir = null
  }

  private suspend fun playPcmAudio(pcmData: ByteArray) = withContext(Dispatchers.IO) {
    if (pcmData.isEmpty()) return@withContext
    val bufferSize = AudioTrack.getMinBufferSize(
      DEFAULT_SAMPLE_RATE,
      CHANNEL_CONFIG,
      AUDIO_FORMAT
    ).coerceAtLeast(pcmData.size)

    val audioAttributes = AudioAttributes.Builder()
      .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
      .apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          setUsage(AudioAttributes.USAGE_ASSISTANT)
        } else {
          setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
        }
      }
      .build()

    val audioFormat = AudioFormat.Builder()
      .setSampleRate(DEFAULT_SAMPLE_RATE)
      .setChannelMask(CHANNEL_CONFIG)
      .setEncoding(AUDIO_FORMAT)
      .build()

    val track = AudioTrack.Builder()
      .setAudioAttributes(audioAttributes)
      .setAudioFormat(audioFormat)
      .setBufferSizeInBytes(bufferSize)
      .setTransferMode(AudioTrack.MODE_STREAM)
      .build()

    currentAudioTrack = track
    try {
      track.play()
      var offset = 0
      val chunkSize = 4096
      while (offset < pcmData.size && coroutineScope.isActive) {
        val bytesToWrite = (pcmData.size - offset).coerceAtMost(chunkSize)
        val written = track.write(pcmData, offset, bytesToWrite)
        if (written <= 0) break
        offset += written
      }
    } finally {
      try {
        track.stop()
        track.release()
      } catch (_: Exception) {}
      if (currentAudioTrack == track) {
        currentAudioTrack = null
      }
    }
  }

  private fun generatePcmForText(vocalizedText: String): ByteArray {
    val sampleRate = DEFAULT_SAMPLE_RATE
    val phonemes = breakIntoPhonemicSegments(vocalizedText)
    val totalSamples = phonemes.sumOf { (it.durationMs * sampleRate) / 1000 }
    val buffer = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
    var phase = 0.0

    for (seg in phonemes) {
      val numSamples = (seg.durationMs * sampleRate) / 1000
      val fundamentalFreq = seg.f0
      val f1 = seg.f1
      val f2 = seg.f2

      for (i in 0 until numSamples) {
        if (fundamentalFreq <= 0.0) {
          buffer.putShort(0)
          continue
        }
        val envelope = when {
          i < 160 -> i / 160.0
          i > numSamples - 160 -> (numSamples - i) / 160.0
          else -> 1.0
        }
        phase += 2.0 * Math.PI * fundamentalFreq / sampleRate
        val voiceWave = sin(phase)
        val formant1 = 0.4 * sin(phase * (f1 / fundamentalFreq))
        val formant2 = 0.25 * sin(phase * (f2 / fundamentalFreq))
        val combined = (voiceWave + formant1 + formant2) * envelope * 0.45
        val sampleShort = (combined.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        buffer.putShort(sampleShort)
      }
    }
    return buffer.array()
  }

  private data class PhonemicSegment(
    val durationMs: Int,
    val f0: Double,
    val f1: Double,
    val f2: Double
  )

  private fun breakIntoPhonemicSegments(text: String): List<PhonemicSegment> {
    val segments = mutableListOf<PhonemicSegment>()
    val basePitch = 150.0
    for (char in text) {
      when (char) {
        ' ', '،', ',' -> {
          segments.add(PhonemicSegment(durationMs = 60, f0 = 0.0, f1 = 0.0, f2 = 0.0))
        }
        '.' -> {
          segments.add(PhonemicSegment(durationMs = 180, f0 = 0.0, f1 = 0.0, f2 = 0.0))
        }
        '\u064E', 'ا', 'ى' -> {
          segments.add(PhonemicSegment(durationMs = 80, f0 = basePitch, f1 = 750.0, f2 = 1300.0))
        }
        '\u064F', 'و' -> {
          segments.add(PhonemicSegment(durationMs = 80, f0 = basePitch * 0.95, f1 = 350.0, f2 = 800.0))
        }
        '\u0650', 'ي', 'ئ' -> {
          segments.add(PhonemicSegment(durationMs = 80, f0 = basePitch * 1.05, f1 = 300.0, f2 = 2200.0))
        }
        '\u0652' -> {
          segments.add(PhonemicSegment(durationMs = 25, f0 = basePitch * 0.9, f1 = 500.0, f2 = 1500.0))
        }
        in '\u0621'..'\u064A' -> {
          segments.add(PhonemicSegment(durationMs = 50, f0 = basePitch, f1 = 500.0, f2 = 1500.0))
        }
      }
    }
    if (segments.isEmpty()) {
      segments.add(PhonemicSegment(durationMs = 100, f0 = 0.0, f1 = 0.0, f2 = 0.0))
    }
    return segments
  }
}
