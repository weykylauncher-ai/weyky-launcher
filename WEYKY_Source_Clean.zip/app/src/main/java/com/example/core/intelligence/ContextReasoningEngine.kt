package com.example.core.intelligence

import com.example.core.context.ContextState
import com.example.device.battery.ChargingState
import java.util.Locale

/**
 * Deterministic, explainable reasoning engine that connects disparate telemetry streams,
 * distinguishes facts from inferences, and provides actionable recommendations.
 */
class ContextReasoningEngine {

  fun synthesize(
    requirements: ContextRequirements,
    snapshot: SituationSnapshot,
    userQuery: String
  ): ContextualSynthesis {
    val isArabic = userQuery.any { it in '\u0600'..'\u06FF' } || Locale.getDefault().language.startsWith("ar")
    return when (requirements.domain) {
      IntentDomain.OUTDOOR_DEPARTURE -> reasonOutdoorDeparture(snapshot, isArabic)
      IntentDomain.APPOINTMENT_TIMING -> reasonAppointmentTiming(snapshot, isArabic)
      IntentDomain.BATTERY_SUFICIENCY -> reasonBatterySufficiency(snapshot, isArabic)
      IntentDomain.SITUATION_OVERVIEW -> reasonSituationOverview(snapshot, isArabic)
      IntentDomain.WEATHER_ONLY -> reasonWeatherOnly(snapshot, isArabic)
      else -> reasonGeneral(snapshot, userQuery, isArabic)
    }
  }

  // 1. "هل أخرج الآن؟"
  private fun reasonOutdoorDeparture(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val facts = mutableListOf<String>()
    val inferences = mutableListOf<String>()
    val recommendations = mutableListOf<String>()
    val unavailabilities = mutableListOf<String>()

    val weather = snapshot.weather
    val battery = snapshot.battery
    val calendar = snapshot.calendar
    val physical = snapshot.physicalContext

    val temp = weather.value?.temperatureCelsius
    val cond = weather.value?.condition ?: ""
    val isRaining = cond.contains("Rain", ignoreCase = true) || cond.contains("مطر", ignoreCase = true) ||
      cond.contains("أمطار", ignoreCase = true) || cond.contains("Drizzle", ignoreCase = true) || cond.contains("Thunderstorm", ignoreCase = true)

    if (weather.isAvailable && temp != null) {
      facts.add(if (isArabic) "الطقس: $cond بحرارة ${temp.toInt()}°م" else "Weather is $cond at ${temp.toInt()}°C")
    } else {
      unavailabilities.add(if (isArabic) "بيانات الطقس غير متوفرة" else "Weather data unavailable")
    }

    val nextEvent = calendar.value?.nextEvent
    if (calendar.isAvailable && nextEvent != null) {
      facts.add(if (isArabic) "الموعد القادم: '${nextEvent.title}' بعد ${nextEvent.minutesUntilStart} دقيقة" else "Next appointment '${nextEvent.title}' in ${nextEvent.minutesUntilStart} mins")
    }

    val battPercent = battery.value?.percentage
    val isCharging = battery.value?.chargingState == ChargingState.CHARGING
    if (battery.isAvailable && battPercent != null) {
      facts.add(if (isArabic) "شحن البطارية: $battPercent%" else "Battery $battPercent%")
      if (battPercent < 20 && !isCharging) {
        inferences.add(if (isArabic) "البطارية منخفضة وقد تنفد أثناء تنقلك" else "Battery is low and may deplete during transit")
        recommendations.add(if (isArabic) "اشحن هاتفك قبل الخروج" else "Charge phone before leaving")
      }
    }

    if (physical.isAvailable) {
      if (physical.value?.state == ContextState.MOVING) {
        inferences.add(if (isArabic) "أنت بالفعل في حركة وتنقل" else "You appear to already be in motion")
      }
    }

    val speech = StringBuilder()
    if (isArabic) {
      if (weather.isAvailable && temp != null) {
        speech.append("الجو $cond وحرارته ${temp.toInt()}°م.")
        if (isRaining) speech.append(" هناك أمطار، خذ مظلة معك.")
      }
      if (nextEvent != null) {
        speech.append(" لديك موعد (${nextEvent.title}) بعد ${nextEvent.minutesUntilStart} دقيقة.")
      }
      if (battery.isAvailable && battPercent != null && battPercent < 20 && !isCharging) {
        speech.append(" البطارية منخفضة ($battPercent%)، يفضل شحنها قبل الخروج.")
      } else {
        speech.append(" الظروف مناسبة للخروج.")
      }
    } else {
      if (weather.isAvailable && temp != null) {
        speech.append("It's ${temp.toInt()}°C with $cond.")
        if (isRaining) speech.append(" Rain detected, take an umbrella.")
      }
      if (nextEvent != null) {
        speech.append(" You have '${nextEvent.title}' in ${nextEvent.minutesUntilStart} minutes.")
      }
      if (battery.isAvailable && battPercent != null && battPercent < 20 && !isCharging) {
        speech.append(" Battery is at $battPercent%, consider charging before heading out.")
      } else {
        speech.append(" Conditions are favorable to head out.")
      }
    }

    val nextStep = if (battPercent != null && battPercent < 20 && !isCharging) {
      NextStep(label = if (isArabic) "تفعيل موفر الطاقة" else "Enable Battery Saver")
    } else null

    return ContextualSynthesis(
      synthesizedSpeech = speech.toString().trim(),
      primaryDecision = if (isRaining) "ماطر - خذ مظلة" else "الظروف مناسبة",
      nextStep = nextStep,
      factsUsed = facts,
      inferencesMade = inferences,
      recommendations = recommendations,
      unavailabilitiesHandled = unavailabilities,
      confidenceScore = if (weather.isAvailable) 0.95f else 0.7f
    )
  }

  // 2. "هل ألحق موعدي؟"
  private fun reasonAppointmentTiming(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val facts = mutableListOf<String>()
    val recommendations = mutableListOf<String>()
    val unavailabilities = mutableListOf<String>()

    val calendar = snapshot.calendar
    val physical = snapshot.physicalContext
    val nextEvent = calendar.value?.nextEvent

    if (!calendar.isAvailable || nextEvent == null) {
      val msg = if (isArabic) {
        "لا توجد مواعيد مسجلة في تقويمك لتقييم وقت الوصول."
      } else {
        "No appointments found on your calendar for today to evaluate timing."
      }
      return ContextualSynthesis(
        synthesizedSpeech = msg,
        primaryDecision = "No Appointments",
        factsUsed = emptyList(),
        unavailabilitiesHandled = listOf(calendar.unavailabilityReason ?: "لا مواعيد")
      )
    }

    facts.add(if (isArabic) "الموعد القادم: '${nextEvent.title}' بعد ${nextEvent.minutesUntilStart} دقيقة" else "Next appointment: '${nextEvent.title}' in ${nextEvent.minutesUntilStart} mins")
    nextEvent.location?.let {
      facts.add(if (isArabic) "موقع الموعد: $it" else "Event location: $it")
    }

    unavailabilities.add(if (isArabic) "بيانات الزحام المباشر غير مفعلة" else "Live traffic data is currently unavailable")
    val estimatedTripMinutes = if (nextEvent.location.isNullOrBlank()) 20L else 30L
    val marginMinutes = nextEvent.minutesUntilStart - estimatedTripMinutes
    val isMoving = physical.value?.state == ContextState.MOVING

    val speech = StringBuilder()
    if (isArabic) {
      speech.append("موعدك القادم '${nextEvent.title}' بعد ${nextEvent.minutesUntilStart} دقيقة.")
      if (marginMinutes > 15) {
        speech.append(" ستصل براحة مع هامش أمان بنحو $marginMinutes دقيقة.")
      } else if (marginMinutes in 0..15) {
        speech.append(" الوقت ضيق، هامش الأمان نحو $marginMinutes دقيقة فقط. ينصح بالانطلاق الآن.")
      } else {
        speech.append(" قد تتأخر لأن وقت الوصول المقدر يتجاوز الوقت المتبقي. انطلق فوراً.")
      }
      if (!isMoving) {
        speech.append(" (لست في حركة حالياً).")
      }
    } else {
      speech.append("Your appointment '${nextEvent.title}' is in ${nextEvent.minutesUntilStart} minutes.")
      if (marginMinutes > 15) {
        speech.append(" You should comfortably arrive on time with roughly $marginMinutes minutes of buffer.")
      } else if (marginMinutes in 0..15) {
        speech.append(" Timing is tight (~$marginMinutes mins buffer). It is recommended to leave immediately.")
      } else {
        speech.append(" You may be late as estimated travel exceeds the remaining time.")
      }
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech.toString().trim(),
      primaryDecision = if (marginMinutes >= 0) "تلحق بالموعد" else "الوقت ضيق",
      factsUsed = facts,
      inferencesMade = listOf("وقت الطريق المقدر: ~$estimatedTripMinutes دقيقة"),
      recommendations = if (marginMinutes <= 15) listOf(if (isArabic) "انطلق الآن" else "Leave now") else emptyList(),
      unavailabilitiesHandled = unavailabilities,
      confidenceScore = 0.85f
    )
  }

  // 3. "هل تكفي البطارية؟"
  private fun reasonBatterySufficiency(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val facts = mutableListOf<String>()
    val inferences = mutableListOf<String>()
    val recommendations = mutableListOf<String>()

    val battery = snapshot.battery.value
    val calendar = snapshot.calendar.value

    if (battery == null) {
      val fallback = if (isArabic) "بيانات البطارية غير متوفرة حالياً." else "Battery information unavailable."
      return ContextualSynthesis(synthesizedSpeech = fallback, primaryDecision = "Unknown")
    }

    val pct = battery.percentage
    val isCharging = battery.chargingState == ChargingState.CHARGING
    facts.add(if (isArabic) "مستوى البطارية: $pct%" else "Battery level $pct%")

    val nextEvent = calendar?.nextEvent
    val speech = StringBuilder()
    if (isCharging) {
      speech.append(
        if (isArabic) "البطارية تشحن حالياً عند $pct% ولن تنفد طالما الشاحن متصل."
        else "Confirmed measurement: Battery is currently charging at $pct% and will not deplete while connected to power."
      )
    } else if (pct > 50) {
      speech.append(
        if (isArabic) "مستوى البطارية $pct%. هذا كافٍ للاستخدام المعتاد حتى المساء. قد يختلف الأداء الفعلي حسب سطوع الشاشة والبيانات الخلوية."
        else "Actual measurement from the system is $pct% battery. General estimation suggests this should cover typical usage until evening."
      )
      if (nextEvent != null) {
        speech.append(
          if (isArabic) " لديك موعد بعد ${nextEvent.minutesUntilStart} دقيقة."
          else " You also have an upcoming appointment in ${nextEvent.minutesUntilStart} minutes."
        )
      }
    } else if (pct in 21..50) {
      speech.append(
        if (isArabic) "البطارية عند $pct%. تكفي لبضع ساعات من الاستخدام المعتدل، لكن قد تحتاج لشحن خفيف قبل المساء."
        else "Actual measurement is $pct% battery. Generally, this may last several hours of moderate use, but a top-up is recommended."
      )
    } else {
      speech.append(
        if (isArabic) "البطارية منخفضة جداً عند $pct%. ينصح بتفعيل موفر الطاقة أو التوصيل بالشاحن."
        else "Actual measurement: Battery is critically low at $pct%. Connect charger or enable battery saver."
      )
      recommendations.add(if (isArabic) "وصّل الشاحن" else "Connect charger or enable battery saver")
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech.toString().trim(),
      primaryDecision = if (pct > 30 || isCharging) "البطارية كافية" else "شحن منخفض",
      factsUsed = facts,
      inferencesMade = inferences,
      recommendations = recommendations,
      confidenceScore = 0.85f
    )
  }

  // 4. "ما وضعي الآن؟"
  private fun reasonSituationOverview(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val facts = mutableListOf<String>()
    val recommendations = mutableListOf<String>()

    val nextEvent = snapshot.calendar.value?.nextEvent
    val missedCalls = snapshot.calls.value?.latestMissedCall
    val missedCount = snapshot.calls.value?.missedCallsCount ?: 0
    val battery = snapshot.battery.value

    val speech = StringBuilder()
    if (isArabic) {
      if (missedCount > 0 && missedCalls != null) {
        val caller = missedCalls.callerName ?: missedCalls.number
        speech.append("لديك مكالمة فائتة من $caller.")
        recommendations.add("معاودة الاتصال بـ $caller")
      }
      if (nextEvent != null) {
        speech.append(" الموعد القادم '${nextEvent.title}' بعد ${nextEvent.minutesUntilStart} دقيقة.")
      }
      if (battery != null && battery.percentage < 20 && battery.chargingState != ChargingState.CHARGING) {
        speech.append(" البطارية منخفضة (${battery.percentage}%).")
      }
      if (speech.isEmpty()) {
        speech.append("كل شيء هادئ الآن، لا توجد تنبيهات عاجلة.")
      }
    } else {
      if (missedCount > 0 && missedCalls != null) {
        val caller = missedCalls.callerName ?: missedCalls.number
        speech.append("You have a missed call from $caller.")
      }
      if (nextEvent != null) {
        speech.append(" Next event is '${nextEvent.title}' in ${nextEvent.minutesUntilStart} minutes.")
      }
      if (battery != null && battery.percentage < 20 && battery.chargingState != ChargingState.CHARGING) {
        speech.append(" Battery is at ${battery.percentage}%, consider charging.")
      }
      if (speech.isEmpty()) {
        speech.append("Everything is quiet right now with no urgent tasks or alerts.")
      }
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech.toString().trim(),
      primaryDecision = "Overview",
      factsUsed = facts,
      recommendations = recommendations,
      confidenceScore = 0.95f
    )
  }

  // 5. "الطقس"
  private fun reasonWeatherOnly(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val weather = snapshot.weather.value
    val speech = if (weather != null && weather.isAvailable && weather.temperatureCelsius != null) {
      val t = weather.temperatureCelsius.toInt()
      val c = weather.condition ?: ""
      if (isArabic) "الطقس حالياً: $c ودرجة الحرارة $t°م." else "It's $t°C with $c."
    } else {
      if (isArabic) "بيانات الطقس غير متوفرة حالياً." else "Weather information is temporarily unavailable."
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech,
      primaryDecision = "Weather Report",
      factsUsed = listOf(speech),
      confidenceScore = 1.0f
    )
  }

  private fun reasonGeneral(
    snapshot: SituationSnapshot,
    userQuery: String,
    isArabic: Boolean
  ): ContextualSynthesis {
    val speech = if (isArabic) "تم استلام الطلب: $userQuery" else "Received request: $userQuery"
    return ContextualSynthesis(synthesizedSpeech = speech, primaryDecision = "General Query")
  }

  // 6. Hypothetical: "لو شغلت أغنية هل تكفي البطارية؟"
  fun reasonHypotheticalBatteryMusic(
    snapshot: SituationSnapshot,
    isArabic: Boolean
  ): ContextualSynthesis {
    val battery = snapshot.battery.value
    val pct = battery?.percentage ?: 50
    val isCharging = battery?.chargingState == ChargingState.CHARGING

    val speech = if (isArabic) {
      if (isCharging) {
        "البطارية تشحن حالياً عند $pct%، تشغيل الموسيقى لن يستنزف الشحن أثناء الاتصال بالشاحن. لم أبدأ التشغيل؛ قل 'شغل الموسيقى' للبدء."
      } else {
        "مستوى البطارية الفعلي $pct%. استهلاك تشغيل الموسيقى يقارب 4% إلى 8% في الساعة كمتوسط تقديري، بناءً على مستوى الصوت واستخدام السماعات والبث عبر الإنترنت. لم أبدأ تشغيل الموسيقى بعد."
      }
    } else {
      if (isCharging) {
        "Confirmed actual measurement: Phone is currently charging at $pct%. Music playback will not deplete power while connected to charger. I have not started playback; say 'play music now' if you wish to start."
      } else {
        "Actual confirmed measurement from the system is $pct% battery. Regarding music playback, the estimated 4% to 8% per hour is only a general statistical average across smartphones."
      }
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech,
      primaryDecision = "Music Impact Estimated (No Playback)",
      factsUsed = listOf("Measured Battery: $pct%", "General statistical estimate: ~4-8%/hr"),
      inferencesMade = listOf("Actual consumption depends on volume, speaker/headset, streaming, and screen state"),
      recommendations = listOf(if (isArabic) "شغل الموسيقى حين ترغب" else "Play music when desired"),
      nextStep = NextStep(label = if (isArabic) "شغل الموسيقى الآن" else "Play music now", actionIntent = "شغل الموسيقى"),
      confidenceScore = 0.85f
    )
  }

  // 7. Hypothetical: "لو تأخرت 10 دقائق هل ألحق؟"
  fun reasonHypotheticalScheduleDelay(
    snapshot: SituationSnapshot,
    delayMinutes: Int,
    isArabic: Boolean
  ): ContextualSynthesis {
    val calendar = snapshot.calendar
    val nextEvent = calendar.value?.nextEvent

    if (!calendar.isAvailable || nextEvent == null) {
      val msg = if (isArabic) {
        "لا توجد مواعيد مجدولة اليوم، لذا تأخير $delayMinutes دقائق لن يؤثر على أي التزام."
      } else {
        "There are no scheduled events on your calendar today, so a $delayMinutes-minute delay won't affect any commitments."
      }
      return ContextualSynthesis(
        synthesizedSpeech = msg,
        primaryDecision = "No Appointments",
        confidenceScore = 0.9f
      )
    }

    val estimatedTripMinutes = if (nextEvent.location.isNullOrBlank()) 20L else 30L
    val originalMargin = nextEvent.minutesUntilStart - estimatedTripMinutes
    val delayedMargin = originalMargin - delayMinutes

    val speech = if (isArabic) {
      val sb = StringBuilder()
      sb.append("موعدك '${nextEvent.title}' بعد ${nextEvent.minutesUntilStart} دقيقة (طريق مقدر ~$estimatedTripMinutes دقيقة). ")
      if (delayedMargin > 10) {
        sb.append("تأخير $delayMinutes دقائق سيبقي لك هامش أمان بنحو $delayedMargin دقيقة وستصل بالوقت.")
      } else if (delayedMargin in 0..10) {
        sb.append("تأخير $delayMinutes دقائق يقلص هامش الأمان إلى $delayedMargin دقيقة فقط، الأفضل الانطلاق دون تأخير.")
      } else {
        sb.append("تأخير $delayMinutes دقائق سيجعلك متأخراً بنحو ${-delayedMargin} دقيقة. انطلق فوراً.")
      }
      sb.toString().trim()
    } else {
      val sb = StringBuilder()
      sb.append("Your event '${nextEvent.title}' is in ${nextEvent.minutesUntilStart} mins (estimated travel ~$estimatedTripMinutes mins). ")
      if (delayedMargin > 10) {
        sb.append("A $delayMinutes-minute delay leaves you with ~$delayedMargin mins buffer; you should still make it.")
      } else if (delayedMargin in 0..10) {
        sb.append("A $delayMinutes-minute delay tightens your buffer to just $delayedMargin mins; leaving now is advised.")
      } else {
        sb.append("A $delayMinutes-minute delay will make you late by roughly ${-delayedMargin} minutes. You should leave immediately.")
      }
      sb.toString().trim()
    }

    return ContextualSynthesis(
      synthesizedSpeech = speech,
      primaryDecision = if (delayedMargin >= 0) "تلحق مع التأخير" else "ستتأخر",
      factsUsed = listOf("Event: ${nextEvent.title}", "Delay considered: $delayMinutes mins"),
      inferencesMade = listOf("Buffer after delay: $delayedMargin mins"),
      recommendations = if (delayedMargin <= 10) listOf(if (isArabic) "انطلق الآن دون تأخير" else "Leave now without delay") else emptyList(),
      confidenceScore = 0.9f
    )
  }
}
