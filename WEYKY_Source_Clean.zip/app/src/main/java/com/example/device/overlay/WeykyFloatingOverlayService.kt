package com.example.device.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R

/**
 * Foreground floating overlay and ambient core service for WEYKY.
 * Keeps ambient intelligence alive and manages floating sphere interaction when overlay permission is granted.
 */
class WeykyFloatingOverlayService : Service() {

  companion object {
    private const val CHANNEL_ID = "weyky_overlay_channel"
    private const val NOTIFICATION_ID = 2001
    const val ACTION_START = "com.example.device.overlay.ACTION_START"
    const val ACTION_STOP = "com.example.device.overlay.ACTION_STOP"
  }

  override fun onCreate() {
    super.onCreate()
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      stopForeground(STOP_FOREGROUND_REMOVE)
      stopSelf()
      return START_NOT_STICKY
    }

    val notification = createNotification()
    startForeground(NOTIFICATION_ID, notification)
    return START_STICKY
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "WEYKY Ambient Core",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "WEYKY background ambient consciousness and overlay"
        setShowBadge(false)
      }
      val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      manager?.createNotificationChannel(channel)
    }
  }

  private fun createNotification(): Notification {
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("WEYKY Core")
      .setContentText("Ambient consciousness active")
      .setSmallIcon(R.mipmap.ic_launcher)
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()
  }
}
