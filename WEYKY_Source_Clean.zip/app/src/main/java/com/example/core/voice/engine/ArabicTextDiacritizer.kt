package com.example.core.voice.engine

/**
 * High-quality Arabic text diacritizer, vocalization, and normalizer for TTS.
 * Functions:
 * 1. Expands Arabic digits and Western digits to fully diacritized Arabic words.
 * 2. Normalizes punctuation, percentages, units, mathematical symbols, dates, and times.
 * 3. Applies Rule-Based / Morphological diacritics to common assistant vocabulary.
 * 4. Preserves already diacritized Arabic text untouched.
 */
object ArabicTextDiacritizer {
  private val ARABIC_DIACRITICS_REGEX = Regex("[\u064B-\u0652\u0670]")

  fun isPreDiacritized(text: String): Boolean {
    val diacriticCount = ARABIC_DIACRITICS_REGEX.findAll(text).count()
    val arabicLettersCount = text.count { char ->
      char in '\u0621'..'\u064A'
    }
    if (arabicLettersCount == 0) return false
    return (diacriticCount.toDouble() / arabicLettersCount.toDouble()) > 0.15
  }

  fun prepareAndDiacritize(raw: String): String {
    if (raw.isBlank()) return ""
    var text = expandDatesAndTimes(raw)
    text = expandSymbolsAndUnits(text)
    text = expandNumbers(text)
    if (isPreDiacritized(text)) {
      return cleanPunctuationForSpeech(text)
    }
    text = applyContextualDiacritization(text)
    return cleanPunctuationForSpeech(text)
  }

  fun splitIntoSynthesisChunks(text: String, maxCharsPerChunk: Int = 120): List<String> {
    val normalized = text.replace(Regex("\\s+"), " ").trim()
    if (normalized.isEmpty()) return emptyList()
    if (normalized.length <= maxCharsPerChunk) return listOf(normalized)

    val rawClauses = normalized.split(Regex("(?<=[.!?،؛\\n])\\s+"))
      .map { it.trim() }
      .filter { it.isNotEmpty() }

    val chunks = mutableListOf<String>()
    val current = StringBuilder()
    for (clause in rawClauses) {
      if (clause.length > maxCharsPerChunk) {
        if (current.isNotEmpty()) {
          chunks.add(current.toString().trim())
          current.clear()
        }
        val words = clause.split(" ")
        for (word in words) {
          if (current.length + word.length + 1 > maxCharsPerChunk && current.isNotEmpty()) {
            chunks.add(current.toString().trim())
            current.clear()
          }
          if (current.isNotEmpty()) current.append(' ')
          current.append(word)
        }
      } else if (current.length + clause.length + 1 <= maxCharsPerChunk) {
        if (current.isNotEmpty()) current.append(' ')
        current.append(clause)
      } else {
        if (current.isNotEmpty()) {
          chunks.add(current.toString().trim())
          current.clear()
        }
        current.append(clause)
      }
    }
    if (current.isNotEmpty()) {
      chunks.add(current.toString().trim())
    }
    return chunks
  }

  private fun expandDatesAndTimes(text: String): String {
    val standardized = standardizeEasternDigits(text)
    val dateRegex = Regex("""\b(\d{1,4})[/-](\d{1,2})[/-](\d{1,4})\b""")
    val afterDates = dateRegex.replace(standardized) { m ->
      val p1 = m.groupValues[1].toLongOrNull()
      val p2 = m.groupValues[2].toIntOrNull()
      val p3 = m.groupValues[3].toLongOrNull()
      val monthNames = arrayOf(
        "", "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
      )
      if (p1 != null && p2 != null && p3 != null && p2 in 1..12) {
        val monthWord = monthNames[p2]
        if (p1 > 31) {
          "${numberToArabicWords(p3)} $monthWord ${numberToArabicWords(p1)}"
        } else {
          "${numberToArabicWords(p1)} $monthWord ${numberToArabicWords(p3)}"
        }
      } else {
        m.value
      }
    }

    val timeRegex = Regex("""\b(\d{1,2}):(\d{2})\b""")
    return timeRegex.replace(afterDates) { m ->
      val hours = m.groupValues[1].toLongOrNull()
      val mins = m.groupValues[2].toLongOrNull()
      if (hours != null && mins != null && hours in 0..23 && mins in 0..59) {
        if (mins == 0L) {
          "الساعة ${numberToArabicWords(hours)} تماماً"
        } else {
          "${numberToArabicWords(hours)} و ${numberToArabicWords(mins)} دقيقة"
        }
      } else {
        m.value
      }
    }
  }

  private fun expandSymbolsAndUnits(text: String): String {
    return text
      .replace(Regex("""(?i)\bweyky\s*\(\s*(?:ويكي)?\s*\)"""), "ويكي")
      .replace(Regex("""(?i)\bweyky\b"""), "ويكي")
      .replace(Regex("""(?i)(?<=\d)\s*(?:كم|km)\s*[/\\|]\s*(?:س|ساعة|h(?:r)?)(?!\w)"""), " كيلومتراً في الساعة ")
      .replace(Regex("""(?i)(?:كم|km)\s*[/\\|]\s*(?:س|ساعة|h(?:r)?)(?!\w)"""), " كيلومتر في الساعة ")
      .replace(Regex("""(?i)\b(?:kmph|kph|kmh)\b"""), " كيلومتر في الساعة ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:م|m)\s*[/\\|]\s*(?:ث|ثانية|s(?:ec)?)(?!\w)"""), " متراً في الثانية ")
      .replace(Regex("""(?i)(?:م|m)\s*[/\\|]\s*(?:ث|ثانية|s(?:ec)?)(?!\w)"""), " متر في الثانية ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:كم|km)(?!\w)"""), " كيلومتر ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:كغ|kg)\b"""), " كيلوغرام ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:غ|g)\b"""), " غرام ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:سم|cm)\b"""), " سنتيمتر ")
      .replace(Regex("""(?i)(?<=\d)\s*(?:ملم|mm)\b"""), " مليمتر ")
      .replace("%", " بالمئة ")
      .replace("°م", " درجة مئوية ")
      .replace(Regex("""(?i)°\s*[cC سS]|°[cC]"""), " درجة مئوية ")
      .replace(Regex("""(?<=\d)\s*°"""), " درجة ")
      .replace(Regex("""(?i)\bMB\b"""), " ميغابايت ")
      .replace(Regex("""(?i)\bGB\b"""), " غيغابايت ")
      .replace(Regex("""(?i)\bKB\b"""), " كيلوبايت ")
      .replace(" / ", " تقسيم ")
      .replace(" + ", " زائد ")
      .replace(" - ", " ناقص ")
      .replace(" = ", " يساوي ")
      .replace("&", " و ")
      .replace("\\", " ")
  }

  private fun standardizeEasternDigits(text: String): String {
    return buildString(text.length) {
      for (ch in text) {
        when (ch) {
          '٠' -> append('0'); '١' -> append('1'); '٢' -> append('2'); '٣' -> append('3'); '٤' -> append('4')
          '٥' -> append('5'); '٦' -> append('6'); '٧' -> append('7'); '٨' -> append('8'); '٩' -> append('9')
          else -> append(ch)
        }
      }
    }
  }

  private fun expandNumbers(text: String): String {
    val standardized = standardizeEasternDigits(text)
    val decimalRegex = Regex("""\b(\d+)[.,](\d+)\b""")
    val afterDecimals = decimalRegex.replace(standardized) { matchResult ->
      val intPart = matchResult.groupValues[1].toLongOrNull()
      val fracStr = matchResult.groupValues[2]
      val fracPart = fracStr.toLongOrNull()
      if (intPart != null && fracPart != null && intPart in 0..999999 && fracPart in 0..999999) {
        " ${numberToArabicWords(intPart)} فاصلة ${numberToArabicWords(fracPart)} "
      } else {
        matchResult.value
      }
    }

    val numberRegex = Regex("\\b\\d+\\b")
    return numberRegex.replace(afterDecimals) { matchResult ->
      val numStr = matchResult.value
      val num = numStr.toLongOrNull()
      if (num != null && num in 0..999999) {
        " " + numberToArabicWords(num) + " "
      } else {
        matchResult.value
      }
    }
  }

  fun numberToArabicWords(number: Long): String {
    if (number == 0L) return "صفر"
    if (number < 0L) return "سالب " + numberToArabicWords(-number)

    val units = arrayOf(
      "", "واحد", "اثنان", "ثلاثة", "أربعة",
      "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"
    )
    val teens = arrayOf(
      "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر",
      "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"
    )
    val tens = arrayOf(
      "", "", "عشرون", "ثلاثون", "أربعون",
      "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"
    )
    val hundreds = arrayOf(
      "", "مئة", "مئتان", "ثلاثمئة", "أربعمئة",
      "خمسمئة", "ستمئة", "سبعمئة", "ثمانمئة", "تسعمئة"
    )

    fun convertUnder1000(n: Int): String {
      if (n == 0) return ""
      val h = n / 100
      val rem = n % 100
      val parts = mutableListOf<String>()
      if (h > 0) parts.add(hundreds[h])
      if (rem in 1..9) {
        parts.add(units[rem])
      } else if (rem in 10..19) {
        parts.add(teens[rem - 10])
      } else if (rem >= 20) {
        val u = rem % 10
        val t = rem / 10
        if (u > 0) {
          parts.add("${units[u]} و${tens[t]}")
        } else {
          parts.add(tens[t])
        }
      }
      return parts.joinToString(" و")
    }

    if (number < 1000L) {
      return convertUnder1000(number.toInt())
    }

    val thousands = (number / 1000L).toInt()
    val remainder = (number % 1000L).toInt()

    val thousandsWord = when (thousands) {
      1 -> "ألف"
      2 -> "ألفان"
      in 3..10 -> "${units[thousands]} آلاف"
      else -> "${convertUnder1000(thousands)} ألف"
    }

    val remWord = if (remainder > 0) " و" + convertUnder1000(remainder) else ""
    return thousandsWord + remWord
  }

  private fun applyContextualDiacritization(input: String): String {
    val vocalizedDictionary = mapOf(
      "مرحبا" to "مَرْحَبًا",
      "اهلا" to "أَهْلًا",
      "السلام" to "السَّلَامُ",
      "عليكم" to "عَلَيْكُمْ",
      "صباح" to "صَبَاحُ",
      "الخير" to "الْخَيْرِ",
      "مساء" to "مَسَاءُ",
      "النور" to "النُّورِ",
      "شكرا" to "شُكْرًا",
      "عفوا" to "عَفْوًا",
      "نعم" to "نَعَمْ",
      "لا" to "لَا",
      "اليوم" to "الْيَوْمَ",
      "غدا" to "غَدًا",
      "الساعة" to "السَّاعَةُ",
      "دقيقة" to "دَقِيقَة",
      "الطقس" to "الطَّقْسُ",
      "الجو" to "الْجَوُّ",
      "حرارة" to "حَرَارَة",
      "البطارية" to "الْبَطَّارِيَّةُ",
      "الكشاف" to "الْكَشَّافُ",
      "الموسيقى" to "الْمُوسِيقَى",
      "الهاتف" to "الْهَاتِفُ",
      "الجهاز" to "الْجِهَازُ",
      "الذاكرة" to "الذَّاكِرَةُ",
      "الشبكة" to "الشَّبَكَةُ",
      "تم" to "تَمَّ",
      "تشغيل" to "تَشْغِيلُ",
      "إيقاف" to "إِيقَافُ",
      "فتح" to "فَتْحُ",
      "تطبيق" to "تَطْبِيق",
      "WEYKY" to "وِيكِي",
      "Weyky" to "وِيكِي",
      "weyky" to "وِيكِي"
    )
    val words = input.split(Regex("\\s+"))
    return words.joinToString(" ") { word ->
      val cleanWord = word.trim { !it.isLetterOrDigit() && it !in '\u064B'..'\u0652' }
      val vocalized = vocalizedDictionary[cleanWord]
      if (vocalized != null) {
        word.replace(cleanWord, vocalized)
      } else {
        word
      }
    }
  }

  private fun cleanPunctuationForSpeech(text: String): String {
    return text
      .replace(Regex("""[/\\|]+"""), " ")
      .replace(Regex("[,،]+"), " ، ")
      .replace(Regex("[.!?؟]+"), " . ")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  private val lexiconLock = Any()
  @Volatile
  private var cachedEspeakLexicon: Map<String, String>? = null
  private val THICK_ARABIC_CONSONANTS = setOf('ص', 'ض', 'ط', 'ظ', 'ق', 'خ', 'غ')
  private val SUN_ARABIC_CONSONANTS = setOf('ت', 'ث', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ل', 'ن')
  private val SHORT_VOWELS = setOf('\u064E', '\u064F', '\u0650')

  private val CORE_BUILTIN_ESPEAK_LEXICON = mapOf(
    "مرحبا" to "m'aRHaban",
    "أهلا" to "?'ahlan",
    "اهلا" to "?'ahlan",
    "بكم" to "b'ikum",
    "بك" to "b'ika",
    "في" to "fi:",
    "من" to "min",
    "إلى" to "?'ila:",
    "الى" to "?'ila:",
    "على" to "A'ala:",
    "عن" to "A'an",
    "مع" to "m'aA",
    "بين" to "b'ajna",
    "بعد" to "b'aAd",
    "قبل" to "q'abl",
    "عند" to "A'ind",
    "الآن" to "?al?'a:na",
    "الان" to "?al?'a:na",
    "اليوم" to "?alj'awma",
    "يوم" to "j'awm",
    "غدا" to "Q'adan",
    "أمس" to "?'amsi",
    "نعم" to "n'aAam",
    "لا" to "l'a:",
    "ما" to "m'a:",
    "ماذا" to "m'a:Da:",
    "لماذا" to "lim'a:Da:",
    "كيف" to "k'ajfa",
    "متى" to "m'ata:",
    "أين" to "?'ajna",
    "اين" to "?'ajna",
    "هل" to "h'al",
    "كم" to "k'am",
    "أنا" to "'ana",
    "انا" to "'ana",
    "أنت" to "?'anta",
    "انت" to "?'anta",
    "هذا" to "ha:Da:",
    "هذه" to "ha:Dihi",
    "ذلك" to "Da:lika",
    "تلك" to "t'ilka",
    "هنا" to "h'una:",
    "هناك" to "hun'a:ka",
    "ويكي" to "w'a:jki:",
    "تفصل" to "taf'adH:al",
    "شكرا" to "S'ukRan",
    "عفوا" to "A'afwan",
    "السلام" to "?assal'a:mu",
    "عليكم" to "Aal'ajkum",
    "وعليكم" to "waAal'ajkumu",
    "ورحمة" to "waR'aHmatu",
    "الله" to "?all'a.:hi",
    "صباح" to "s['a.ba:Hu",
    "مساء" to "mas'a:?u",
    "الخير" to "?alx'ajRi",
    "النور" to "?ann'u:Ri",
    "درجة" to "d'aRadZa",
    "حرارة" to "HaR'a:Ra",
    "الحرارة" to "?alHaR'a:Ra",
    "الجو" to "?aldZ'aw:",
    "جو" to "dZ'aw:",
    "الطقس" to "?at[:'a.qs",
    "طقس" to "t['a.qs",
    "معتدل" to "muAt'adil",
    "معتدلة" to "muAt'adila",
    "مدينة" to "mad'i:na",
    "مدينتك" to "mad'i:natika",
    "مدينتكم" to "mad'i:natikum",
    "مدينتي" to "mad'i:nati:",
    "البطارية" to "?albat[:a:R'ij:a",
    "بطارية" to "bat[:a:R'ij:a",
    "بطاريتك" to "bat[:a:R'ij:atuka",
    "بطاريتي" to "bat[:a:R'ij:ati:",
    "والبطارية" to "walbat[:a:R'ij:a",
    "مشحونة" to "maSH'u:na",
    "مشحون" to "maSH'u:n",
    "الشحن" to "?aS:'aHn",
    "شحن" to "S'aHn",
    "نسبة" to "n'isba",
    "بنسبة" to "bin'isbat",
    "بالمئة" to "bilm'i?a",
    "بالمائة" to "bilm'i?a",
    "مئوية" to "mi?aw'ij:a",
    "صفر" to "s['i.fR",
    "واحد" to "w'a:Hid",
    "واحدة" to "w'a:Hida",
    "اثنان" to "?iTn'a:n",
    "اثنا" to "?iTn'a:",
    "ثلاثة" to "Tal'a:Ta",
    "ثلاث" to "Tal'a:T",
    "أربعة" to "?aRb'aAa",
    "أربع" to "?'aRbaA",
    "خمسة" to "x'amsa",
    "خمس" to "x'ams",
    "ستة" to "s'it:a",
    "ست" to "s'it:",
    "سبعة" to "s'abAa",
    "سبع" to "s'abA",
    "ثمانية" to "Tam'a:nija",
    "ثماني" to "Tam'a:ni:",
    "تسعة" to "t'isAa",
    "تسع" to "t'isA",
    "عشرة" to "A'aSaRa",
    "عشر" to "A'aSaR",
    "عشرون" to "AiSR'u:n",
    "ثلاثون" to "Tala:T'u:n",
    "أربعون" to "?aRbaA'u:n",
    "خمسون" to "xams'u:n",
    "ستون" to "sit:'u:n",
    "سبعون" to "sabA'u:n",
    "ثمانون" to "Tama:n'u:n",
    "تسعون" to "tisA'u:n",
    "مئة" to "m'i?a",
    "مئتان" to "mi?at'a:n",
    "ثلاثمئة" to "Tal'a:Tumi?a",
    "أربعمئة" to "?'aRbaAumi?a",
    "خمسمئة" to "x'amsumi?a",
    "ستمئة" to "s'it:umi?a",
    "سبعمئة" to "s'abAumi?a",
    "ثمانمئة" to "Tam'a:numi?a",
    "تسعمئة" to "t'isAumi?a",
    "ألف" to "?'alf",
    "ألفان" to "?alf'a:n",
    "آلاف" to "?a:l'a:f",
    "فاصلة" to "f'a.:s[il",
    "زائد" to "z'a:?id",
    "ناقص" to "n'a.:qis[",
    "يساوي" to "jus'a:wi:",
    "الساعة" to "?ass'a:Aa",
    "ساعة" to "s'a:Aa",
    "دقيقة" to "daq'i:qa",
    "دقائق" to "daq'a.:?iq",
    "تماما" to "tam'a:man",
    "الكشاف" to "?alkaS:'a:f",
    "كشاف" to "kaS:'a:f",
    "الصوت" to "?as[:'a.wt",
    "صوت" to "s['a.wt",
    "الموسيقى" to "?almu:s'i:qa:",
    "موسيقى" to "mu:s'i:qa:",
    "الهاتف" to "?alh'a:tif",
    "هاتف" to "h'a:tif",
    "الجهاز" to "?aldZih'a:z",
    "جهاز" to "dZih'a:z",
    "الذاكرة" to "?aD:'a:kiRa",
    "ذاكرة" to "D'a:kiRa",
    "التخزين" to "?attaxz'i:n",
    "تخزين" to "taxz'i:n",
    "الشبكة" to "?aS:'abaka",
    "شبكة" to "S'abaka",
    "تم" to "t'am:",
    "تشغيل" to "taSQ'i:l",
    "إيقاف" to "?i:q'a:f",
    "فتح" to "f'atH",
    "تطبيق" to "tat[b'i.:q",
    "أستمع" to "?ast'amiAu",
    "إليك" to "?il'ajka",
    "ميغابايت" to "mi:ga:b'a:jt",
    "غيغابايت" to "dZi:ga:b'a:jt",
    "كيلوبايت" to "ki:lu:b'a:jt",
    "كيلومتر" to "ki:lu:m'itR",
    "واي" to "w'a:j",
    "فاي" to "f'a:j",
    "بلوتوث" to "blu:t'u:T",
    "البلوتوث" to "?alblu:t'u:T"
  )

  private fun getEspeakLexicon(): Map<String, String> {
    val existing = cachedEspeakLexicon
    if (existing != null) return existing
    synchronized(lexiconLock) {
      val again = cachedEspeakLexicon
      if (again != null) return again
      val map = HashMap<String, String>(32000)
      map.putAll(CORE_BUILTIN_ESPEAK_LEXICON)
      cachedEspeakLexicon = map
      return map
    }
  }

  fun ensureLexiconLoaded(context: android.content.Context) {
    getEspeakLexicon()
  }

  private fun stripDiacritics(word: String): String {
    return buildString(word.length) {
      for (ch in word) {
        if (ch !in '\u064B'..'\u0652' && ch != '\u0670' && ch != '\u0640') {
          append(ch)
        }
      }
    }
  }

  private fun lookupStemMnemonic(stem: String, lexicon: Map<String, String>): String? {
    lexicon[stem]?.let { return it }
    val normHamza = stem.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    lexicon[normHamza]?.let { return it }
    if (stem.startsWith('و') && stem.length >= 2) {
      lexicon[stem.substring(1)]?.let { return "wa$it" }
    }
    if (stem.startsWith('ف') && stem.length >= 2) {
      lexicon[stem.substring(1)]?.let { return "fa$it" }
    }
    return null
  }

  private fun applySunAssimilation(prefixMnem: String, stemMnem: String): String {
    val multiConsonants = listOf("dH", "gH", "s[", "t[", "dZ", "tS")
    for (mc in multiConsonants) {
      if (stemMnem.startsWith(mc)) {
        return prefixMnem + mc + ":" + stemMnem.substring(mc.length)
      }
      if (stemMnem.startsWith("'$mc")) {
        return prefixMnem + "'" + mc + ":" + stemMnem.substring(mc.length + 1)
      }
    }
    if (stemMnem.isNotEmpty()) {
      return if (stemMnem[0] == '\'' && stemMnem.length >= 2) {
        prefixMnem + "'" + stemMnem[1] + ":" + stemMnem.substring(2)
      } else {
        prefixMnem + stemMnem[0] + ":" + stemMnem.substring(1)
      }
    }
    return prefixMnem + stemMnem
  }

  private fun ruleBasedWordToEspeakMnemonic(word: String): String {
    val canonical = word
      .replace("\u064E\u0651", "\u0651\u064E")
      .replace("\u064F\u0651", "\u0651\u064F")
      .replace("\u0650\u0651", "\u0651\u0650")
    val hasAnyShortVowels = canonical.any { it in SHORT_VOWELS }
    val sb = StringBuilder()
    var i = 0
    var prevWasThick = false

    if (canonical.startsWith("ال") && canonical.length >= 3) {
      var afterLamIdx = 2
      while (afterLamIdx < canonical.length && canonical[afterLamIdx] in '\u064B'..'\u0652') {
        afterLamIdx++
      }
      val firstStemChar = if (afterLamIdx < canonical.length) canonical[afterLamIdx] else '\u0000'
      if (firstStemChar in SUN_ARABIC_CONSONANTS) {
        sb.append("?a")
        i = 2
      } else {
        sb.append("?al")
        i = 2
      }
    }

    while (i < canonical.length) {
      val ch = canonical[i]
      val next1 = if (i + 1 < canonical.length) canonical[i + 1] else '\u0000'
      val next2 = if (i + 2 < canonical.length) canonical[i + 2] else '\u0000'
      when (ch) {
        'آ' -> {
          sb.append("?a:")
          prevWasThick = false
          i++
          continue
        }
        'أ', 'إ', 'ء', 'ئ', 'ؤ' -> {
          sb.append("?")
          prevWasThick = false
        }
        'ا' -> {
          if (i == 0) {
            sb.append("?")
            if (!hasAnyShortVowels && next1 !in SHORT_VOWELS) {
              sb.append("a")
            }
          } else {
            sb.append(if (prevWasThick) "a.:" else "a:")
          }
          prevWasThick = false
          i++
          continue
        }
        'ى' -> {
          sb.append(if (prevWasThick) "a.:" else "a:")
          prevWasThick = false
          i++
          continue
        }
        'ب' -> { sb.append("b"); prevWasThick = false }
        'ت' -> { sb.append("t"); prevWasThick = false }
        'ة' -> {
          if (next1 in SHORT_VOWELS || next1 in setOf('\u064B', '\u064C', '\u064D')) {
            sb.append("t")
          } else {
            if (!sb.endsWith("a") && !sb.endsWith("a.") && !sb.endsWith(":")) {
              sb.append(if (prevWasThick) "a." else "a")
            }
          }
          prevWasThick = false
          i++
          continue
        }
        'ث' -> { sb.append("T"); prevWasThick = false }
        'ج' -> { sb.append("dZ"); prevWasThick = false }
        'ح' -> { sb.append("H"); prevWasThick = false }
        'خ' -> { sb.append("X"); prevWasThick = false }
        'د' -> { sb.append("d"); prevWasThick = false }
        'ذ' -> { sb.append("D"); prevWasThick = false }
        'ر' -> { sb.append("R"); prevWasThick = false }
        'ز' -> { sb.append("z"); prevWasThick = false }
        'س' -> { sb.append("s"); prevWasThick = false }
        'ش' -> { sb.append("S"); prevWasThick = false }
        'ص' -> { sb.append("s["); prevWasThick = true }
        'ض' -> { sb.append("dH"); prevWasThick = true }
        'ط' -> { sb.append("t["); prevWasThick = true }
        'ظ' -> { sb.append("Z"); prevWasThick = true }
        'ع' -> { sb.append("A"); prevWasThick = false }
        'غ' -> { sb.append("Q"); prevWasThick = false }
        'ف' -> { sb.append("f"); prevWasThick = false }
        'ق' -> { sb.append("q"); prevWasThick = false }
        'ك' -> { sb.append("k"); prevWasThick = false }
        'ل' -> { sb.append("l"); prevWasThick = false }
        'م' -> { sb.append("m"); prevWasThick = false }
        'ن' -> { sb.append("n"); prevWasThick = false }
        'ه' -> { sb.append("h"); prevWasThick = false }
        'و' -> {
          if (i == 0 || next1 in SHORT_VOWELS || next1 == '\u0651' || next1 == 'ا') {
            sb.append("w")
          } else {
            sb.append(if (prevWasThick) "u.:" else "u:")
            prevWasThick = false
            i++
            continue
          }
          prevWasThick = false
        }
        'ي' -> {
          if (i == 0 || next1 in SHORT_VOWELS || next1 == '\u0651' || next1 == 'ا') {
            sb.append("j")
          } else {
            sb.append(if (prevWasThick) "i.:" else "i:")
            prevWasThick = false
            i++
            continue
          }
          prevWasThick = false
        }
        '\u0651' -> {
          sb.append(":")
          i++
          continue
        }
        '\u064E' -> {
          if (next1 == 'ا' || next1 == 'ى') {
            sb.append(if (prevWasThick) "a.:" else "a:")
            prevWasThick = false
            i += 2
            continue
          } else if (next1 == 'و' && next2 == '\u0652') {
            sb.append(if (prevWasThick) "a.w" else "aw")
            prevWasThick = false
            i += 3
            continue
          } else if (next1 == 'ي' && next2 == '\u0652') {
            sb.append(if (prevWasThick) "a.j" else "aj")
            prevWasThick = false
            i += 3
            continue
          } else {
            sb.append(if (prevWasThick) "a." else "a")
            prevWasThick = false
            i++
            continue
          }
        }
        '\u064F' -> {
          if (next1 == 'و' && next2 !in SHORT_VOWELS && next2 != '\u0651') {
            sb.append(if (prevWasThick) "u.:" else "u:")
            prevWasThick = false
            i += 2
            continue
          } else {
            sb.append(if (prevWasThick) "u." else "u")
            prevWasThick = false
            i++
            continue
          }
        }
        '\u0650' -> {
          if (next1 == 'ي' && next2 !in SHORT_VOWELS && next2 != '\u0651') {
            sb.append(if (prevWasThick) "i.:" else "i:")
            prevWasThick = false
            i += 2
            continue
          } else {
            sb.append(if (prevWasThick) "i." else "i")
            prevWasThick = false
            i++
            continue
          }
        }
        '\u064B' -> {
          sb.append(if (prevWasThick) "a.n" else "an")
          prevWasThick = false
          if (next1 == 'ا' || next1 == 'ى') i += 2 else i++
          continue
        }
        '\u064C' -> {
          sb.append(if (prevWasThick) "u.n" else "un")
          prevWasThick = false
          i++
          continue
        }
        '\u064D' -> {
          sb.append(if (prevWasThick) "i.n" else "in")
          prevWasThick = false
          i++
          continue
        }
        '\u0670' -> {
          sb.append(if (prevWasThick) "a.:" else "a:")
          prevWasThick = false
          i++
          continue
        }
        '\u0652' -> {
          prevWasThick = false
          i++
          continue
        }
        in 'a'..'z', in 'A'..'Z' -> {
          sb.append(ch.lowercaseChar())
          prevWasThick = false
          i++
          continue
        }
        else -> {
          i++
          continue
        }
      }
      if (!hasAnyShortVowels && i < canonical.length - 1) {
        val peek = canonical[i + 1]
        if (peek in '\u0621'..'\u064A' && peek !in setOf('ا', 'و', 'ي', 'ى')) {
          sb.append(if (prevWasThick) "a." else "a")
          prevWasThick = false
        }
      }
      i++
    }
    return sb.toString()
  }

  private fun espeakMnemonicToIpaTokens(mnem: String): List<String> {
    val out = ArrayList<String>(mnem.length + 4)
    var i = 0
    while (i < mnem.length) {
      when {
        mnem.startsWith("dH", i) -> { out.add("d"); out.add("\u02E4"); i += 2 }
        mnem.startsWith("gH", i) -> { out.add("\u0263"); i += 2 }
        mnem.startsWith("s[", i) -> { out.add("s"); out.add("\u032A"); i += 2 }
        mnem.startsWith("t[", i) -> { out.add("t"); out.add("\u032A"); i += 2 }
        mnem.startsWith("dZ", i) -> { out.add("d"); out.add("\u0292"); i += 2 }
        mnem.startsWith("tS", i) -> { out.add("t"); out.add("\u0283"); i += 2 }
        mnem.startsWith("a.", i) -> { out.add("a"); out.add("."); i += 2 }
        mnem.startsWith("i.", i) -> { out.add("i"); out.add("."); i += 2 }
        mnem.startsWith("u.", i) -> { out.add("u"); out.add("."); i += 2 }
        else -> {
          when (val c = mnem[i]) {
            '?' -> out.add("\u0294")
            'A' -> out.add("\u0295")
            'H' -> out.add("\u0127")
            'X' -> out.add("\u03C7")
            'Q' -> out.add("\u0263")
            'T' -> out.add("\u03B8")
            'D' -> out.add("\u00F0")
            'Z' -> out.add("\u00F0")
            'S' -> out.add("\u0283")
            'R' -> out.add("r")
            ':' -> out.add("\u02D0")
            '\'' -> out.add("\u02C8")
            ',' -> out.add("\u02CC")
            '%', '=', '-', '_', '|' -> {}
            ' ' -> out.add(" ")
            else -> out.add(c.toString())
          }
          i++
        }
      }
    }
    return out
  }

  fun arabicToIpaPhonemes(vocalizedText: String): List<String> {
    val prepared = prepareAndDiacritize(vocalizedText)
    if (prepared.isBlank()) return emptyList()
    val lexicon = getEspeakLexicon()
    val tokens = mutableListOf<String>()
    val rawTokens = prepared.trim().split(Regex("\\s+"))
    for (rawTok in rawTokens) {
      if (rawTok.isEmpty()) continue
      if (rawTok == "،" || rawTok == ",") {
        tokens.add(",")
        tokens.add(" ")
        continue
      }
      if (rawTok == "." || rawTok == "!" || rawTok == "?" || rawTok == "؟") {
        tokens.add(if (rawTok == "؟" || rawTok == "?") "?" else if (rawTok == "!") "!" else ".")
        continue
      }

      var startIdx = 0
      while (startIdx < rawTok.length && !rawTok[startIdx].isLetterOrDigit() && rawTok[startIdx] !in '\u064B'..'\u0652') {
        startIdx++
      }
      var endIdx = rawTok.length
      while (endIdx > startIdx && !rawTok[endIdx - 1].isLetterOrDigit() && rawTok[endIdx - 1] !in '\u064B'..'\u0652') {
        endIdx--
      }
      val wordCore = rawTok.substring(startIdx, endIdx)
      val trailingPunct = rawTok.substring(endIdx)
      if (wordCore.isNotEmpty()) {
        if (tokens.isNotEmpty() && tokens.last() != " ") {
          tokens.add(" ")
        }
        val clean = stripDiacritics(wordCore)
        val espeakMnem = lookupStemMnemonic(clean, lexicon)
          ?: ruleBasedWordToEspeakMnemonic(wordCore)
        tokens.addAll(espeakMnemonicToIpaTokens(espeakMnem))
      }
      if (trailingPunct.isNotEmpty()) {
        for (p in trailingPunct) {
          when (p) {
            '،', ',' -> tokens.add(",")
            '؛', ';' -> tokens.add(";")
            ':', ' ' -> tokens.add(":")
            '؟', '?' -> tokens.add("?")
            '!' -> tokens.add("!")
            '.' -> tokens.add(".")
          }
        }
      }
    }
    while (tokens.isNotEmpty() && tokens.last() == " ") {
      tokens.removeAt(tokens.lastIndex)
    }
    return tokens
  }
}
