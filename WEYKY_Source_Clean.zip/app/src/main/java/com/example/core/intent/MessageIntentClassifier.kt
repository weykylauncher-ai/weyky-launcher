package com.example.core.intent

import com.example.core.intelligence.conversation.ConversationSession
import com.example.core.intelligence.conversation.PendingExpectation
import java.util.Locale

enum class MessageIntentType {
  ACTION_EXECUTION,         // "افتح واتساب", "أشعل الكشاف"
  HYPOTHETICAL_QUESTION,    // "لو شغلت أغنية هل تكفي البطارية؟"
  INFORMATIONAL_QUESTION,   // "كم الساعة", "كيف الطقس"
  FOLLOW_UP_QUERY,          // "وماذا عنه أيضاً؟"
  HYBRID_REQUEST,           // "احسب كذا وافتح الآلة"
  GENERAL_CONVERSATION      // حوار وسوالف عامة
}

data class ClassifiedMessage(
  val type: MessageIntentType,
  val primarySubject: String? = null,
  val isHypothetical: Boolean = false,
  val extractedDelayMinutes: Int? = null,
  val extractedSongTitle: String? = null,
  val confidence: Float = 1.0f
)

object MessageIntentClassifier {
  fun normalize(raw: String): String {
    return raw.trim()
      .lowercase(Locale.ROOT)
      .replace(Regex("[\\u064B-\\u065F\\u0670]"), "") // Strip all tashkeel & shaddah
      .replace('أ', 'ا')
      .replace('إ', 'ا')
      .replace('آ', 'ا')
      .replace('ة', 'ه')
      .replace('ى', 'ي')
      .replace('ؤ', 'و')
      .replace('ئ', 'ي')
      .replace(Regex("[\\?\\!\\.\\,\\،\\:]"), " ")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  fun classify(rawInput: String, session: ConversationSession?): ClassifiedMessage {
    val norm = normalize(rawInput)

    // 1. Check if assistant is currently awaiting song title from a previous turn
    if (session?.pendingExpectation == PendingExpectation.AWAITING_SONG_TITLE) {
      val isCancellation = norm.contains("الغاء") || norm.contains("إلغاء") || norm.contains("بطلت") || norm.contains("لا شيء") || norm.contains("cancel")
      if (!isCancellation && rawInput.isNotBlank()) {
        val cleanedTitle = extractSongTitleOnly(rawInput)
        return ClassifiedMessage(
          type = MessageIntentType.FOLLOW_UP_QUERY,
          primarySubject = "song_title_provided",
          extractedSongTitle = cleanedTitle
        )
      }
    }

    // 2. Hypothetical Questions: "لو شغلت...", "لو تأخرت...", "لو...", "if I..."
    val isHypothetical = norm.contains("لو شغلت") || norm.startsWith("لو ") ||
      norm.contains("إذا شغلت") || norm.contains("اذا شغلت") || norm.contains("لو فتحت") ||
      norm.contains("لو تاخرت") || norm.contains("لو تأخرت") || norm.contains("اذا تاخرت") ||
      norm.contains("اذا تأخرت") || norm.contains("ماذا لو") || norm.contains("شو بصير لو") ||
      norm.contains("شو يصير لو") || norm.contains("لو اشغل") ||
      norm.contains("what if") || norm.contains("what happens if") || norm.contains("what would happen if") ||
      norm.contains("if i play") || norm.contains("if i delay") || norm.contains("if i turn on")

    if (isHypothetical) {
      when {
        norm.contains("موسيقى") || norm.contains("اغنيه") || norm.contains("أغنية") || norm.contains("music") || norm.contains("song") -> {
          return ClassifiedMessage(
            type = MessageIntentType.HYPOTHETICAL_QUESTION,
            primarySubject = "battery_music_impact",
            isHypothetical = true
          )
        }
        norm.contains("تاخرت") || norm.contains("تأخرت") || norm.contains("delay") || norm.contains("late") -> {
          val delayMins = extractMinutes(norm) ?: 10
          return ClassifiedMessage(
            type = MessageIntentType.HYPOTHETICAL_QUESTION,
            primarySubject = "schedule_delay_impact",
            isHypothetical = true,
            extractedDelayMinutes = delayMins
          )
        }
        norm.contains("كشاف") || norm.contains("ضوء") || norm.contains("فلاش") || norm.contains("torch") || norm.contains("flashlight") -> {
          return ClassifiedMessage(
            type = MessageIntentType.HYPOTHETICAL_QUESTION,
            primarySubject = "battery_flashlight_impact",
            isHypothetical = true
          )
        }
        else -> {
          return ClassifiedMessage(
            type = MessageIntentType.HYPOTHETICAL_QUESTION,
            primarySubject = "general_hypothetical",
            isHypothetical = true
          )
        }
      }
    }

    // 3. Follow-up to Previous Turns
    val isPronounFollowUp = norm == "وماذا عنه" || norm == "وماذا عنها" ||
      norm == "وكم فيه" || norm == "شو عنه" || norm == "شو مواصفاته" || norm == "تفاصيل عنه" ||
      norm == "المزيد عنه" || norm.startsWith("عنه ") || norm.startsWith("عنها ") ||
      norm == "and what do you know about it" || norm == "what about it"

    if (isPronounFollowUp) {
      if (session?.currentTopic == "device_info" || session?.lastReferencedSubject == "phone") {
        return ClassifiedMessage(
          type = MessageIntentType.FOLLOW_UP_QUERY,
          primarySubject = "device_detailed_specs"
        )
      }
    }

    // 4. User Identity: "من أنا؟"
    if (norm == "من انا" || norm == "من اكون" || norm == "هل تعرفني" ||
      norm == "مين انا" || norm == "بتعرفني" || norm == "ما اسمي" ||
      norm == "who am i" || norm == "do you know me" || norm == "what is my name"
    ) {
      return ClassifiedMessage(
        type = MessageIntentType.INFORMATIONAL_QUESTION,
        primarySubject = "user_identity"
      )
    }

    // 5. Phone Model & Detailed Specs
    if (norm.contains("شو نوع جوالي") || norm.contains("ما نوع هاتفي") || norm.contains("ما هو جوالي") || norm.contains("نوع جهازي") ||
      norm.contains("موديل الهاتف") || norm.contains("طراز الهاتف") || norm.contains("شو هاتفي") || norm.contains("شو جهازي") ||
      norm.contains("ماهو هاتفي") || norm.contains("what phone is this") || norm.contains("what is my phone") || norm.contains("phone model")
    ) {
      return ClassifiedMessage(
        type = MessageIntentType.INFORMATIONAL_QUESTION,
        primarySubject = "phone_model"
      )
    }

    if (norm.contains("ماذا تعرف عن جهازي") || norm.contains("مواصفات جهازي") ||
      norm.contains("تفاصيل جهازي") || norm.contains("معلومات الهاتف") || norm.contains("قطع جهازي") ||
      norm.contains("what do you know about my phone") || norm.contains("device specs") || norm.contains("phone specs")
    ) {
      return ClassifiedMessage(
        type = MessageIntentType.INFORMATIONAL_QUESTION,
        primarySubject = "device_detailed_specs"
      )
    }

    // 6. Specific Song Queries & Playback
    if (norm.contains("شغل لي اغنية") || norm.contains("شغل اغنية") ||
      norm.contains("بدي اغنية") || norm.contains("شغل لي انشودة") ||
      norm == "شغل اغنية" || norm == "play a song" || norm == "play specific song"
    ) {
      return ClassifiedMessage(
        type = MessageIntentType.INFORMATIONAL_QUESTION,
        primarySubject = "request_song_title"
      )
    }

    val hasExplicitSongTitlePrefix = norm.startsWith("شغل اغنية ") || norm.startsWith("شغل لي اغنية ") ||
      norm.startsWith("play song ") || norm.startsWith("play the song ")
    if (hasExplicitSongTitlePrefix) {
      val title = extractSongTitleOnly(rawInput)
      if (title.isNotBlank()) {
        return ClassifiedMessage(
          type = MessageIntentType.ACTION_EXECUTION,
          primarySubject = "play_specific_song",
          extractedSongTitle = title
        )
      }
    }

    // 7. General Media Playback Direct Commands
    val isMediaPlayCommand = (norm.contains("شغل الموسيقى") || norm.contains("تشغيل الموسيقى") ||
      norm.contains("تابع الموسيقى") || norm.contains("شغل الصوت") ||
      norm == "شغل" || norm.contains("استئناف") ||
      norm == "play music" || norm == "play" || norm == "resume music") &&
      !isHypothetical

    if (isMediaPlayCommand) {
      return ClassifiedMessage(
        type = MessageIntentType.ACTION_EXECUTION,
        primarySubject = "media_play"
      )
    }

    // Default classification
    return ClassifiedMessage(
      type = MessageIntentType.INFORMATIONAL_QUESTION,
      primarySubject = "general"
    )
  }

  fun extractSongTitleOnly(rawInput: String): String {
    val norm = normalize(rawInput)
    val normalizedPrefixes = listOf(
      "شغل لي اغنية ", "شغل اغنية ", "شغل لي أنشودة ", "شغل أنشودة ",
      "أريد أغنية ", "play song ", "play the song ", "song "
    )
    for (p in normalizedPrefixes) {
      if (norm.startsWith(p)) {
        val rawTokens = rawInput.trim().split(Regex("\\s+"))
        val prefixCount = p.trim().split(Regex("\\s+")).size
        if (rawTokens.size > prefixCount) {
          return rawTokens.drop(prefixCount).joinToString(" ").replace(Regex("[\\?\\!\\.\\,\\،\\:]"), "").trim()
        }
        return norm.substring(p.length).trim()
      }
    }
    return rawInput.replace(Regex("[\\?\\!\\.\\,\\،\\:]"), "").trim()
  }

  private fun extractMinutes(norm: String): Int? {
    val converted = norm.map { char ->
      when (char) {
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> char
      }
    }.joinToString("")

    val regex = Regex("""(\d{1,3})""")
    val match = regex.find(converted)
    if (match != null) {
      val num = match.groupValues[1].toIntOrNull()
      if (num != null && num in 1..180) {
        return num
      }
    }
    return when {
      converted.contains("عشر دقائق") || converted.contains("10 دقائق") || converted.contains("عشرة دقائق") || converted.contains("10 min") -> 10
      converted.contains("خمس دقائق") || converted.contains("5 دقائق") || converted.contains("خمسة دقائق") -> 5
      converted.contains("ربع ساعة") || converted.contains("15 دقيقة") -> 15
      converted.contains("نصف ساعة") || converted.contains("30 دقيقة") -> 30
      converted.contains("ساعة") || converted.contains("60 دقيقة") -> 60
      else -> null
    }
  }
}
