package com.example.core.intelligence.conversation

import com.example.device.info.DeviceInfoProvider
import java.util.Locale

/**
 * High-level conversational reasoning engine.
 * Handles semantic intent classification, multi-turn resolution, empathetic response crafting,
 * dialect understanding, and genuine on-device decision-making without misleading canned templates.
 */
class ConversationalReasoner(
  private val deviceInfoProvider: DeviceInfoProvider? = null
) {
  data class ReasoningResult(
    val replyText: String,
    val topicDetected: String?,
    val proactiveSuggestions: List<ActionableOption>
  )

  fun reason(
    userQuery: String,
    session: ConversationSession
  ): ReasoningResult {
    val hasArabicChars = userQuery.any { it in '\u0600'..'\u06FF' }
    val isArabic = hasArabicChars || Locale.getDefault().language.startsWith("ar")
    val query = userQuery.trim()
    val normalized = LocalKnowledgeBase.normalizeArabic(query)

    // 1. Math and Calculation Check
    val mathResult = LocalKnowledgeBase.evaluateArithmetic(query)
    if (mathResult != null) {
      return ReasoningResult(
        replyText = mathResult,
        topicDetected = "calculation",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "حساب آخر" else "Another calculation", "احسب 50 * 12"),
          ActionableOption(if (isArabic) "حالة الذاكرة" else "Memory status", "حالة الذاكرة")
        )
      )
    }

    // 2. Multi-turn Follow-up Resolution
    if (isFollowUpQuery(normalized, session)) {
      val resolvedFollowUp = resolveFollowUp(normalized, session, isArabic)
      if (resolvedFollowUp != null) {
        return resolvedFollowUp
      }
    }

    // 3. User Identity Check: "من أنا؟"
    if (isUserIdentityQuery(normalized)) {
      val identityText = deviceInfoProvider?.getUserIdentityDescription(isArabic)
        ?: if (isArabic) {
          "أنت مستخدم هذا الجهاز العزيز. WEYKY يحترم خصوصيتك بالكامل ولا يجمع أي بيانات شخصية أو بروفايل عنك."
        } else {
          "You are the user of this device. No personal identity is currently registered in WEYKY, respecting your privacy."
        }
      return ReasoningResult(
        replyText = identityText,
        topicDetected = "identity",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "طراز هاتفي؟" else "Phone model?", "ما هو طراز هاتفي؟"),
          ActionableOption(if (isArabic) "عن جهازي؟" else "About my phone?", "تفاصيل جهازي")
        )
      )
    }

    // 4. Phone Model & Detailed Specs Check
    if (isPhoneModelQuery(normalized)) {
      val modelSummary = deviceInfoProvider?.getPhoneModelSummary(isArabic)
        ?: if (isArabic) {
          "هاتفك يعمل بنظام Android."
        } else {
          "Your phone is running Android."
        }
      return ReasoningResult(
        replyText = modelSummary,
        topicDetected = "device_info",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "تفاصيل أكثر؟" else "What else?", "تفاصيل جهازي"),
          ActionableOption(if (isArabic) "البطارية" else "Battery", "حالة البطارية")
        )
      )
    }

    if (isPhoneDetailedSpecsQuery(normalized)) {
      val detailedSpecs = deviceInfoProvider?.getDetailedTechnicalSpecs(isArabic)
        ?: if (isArabic) {
          "مواصفات الجهاز غير متوفرة حالياً من نظام التشغيل."
        } else {
          "Device specifications are currently unavailable from system APIs."
        }
      return ReasoningResult(
        replyText = detailedSpecs,
        topicDetected = "device_info",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "البطارية" else "Battery", "حالة البطارية"),
          ActionableOption(if (isArabic) "استهلاك الرام" else "RAM usage", "حالة الرام")
        )
      )
    }

    // 5. Greetings & Chitchat
    val greetingReply = handleGreetingsAndChitchat(normalized, isArabic)
    if (greetingReply != null) {
      return greetingReply
    }

    // 6. Emotional Empathy & Mood Support
    val empathyReply = handleEmotionalSupport(normalized, isArabic)
    if (empathyReply != null) {
      return empathyReply
    }

    // 7. Direct Curated Knowledge Base Match
    val kbTopic = LocalKnowledgeBase.findMatchingTopic(query)
    if (kbTopic != null) {
      val text = if (isArabic) kbTopic.arabicSummary else kbTopic.englishSummary
      return ReasoningResult(
        replyText = text,
        topicDetected = kbTopic.id,
        proactiveSuggestions = kbTopic.suggestedFollowUps
      )
    }

    // 8. Principled Decision & Honest Fallback without Canned Deception
    return generatePrincipledResponse(query, normalized, isArabic)
  }

  private fun isUserIdentityQuery(query: String): Boolean {
    return query == "من انا" || query == "من اكون" || query == "بتعرفني" || query == "هل تعرفني" ||
      query == "مين انا" || query == "ما اسمي" || query == "شو اسمي" ||
      query == "who am i" || query == "do you know me" || query == "what is my name"
  }

  private fun isPhoneModelQuery(query: String): Boolean {
    return query.contains("شو نوع جوالي") || query.contains("ما هو جوالي") || query.contains("نوع هاتفي") ||
      query.contains("طراز الهاتف") || query.contains("موديل جهازي") || query.contains("شو جهازي") ||
      query.contains("what is my phone") || query.contains("phone model")
  }

  private fun isPhoneDetailedSpecsQuery(query: String): Boolean {
    return query.contains("ماذا تعرف عن جهازي") || query.contains("مواصفات جهازي") ||
      query.contains("تفاصيل جهازي") || query.contains("معلومات الهاتف") || query.contains("قطع جهازي") ||
      query.contains("what do you know about my phone") || query.contains("device specs")
  }

  private fun isFollowUpQuery(query: String, session: ConversationSession): Boolean {
    if (session.currentTopic == "device_info" || session.lastReferencedSubject == "phone") {
      if (query.contains("عنه") || query.contains("تفاصيل") || query.contains("المزيد") || query.contains("about it")) {
        return true
      }
    }
    val followUpStarters = listOf(
      "وماذا عن", "وكم", "واين", "وكيف", "اخبرني اكثر", "زيدني", "المزيد", "ليش", "لماذا",
      "tell me more", "and how", "what about", "elaborate", "can you give more details", "why"
    )
    val hasPronounOrFollowUpMarker = query.contains("هذا") || query.contains("ذلك") ||
      query.contains("عنها") || query.contains("فيها") ||
      query.contains("there") || query.contains("that")
    return hasPronounOrFollowUpMarker || followUpStarters.any { query.startsWith(it) } || query.length < 15
  }

  private fun resolveFollowUp(
    query: String,
    session: ConversationSession,
    isArabic: Boolean
  ): ReasoningResult? {
    val topic = session.currentTopic ?: return null

    if (topic == "device_info" || session.lastReferencedSubject == "phone") {
      if (query.contains("عنه") || query.contains("المزيد") || query.contains("تفاصيل") || query.contains("about it")) {
        val detailedSpecs = deviceInfoProvider?.getDetailedTechnicalSpecs(isArabic)
          ?: if (isArabic) {
            "هاتفك يعمل بنظام Android بمواصفات جيدة."
          } else {
            "Phone specs: Running Android."
          }
        return ReasoningResult(
          replyText = detailedSpecs,
          topicDetected = "device_info",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "البطارية" else "Battery", "حالة البطارية"),
            ActionableOption(if (isArabic) "استهلاك الرام" else "RAM usage", "حالة الرام")
          )
        )
      }
    }

    when (topic) {
      "travel" -> {
        if (query.contains("طقس") || query.contains("جو") || query.contains("بارد") || query.contains("مطر") || query.contains("weather") || query.contains("cold")) {
          val reply = if (isArabic) {
            "في صلالة خلال موسم الخريف، يكون الجو معتدلاً ولطيفاً مائلاً للبرودة الرطبة في الجبال (~22-25°م) مع ضباب مستمر ورذاذ. احرص على اصطحاب سترة خفيفة ومقاومة للماء."
          } else {
            "In Salalah during the Khareef season, the weather is pleasantly mild and mist-covered (approx 22°C), cooler in mountain areas. Pack light layers and a rain-resistant jacket."
          }
          return ReasoningResult(
            replyText = reply,
            topicDetected = "travel",
            proactiveSuggestions = listOf(
              ActionableOption(if (isArabic) "الطقس المحلي" else "Local weather", "الطقس الآن"),
              ActionableOption(if (isArabic) "هل أخرج؟" else "Should I leave?", "هل أخرج الآن؟")
            )
          )
        }
        if (query.contains("وقت") || query.contains("شهر") || query.contains("متى") || query.contains("when")) {
          val reply = if (isArabic) {
            "ذروة موسم الخريف واخضرار صلالة تكون بين شهري يوليو وأغسطس، حيث تكون الشلالات والعيون في أبهى صورها."
          } else {
            "The best time to visit Salalah for lush greenery is between July and August during the peak of Khareef season."
          }
          return ReasoningResult(
            replyText = reply,
            topicDetected = "travel",
            proactiveSuggestions = listOf(
              ActionableOption(if (isArabic) "أهم المعالم" else "Top attractions", "حدثني عن صلالة"),
              ActionableOption(if (isArabic) "مواعيدي القادمة" else "Next appointments", "ما هي مواعيدي؟")
            )
          )
        }
      }
      "sleep_wellness" -> {
        if (query.contains("قهوة") || query.contains("منبهات") || query.contains("كافيين") || query.contains("coffee") || query.contains("caffeine")) {
          val reply = if (isArabic) {
            "يبقى الكافيين في الجسم لعدة ساعات (نصف عمره الحيوي بين 6 إلى 8 ساعات). يُفضل التوقف عن شرب القهوة بعد الساعة 2 ظهراً لضمان نوم عميق ومريح."
          } else {
            "Caffeine has a half-life of 6 to 8 hours. It is best to avoid coffee after 2 PM to protect deep sleep stages."
          }
          return ReasoningResult(
            replyText = reply,
            topicDetected = "sleep_wellness",
            proactiveSuggestions = listOf(
              ActionableOption(if (isArabic) "إطفاء الكشاف" else "Turn off torch", "أغلق الكشاف"),
              ActionableOption(if (isArabic) "الوقت الآن" else "Current time", "كم الساعة؟")
            )
          )
        }
      }
      "productivity" -> {
        if (query.contains("المزيد") || query.contains("نصيحة ثانية") || query.contains("غيرها") || query.contains("more") || query.contains("tips")) {
          val reply = if (isArabic) {
            "نصيحة إضافية: تجنب تعدد المهام (Multitasking). أظهرت الدراسات أن التركيز على مهمة واحدة يرفع سرعة الإنجاز بنسبة تصل إلى 40% ويقلل الإجهاد الذهني بشكل ملحوظ."
          } else {
            "Additional tip: Avoid multitasking. Research indicates single-task focus boosts efficiency by up to 40% while lowering cognitive strain."
          }
          return ReasoningResult(
            replyText = reply,
            topicDetected = "productivity",
            proactiveSuggestions = listOf(
              ActionableOption(if (isArabic) "افتح التقويم" else "Open Calendar", "افتح التقويم"),
              ActionableOption(if (isArabic) "افحص البطارية" else "Check battery", "حالة البطارية")
            )
          )
        }
      }
    }
    return null
  }

  private fun handleGreetingsAndChitchat(
    query: String,
    isArabic: Boolean
  ): ReasoningResult? {
    when {
      query.contains("مرحبا") || query.contains("اهلا") || query.contains("سلام") || query.contains("السلام عليكم") || query.contains("صباح الخير") || query.startsWith("hello") || query.startsWith("hi") -> {
        val reply = if (isArabic) {
          "أهلاً بك! أنا WEYKY، نواتك الذكية في خدمتك. كيف يمكنني مساعدتك الآن؟"
        } else {
          "Hello! I am WEYKY, at your service. How can I assist you today?"
        }
        return ReasoningResult(
          replyText = reply,
          topicDetected = "chitchat",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "ما وضعي الآن؟" else "Current situation", "ما وضعي الآن؟"),
            ActionableOption(if (isArabic) "توقعات الطقس" else "Weather forecast", "كيف الطقس الآن؟"),
            ActionableOption(if (isArabic) "مستوى البطارية" else "Battery level", "حالة البطارية")
          )
        )
      }
      query.contains("كيفك") || query.contains("شخبارك") || query.contains("كيف حالك") || query.contains("how are you") -> {
        val reply = if (isArabic) {
          "أنا بخير وجاهز تماماً لمساعدتك ومرافقتك في مهامك اليومية! كيف حالك أنت؟"
        } else {
          "I'm doing great and fully ready to assist you! How are things with you?"
        }
        return ReasoningResult(
          replyText = reply,
          topicDetected = "chitchat",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "أخبرني قصة" else "Tell a story", "أخبرني قصة"),
            ActionableOption(if (isArabic) "هل أخرج الآن؟" else "Should I go out?", "هل أخرج الآن؟")
          )
        )
      }
      query.contains("شكرا") || query.contains("تسلم") || query.contains("مشكور") || query.contains("يعطيك العافية") || query.contains("thank") -> {
        val reply = if (isArabic) {
          "على الرحب والسعة دائماً! أنا هنا دوماً لمساعدتك في أي وقت تحتاج فيه لإدارة هاتفك أو معرفة السياق."
        } else {
          "You're very welcome! I'm always here whenever you need assistance or quick reasoning."
        }
        return ReasoningResult(
          replyText = reply,
          topicDetected = "chitchat",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "نظرة عامة على الجهاز" else "Device overview", "تفاصيل جهازي"),
            ActionableOption(if (isArabic) "شغل الموسيقى" else "Play music", "شغل الموسيقى")
          )
        )
      }
      query.contains("صباح النور") || query.contains("good morning") -> {
        val reply = if (isArabic) {
          "صباح الخير والنشاط! أتمنى لك يوماً مثمراً وموفقاً. هل ترغب بموجز سريع عن الطقس والمواعيد؟"
        } else {
          "Good morning! Wishing you an energized and productive day. Would you like a quick overview of today's weather and schedule?"
        }
        return ReasoningResult(
          replyText = reply,
          topicDetected = "chitchat",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "الطقس اليوم" else "Weather today", "كيف الطقس الآن؟"),
            ActionableOption(if (isArabic) "المواعيد" else "Check schedule", "ما هي مواعيدي؟"),
            ActionableOption(if (isArabic) "البطارية" else "Battery", "حالة البطارية")
          )
        )
      }
      query.contains("تصبح على خير") || query.contains("مساء الخير") || query.contains("good evening") || query.contains("good night") -> {
        val reply = if (isArabic) {
          "مساء النور والراحة! أتمنى لك ليلة هادئة ونوماً عميقاً يجدد طاقتك. هل ترغب في تفعيل موفر الطاقة؟"
        } else {
          "Good evening! I hope you had a fruitful day. Would you like help preparing for rest or setting your alarms?"
        }
        return ReasoningResult(
          replyText = reply,
          topicDetected = "chitchat",
          proactiveSuggestions = listOf(
            ActionableOption(if (isArabic) "نصائح النوم" else "Sleep tips", "نصائح للنوم العميق"),
            ActionableOption(if (isArabic) "إطفاء الكشاف" else "Turn off torch", "أغلق الكشاف")
          )
        )
      }
    }
    return null
  }

  private fun handleEmotionalSupport(
    query: String,
    isArabic: Boolean
  ): ReasoningResult? {
    if (query.contains("تعبان") || query.contains("حزين") || query.contains("مضغوط") || query.contains("قلق") || query.contains("طفشان") || query.contains("زهقان") || query.contains("sad") || query.contains("tired") || query.contains("stressed")) {
      val reply = if (isArabic) {
        "أشعر بك، من الطبيعي أن نمر بلحظات تعب وضغط. خذ نفساً عميقاً واسترح قليلاً، أو قم بجولة قصيرة لاستنشاق الهواء النقي. أنا بجانبك دائماً."
      } else {
        "I'm sorry you're feeling that way. Stress and fatigue happen to everyone. Taking a short break, breathing deeply, or a brief walk can help refresh your perspective. I'm here to support you."
      }
      return ReasoningResult(
        replyText = reply,
        topicDetected = "emotional_support",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "شغل الموسيقى" else "Play music", "شغل الموسيقى"),
          ActionableOption(if (isArabic) "قصة قصيرة" else "Short story", "أخبرني قصة"),
          ActionableOption(if (isArabic) "الخروج في جولة؟" else "Go outside?", "هل أخرج الآن؟")
        )
      )
    }
    return null
  }

  private fun generatePrincipledResponse(
    query: String,
    normalized: String,
    isArabic: Boolean
  ): ReasoningResult {
    val isExternalLiveQuery = normalized.contains("اسعار الاسهم") || normalized.contains("سعر الذهب") ||
      normalized.contains("سعر الصرف") || normalized.contains("اخبار عاجلة") || normalized.contains("مباراة اليوم") ||
      normalized.contains("stock price") || normalized.contains("exchange rate") || normalized.contains("breaking news")

    if (isExternalLiveQuery) {
      val reply = if (isArabic) {
        "هذا الاستفسار يتطلب مصادر بيانات ويب خارجية حية غير متوفرة محلياً دون اتصال. أعمل محلياً على جهازك لإدارة الهاتف وتحليل السياق والإجابة عن الأسئلة المعرفية المخزنة."
      } else {
        "This query requires a live internet connection to external real-time data sources, which is not available locally offline. I operate entirely on-device to manage your phone, analyze daily context, and assist with logical inquiries."
      }
      return ReasoningResult(
        replyText = reply,
        topicDetected = "unavailable_external_data",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "نظرة عامة على الجهاز" else "Device overview", "تفاصيل جهازي"),
          ActionableOption(if (isArabic) "الطقس المحلي" else "Local weather", "كيف الطقس الآن؟")
        )
      )
    }

    if (query.trim().split("\\s+".toRegex()).size <= 2 && query.length < 10) {
      val reply = if (isArabic) {
        "طلبك بخصوص '$query' يحتاج إلى توضيح. هل ترغب بمعلومات، أو تنفيذ إجراء على الجهاز كفتح تطبيق أو فحص البطارية؟"
      } else {
        "Your request regarding '$query' is ambiguous. Would you like information, or to execute a device action such as opening an app or checking battery?"
      }
      return ReasoningResult(
        replyText = reply,
        topicDetected = "ambiguous_clarification",
        proactiveSuggestions = listOf(
          ActionableOption(if (isArabic) "ما وضعي؟" else "What's my status?", "ما وضعي الآن؟"),
          ActionableOption(if (isArabic) "فتح تطبيق" else "Open app", "افتح الواتساب")
        )
      )
    }

    val reply = if (isArabic) {
      "بخصوص استفسارك عن '$query'، هذه المعلومة التفصيلية ليست مفهرسة في قاعدة بياناتي المحلية. يمكنني مساعدتك في التحكم بالهاتف، وتتبع سياق يومك (الطقس، البطارية، المواعيد)، والحسابات الرياضية."
    } else {
      "Regarding your inquiry about '$query', this specific detail is not stored in my on-device knowledge base. I can assist with device controls, contextual tracking (weather, battery, calendar), calculations, and lifestyle advice."
    }
    return ReasoningResult(
      replyText = reply,
      topicDetected = "unindexed_query",
      proactiveSuggestions = listOf(
        ActionableOption(if (isArabic) "ماذا تستطيع أن تفعل؟" else "What can you do?", "ماذا تستطيع أن تفعل؟"),
        ActionableOption(if (isArabic) "فحص الجهاز" else "Check device", "تفاصيل جهازي"),
        ActionableOption(if (isArabic) "هل أخرج الآن؟" else "Should I leave?", "هل أخرج الآن؟")
      )
    )
  }
}
