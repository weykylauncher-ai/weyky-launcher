package com.example.core.intelligence

/**
 * Domain of the user query for targeted context scoping.
 */
enum class IntentDomain {
  OUTDOOR_DEPARTURE,     // "هل أخرج الآن؟"
  APPOINTMENT_TIMING,    // "هل ألحق موعدي؟"
  BATTERY_SUFICIENCY,    // "هل تكفي البطارية؟"
  SITUATION_OVERVIEW,    // "ما وضعي الآن؟"
  WEATHER_ONLY,          // "كيف الطقس؟"
  DIRECT_COMMAND,        // volume, flashlight, launch app, etc.
  GENERAL
}

enum class ContextField {
  BATTERY,
  NETWORK,
  PHYSICAL_CONTEXT,
  LOCATION,
  WEATHER,
  CALENDAR,
  MEDIA,
  CALLS,
  NOTIFICATIONS
}

data class ContextRequirements(
  val domain: IntentDomain,
  val required: Set<ContextField>,
  val optional: Set<ContextField> = emptySet(),
  val conditional: Set<ContextField> = emptySet()
) {
  val allNeeded: Set<ContextField> get() = required + optional + conditional
}

object ContextRequirementsRegistry {
  fun resolve(rawInput: String): ContextRequirements {
    val input = rawInput.trim().lowercase()

    // 1. Outdoor departure decision: "هل أخرج" / "اطلع برا" / "should I go out?" / "can I leave now?"
    if (input.contains("اخرج") || input.contains("أخرج") || input.contains("اطلع") ||
      input.contains("go out") || input.contains("leave now") || input.contains("should i leave")
    ) {
      return ContextRequirements(
        domain = IntentDomain.OUTDOOR_DEPARTURE,
        required = setOf(ContextField.WEATHER, ContextField.CALENDAR, ContextField.BATTERY),
        optional = setOf(ContextField.PHYSICAL_CONTEXT, ContextField.LOCATION),
        conditional = setOf(ContextField.NETWORK)
      )
    }

    // 2. Appointment timing / Arrival probability: "ألحق موعدي" / "هل أصل في الوقت" / "will I make it on time?"
    if (input.contains("الحق") || input.contains("ألحق") || input.contains("موعد") || input.contains("الموعد") ||
      input.contains("وصلت") || input.contains("أصل") || input.contains("تاخرت") || input.contains("make it on time") || input.contains("reach in time")
    ) {
      return ContextRequirements(
        domain = IntentDomain.APPOINTMENT_TIMING,
        required = setOf(ContextField.CALENDAR, ContextField.PHYSICAL_CONTEXT),
        optional = setOf(ContextField.LOCATION, ContextField.BATTERY),
        conditional = setOf(ContextField.WEATHER)
      )
    }

    // 3. Battery sufficiency evaluation: "تكفي البطارية" / "will my battery last?" / "is battery enough?"
    if ((input.contains("بطارية") || input.contains("البطارية") || input.contains("battery")) &&
      (input.contains("تكفي") || input.contains("تصمد") || input.contains("تكمل") || input.contains("last") || input.contains("enough"))
    ) {
      return ContextRequirements(
        domain = IntentDomain.BATTERY_SUFICIENCY,
        required = setOf(ContextField.BATTERY, ContextField.CALENDAR),
        optional = setOf(ContextField.PHYSICAL_CONTEXT, ContextField.NETWORK),
        conditional = setOf(ContextField.MEDIA)
      )
    }

    // 4. Broad situational overview / "What should I do now?": "ما وضعي" / "شو أعمل" / "what should I do now?"
    if (input.contains("وضعي") || input.contains("شو في") || input.contains("ماذا أفعل") || input.contains("ماذا افعل") ||
      input.contains("الملخص") || input.contains("الموجز") || input.contains("what should i do") || input.contains("what's next")
    ) {
      return ContextRequirements(
        domain = IntentDomain.SITUATION_OVERVIEW,
        required = setOf(ContextField.CALENDAR, ContextField.CALLS, ContextField.NOTIFICATIONS, ContextField.BATTERY),
        optional = setOf(ContextField.WEATHER, ContextField.PHYSICAL_CONTEXT),
        conditional = setOf(ContextField.MEDIA)
      )
    }

    // 5. Weather inquiry: "الطقس" / "الجو" / "what's the weather?"
    if (input.contains("طقس") || input.contains("الطقس") || input.contains("جو") || input.contains("الجو") ||
      input.contains("weather") || input.contains("temperature")
    ) {
      return ContextRequirements(
        domain = IntentDomain.WEATHER_ONLY,
        required = setOf(ContextField.WEATHER),
        optional = setOf(ContextField.PHYSICAL_CONTEXT),
        conditional = emptySet()
      )
    }

    // Default: General
    return ContextRequirements(
      domain = IntentDomain.GENERAL,
      required = emptySet(),
      optional = emptySet(),
      conditional = emptySet()
    )
  }
}
