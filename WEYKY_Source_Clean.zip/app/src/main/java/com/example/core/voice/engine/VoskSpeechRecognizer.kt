package com.example.core.voice.engine

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import java.io.File
import java.io.IOException
import kotlin.math.roundToInt

sealed interface OfflineRecognitionState {
  object Uninitialized : OfflineRecognitionState
  object LoadingModel : OfflineRecognitionState
  object Ready : OfflineRecognitionState
  object Listening : OfflineRecognitionState
  data class Partial(val text: String) : OfflineRecognitionState
  data class Result(val text: String) : OfflineRecognitionState
  data class Error(val message: String) : OfflineRecognitionState
}

/**
 * Embedded On-Device Speech Recognizer powered by Vosk Engine.
 * Runs completely locally on Android without Google Play Services or network.
 */
class VoskSpeechRecognizer(
  private val context: Context,
  private val onTranscriptReady: (String) -> Unit,
  private val onPartialTranscript: (String) -> Unit = {},
  private val onListeningStateChanged: (Boolean) -> Unit = {},
  private val onVoiceRmsChanged: (Float) -> Unit = {}
) : RecognitionListener {
  companion object {
    private const val TAG = "WEYKY_VOSK_STT"
    private const val SAMPLE_RATE = 16000.0f
    private const val SAMPLE_RATE_HZ = 16000
    private const val BUFFER_SIZE_SECONDS = 0.2f
    private const val NON_SILENT_RMS_THRESHOLD = 0.0045f
    private const val ZERO_SIGNAL_RECOVERY_FRAMES = 6
  }

  data class AudioCaptureDiagnostics(
    val voskSessionId: Long,
    val audioSourceUsed: Int,
    val audioSourceName: String,
    val sampleRateHz: Int,
    val channelConfig: Int,
    val audioEncoding: Int,
    val bufferSizeBytes: Int,
    val firstSampleLatencyMs: Long,
    val firstNonSilentSignalLatencyMs: Long,
    val totalFramesRead: Int,
    val totalSamplesRead: Long,
    val nonSilentFramesCount: Int,
    val zeroSignalFramesCount: Int,
    val peakRmsObserved: Float,
    val hardwareEffectsDisabledDueToZeroSignal: Boolean,
    val switchedToMicSourceFallback: Boolean,
    val terminationReason: String
  )

  private val mainHandler = Handler(Looper.getMainLooper())
  private val sessionLock = Any()
  private var model: Model? = null
  @Volatile
  var loadedModelPath: String? = null
    private set
  @Volatile
  var lastCaptureDiagnostics: AudioCaptureDiagnostics? = null
    private set

  private var activeAudioRecord: AudioRecord? = null
  private var activeRecognizer: Recognizer? = null
  private var captureThread: Thread? = null

  private var echoCanceler: AcousticEchoCanceler? = null
  private var noiseSuppressor: NoiseSuppressor? = null
  private var autoGainControl: AutomaticGainControl? = null

  @Volatile
  var isListeningActive: Boolean = false
    private set
  @Volatile
  private var activeVoskSessionId: Long = 0L
  @Volatile
  private var hasDeliveredFinalForVoskSession: Boolean = false
  @Volatile
  private var latestPartialTextForSession: String = ""
  @Volatile
  private var sessionTapTimestampMs: Long = 0L

  private val _state = MutableStateFlow<OfflineRecognitionState>(OfflineRecognitionState.Uninitialized)
  val state: StateFlow<OfflineRecognitionState> = _state.asStateFlow()

  val isModelLoaded: Boolean
    get() = model != null

  fun isLoadedForDirectory(modelDir: File): Boolean {
    synchronized(sessionLock) {
      if (model == null || loadedModelPath == null) return false
      val resolved = resolveNestedVoskModelDir(modelDir)
      return loadedModelPath == resolved.absolutePath || loadedModelPath == modelDir.absolutePath
    }
  }

  private fun resolveNestedVoskModelDir(baseDir: File, maxDepth: Int = 2): File {
    if (!baseDir.exists() || !baseDir.isDirectory) return baseDir
    val hasDirectArtifacts = File(baseDir, "am").isDirectory ||
      File(baseDir, "conf").isDirectory ||
      File(baseDir, "final.mdl").isFile ||
      File(baseDir, "model.bin").isFile
    if (hasDirectArtifacts || maxDepth <= 0) return baseDir
    val subDirs = baseDir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") && !f.name.startsWith("__MACOSX") }
    if (subDirs != null && subDirs.size == 1) {
      return resolveNestedVoskModelDir(subDirs[0], maxDepth - 1)
    }
    return baseDir
  }

  fun loadModel(modelDir: File): Boolean {
    synchronized(sessionLock) {
      val effectiveDir = resolveNestedVoskModelDir(modelDir)
      if (!effectiveDir.exists() || !effectiveDir.isDirectory) {
        Log.w(TAG, "Cannot load Vosk model: directory does not exist: ${effectiveDir.absolutePath}")
        _state.value = OfflineRecognitionState.Error("مجلد النموذج غير موجود")
        return false
      }
      if (loadedModelPath == effectiveDir.absolutePath && model != null) {
        Log.d(TAG, "Vosk model already loaded for target directory")
        _state.value = OfflineRecognitionState.Ready
        return true
      }
      if (isListeningActive || activeAudioRecord != null || activeRecognizer != null) {
        releaseRecordingResourcesLocked(notifyStop = false, flushFinalResult = false)
      }
      val startMs = System.currentTimeMillis()
      return try {
        _state.value = OfflineRecognitionState.LoadingModel
        Log.i(TAG, "Loading Vosk Model from ${effectiveDir.name}...")
        val oldModel = model
        model = null
        loadedModelPath = null
        try {
          oldModel?.close()
        } catch (_: Exception) {}

        model = Model(effectiveDir.absolutePath)
        loadedModelPath = effectiveDir.absolutePath
        _state.value = OfflineRecognitionState.Ready
        val elapsedMs = System.currentTimeMillis() - startMs
        Log.i(TAG, "Vosk Model [${effectiveDir.name}] initialized in ${elapsedMs}ms")
        true
      } catch (t: Throwable) {
        Log.e(TAG, "Failed to load Vosk model from ${effectiveDir.name}: ${t.message}")
        model = null
        loadedModelPath = null
        _state.value = OfflineRecognitionState.Error("فشل تحميل النموذج: ${t.localizedMessage ?: t.javaClass.simpleName}")
        false
      }
    }
  }

  private fun audioSourceToName(source: Int): String {
    return when (source) {
      MediaRecorder.AudioSource.VOICE_RECOGNITION -> "VOICE_RECOGNITION"
      MediaRecorder.AudioSource.MIC -> "MIC"
      MediaRecorder.AudioSource.DEFAULT -> "DEFAULT"
      else -> "SOURCE_$source"
    }
  }

  private fun isHuaweiOrHonorDevice(): Boolean {
    val manufacturer = android.os.Build.MANUFACTURER.orEmpty()
    val brand = android.os.Build.BRAND.orEmpty()
    return manufacturer.equals("HUAWEI", ignoreCase = true) ||
      brand.equals("HUAWEI", ignoreCase = true) ||
      brand.equals("HONOR", ignoreCase = true)
  }

  private fun createInitializedAudioRecord(
    preferredSources: List<Int>,
    bufferSizeInBytes: Int
  ): Pair<AudioRecord, Int> {
    var lastError: String = "Unknown AudioRecord init error"
    for (source in preferredSources) {
      try {
        val candidate = AudioRecord(
          source,
          SAMPLE_RATE_HZ,
          AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
          bufferSizeInBytes
        )
        if (candidate.state == AudioRecord.STATE_INITIALIZED) {
          Log.i(
            TAG,
            "[AUDIO-DIAG] AudioRecord initialized: source=${audioSourceToName(source)}($source), " +
              "sampleRate=${candidate.sampleRate}Hz, format=PCM_16BIT_MONO, bufferBytes=$bufferSizeInBytes"
          )
          return candidate to source
        } else {
          lastError = "AudioRecord(${audioSourceToName(source)}) state=${candidate.state}"
          try {
            candidate.release()
          } catch (_: Exception) {}
        }
      } catch (t: Throwable) {
        lastError = "AudioRecord(${audioSourceToName(source)}) threw ${t.javaClass.simpleName}: ${t.message}"
        Log.w(TAG, "[AUDIO-DIAG] $lastError")
      }
    }
    throw IOException("Failed to initialize AudioRecord ($lastError). Microphone may be in use.")
  }

  fun startListening(tapTimestampMs: Long = System.currentTimeMillis()): Boolean {
    synchronized(sessionLock) {
      val currentModel = model
      if (currentModel == null) {
        Log.w(TAG, "[AUDIO-DIAG] Cannot start Vosk listening: model not loaded")
        _state.value = OfflineRecognitionState.Error("النموذج الصوتي غير محمل")
        return false
      }
      if (isListeningActive) {
        releaseRecordingResourcesLocked(notifyStop = false, flushFinalResult = false)
      }
      return try {
        sessionTapTimestampMs = tapTimestampMs
        val rawMinBufSize = AudioRecord.getMinBufferSize(
          SAMPLE_RATE_HZ,
          AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT
        )
        val safeMinBufSize = if (rawMinBufSize > 0) rawMinBufSize else SAMPLE_RATE_HZ * 2
        val targetBufferSamples = (SAMPLE_RATE_HZ * BUFFER_SIZE_SECONDS).roundToInt()
        val bufferSizeInBytes = maxOf(safeMinBufSize, targetBufferSamples * 2)

        val (record, chosenSource) = createInitializedAudioRecord(
          preferredSources = listOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC
          ),
          bufferSizeInBytes = bufferSizeInBytes
        )

        val enableNsAndAgc = !isHuaweiOrHonorDevice()
        attachHardwareAudioEffectsSafely(record.audioSessionId, enableNsAndAgc = enableNsAndAgc)

        val recognizer = Recognizer(currentModel, SAMPLE_RATE)
        val sessionId = ++activeVoskSessionId
        hasDeliveredFinalForVoskSession = false
        latestPartialTextForSession = ""
        activeAudioRecord = record
        activeRecognizer = recognizer
        isListeningActive = true

        val thread = Thread({
          runAudioCaptureLoop(
            sessionId = sessionId,
            record = record,
            initialAudioSource = chosenSource,
            recognizer = recognizer,
            bufferSamples = targetBufferSamples,
            bufferSizeInBytes = bufferSizeInBytes,
            tapStartMs = tapTimestampMs
          )
        }, "WeykyVoskCaptureThread-$sessionId")
        captureThread = thread
        thread.start()

        _state.value = OfflineRecognitionState.Listening
        onListeningStateChanged(true)
        true
      } catch (e: IOException) {
        Log.e(TAG, "[AUDIO-DIAG] IOException starting Vosk AudioRecord", e)
        releaseRecordingResourcesLocked(notifyStop = false, flushFinalResult = false)
        _state.value = OfflineRecognitionState.Error("خطأ في الميكروفون: ${e.message}")
        onListeningStateChanged(false)
        false
      } catch (t: Throwable) {
        Log.e(TAG, "[AUDIO-DIAG] Exception starting Vosk AudioRecord", t)
        releaseRecordingResourcesLocked(notifyStop = false, flushFinalResult = false)
        _state.value = OfflineRecognitionState.Error("خطأ صوتي: ${t.localizedMessage ?: t.javaClass.simpleName}")
        onListeningStateChanged(false)
        false
      }
    }
  }

  private fun attachHardwareAudioEffectsSafely(audioSessionId: Int, enableNsAndAgc: Boolean = true) {
    releaseAudioEffectsLocked()
    if (audioSessionId <= 0) return

    try {
      if (AcousticEchoCanceler.isAvailable()) {
        echoCanceler = AcousticEchoCanceler.create(audioSessionId)?.apply { enabled = true }
      }
    } catch (_: Exception) {}

    if (!enableNsAndAgc) return

    try {
      if (NoiseSuppressor.isAvailable()) {
        noiseSuppressor = NoiseSuppressor.create(audioSessionId)?.apply { enabled = true }
      }
    } catch (_: Exception) {}

    try {
      if (AutomaticGainControl.isAvailable()) {
        autoGainControl = AutomaticGainControl.create(audioSessionId)?.apply { enabled = true }
      }
    } catch (_: Exception) {}
  }

  private fun runAudioCaptureLoop(
    sessionId: Long,
    record: AudioRecord,
    initialAudioSource: Int,
    recognizer: Recognizer,
    bufferSamples: Int,
    bufferSizeInBytes: Int,
    tapStartMs: Long
  ) {
    val buffer = ShortArray(bufferSamples.coerceAtLeast(1600))
    var currentRecord = record
    var currentAudioSource = initialAudioSource
    var firstSampleLatencyMs = -1L
    var firstNonSilentLatencyMs = -1L
    var totalFramesRead = 0
    var totalSamplesRead = 0L
    var nonSilentFramesCount = 0
    var zeroSignalFramesCount = 0
    var consecutiveAllZeroFrames = 0
    var peakRmsObserved = 0f
    var effectsDisabledMidStream = false
    var switchedToMicMidStream = false
    var terminationReason = "NORMAL_STOP"

    try {
      currentRecord.startRecording()
      if (currentRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
        if (currentAudioSource != MediaRecorder.AudioSource.MIC) {
          try {
            currentRecord.release()
          } catch (_: Exception) {}
          val (micRecord, micSource) = createInitializedAudioRecord(
            preferredSources = listOf(MediaRecorder.AudioSource.MIC),
            bufferSizeInBytes = bufferSizeInBytes
          )
          synchronized(sessionLock) {
            if (sessionId == activeVoskSessionId && isListeningActive) {
              activeAudioRecord = micRecord
            }
          }
          currentRecord = micRecord
          currentAudioSource = micSource
          switchedToMicMidStream = true
          currentRecord.startRecording()
        }
        if (currentRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
          terminationReason = "RECORDSTATE_NOT_RECORDING"
          mainHandler.post {
            if (sessionId == activeVoskSessionId) {
              onError(IOException("AudioRecord failed to record"))
            }
          }
          return
        }
      }

      while (isListeningActive && sessionId == activeVoskSessionId && !Thread.currentThread().isInterrupted) {
        val nread = currentRecord.read(buffer, 0, buffer.size)
        if (!isListeningActive || sessionId != activeVoskSessionId || Thread.currentThread().isInterrupted) {
          terminationReason = "SESSION_STOPPED_OR_INTERRUPTED"
          break
        }
        if (nread < 0) {
          terminationReason = "READ_ERROR_$nread"
          throw IOException("AudioRecord.read returned error code $nread")
        }
        if (nread == 0) continue

        totalFramesRead++
        totalSamplesRead += nread
        if (firstSampleLatencyMs < 0L) {
          firstSampleLatencyMs = (System.currentTimeMillis() - tapStartMs).coerceAtLeast(0L)
        }

        var sumSq = 0.0
        var maxAbsSample = 0
        for (i in 0 until nread) {
          val rawVal = buffer[i].toInt()
          val absVal = kotlin.math.abs(rawVal)
          if (absVal > maxAbsSample) maxAbsSample = absVal
          val sample = rawVal.toDouble() / Short.MAX_VALUE
          sumSq += sample * sample
        }
        val rms = kotlin.math.sqrt(sumSq / nread).toFloat()
        if (rms > peakRmsObserved) peakRmsObserved = rms
        val isAllZeroFrame = maxAbsSample == 0
        if (isAllZeroFrame) {
          zeroSignalFramesCount++
          consecutiveAllZeroFrames++
        } else {
          consecutiveAllZeroFrames = 0
        }
        if (rms >= NON_SILENT_RMS_THRESHOLD) {
          nonSilentFramesCount++
          if (firstNonSilentLatencyMs < 0L) {
            firstNonSilentLatencyMs = (System.currentTimeMillis() - tapStartMs).coerceAtLeast(0L)
          }
        }

        if (consecutiveAllZeroFrames == ZERO_SIGNAL_RECOVERY_FRAMES && !effectsDisabledMidStream) {
          effectsDisabledMidStream = true
          synchronized(sessionLock) {
            releaseAudioEffectsLocked()
          }
        } else if (
          consecutiveAllZeroFrames == ZERO_SIGNAL_RECOVERY_FRAMES * 2 &&
          !switchedToMicMidStream &&
          currentAudioSource != MediaRecorder.AudioSource.MIC
        ) {
          switchedToMicMidStream = true
          try {
            currentRecord.stop()
          } catch (_: Exception) {}
          try {
            currentRecord.release()
          } catch (_: Exception) {}
          val (micRecord, micSource) = createInitializedAudioRecord(
            preferredSources = listOf(MediaRecorder.AudioSource.MIC),
            bufferSizeInBytes = bufferSizeInBytes
          )
          synchronized(sessionLock) {
            if (sessionId == activeVoskSessionId && isListeningActive) {
              activeAudioRecord = micRecord
            }
          }
          currentRecord = micRecord
          currentAudioSource = micSource
          currentRecord.startRecording()
          consecutiveAllZeroFrames = 0
        }

        val normalizedEnergy = (rms * 4.2f).coerceIn(0f, 1f)
        mainHandler.post {
          if (isListeningActive && sessionId == activeVoskSessionId) {
            onVoiceRmsChanged(normalizedEnergy)
          }
        }

        val isEndpoint = recognizer.acceptWaveForm(buffer, nread)
        if (isEndpoint) {
          val resultJson = recognizer.result
          val text = extractTextFromJson(resultJson, "text")
          if (text.isNotBlank()) {
            terminationReason = "ENDPOINT_UTTERANCE_DETECTED"
            deliverFinalTextOnce(sessionId, text, source = "endpoint_result")
            break
          }
        } else {
          val partialJson = recognizer.partialResult
          val partialText = extractTextFromJson(partialJson, "partial")
          if (partialText.isNotBlank()) {
            latestPartialTextForSession = partialText
            mainHandler.post {
              if (sessionId == activeVoskSessionId && !hasDeliveredFinalForVoskSession) {
                onPartialResult(partialJson)
              }
            }
          }
        }
      }
    } catch (e: Exception) {
      terminationReason = "EXCEPTION_${e.javaClass.simpleName}"
      Log.e(TAG, "[AUDIO-DIAG] Capture loop error: ${e.message}", e)
      if (isListeningActive && sessionId == activeVoskSessionId) {
        mainHandler.post {
          if (sessionId == activeVoskSessionId) {
            onError(e)
          }
        }
      }
    } finally {
      try {
        if (currentRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
          currentRecord.stop()
        }
      } catch (_: Exception) {}
      val diag = AudioCaptureDiagnostics(
        voskSessionId = sessionId,
        audioSourceUsed = currentAudioSource,
        audioSourceName = audioSourceToName(currentAudioSource),
        sampleRateHz = SAMPLE_RATE_HZ,
        channelConfig = AudioFormat.CHANNEL_IN_MONO,
        audioEncoding = AudioFormat.ENCODING_PCM_16BIT,
        bufferSizeBytes = bufferSizeInBytes,
        firstSampleLatencyMs = firstSampleLatencyMs,
        firstNonSilentSignalLatencyMs = firstNonSilentLatencyMs,
        totalFramesRead = totalFramesRead,
        totalSamplesRead = totalSamplesRead,
        nonSilentFramesCount = nonSilentFramesCount,
        zeroSignalFramesCount = zeroSignalFramesCount,
        peakRmsObserved = peakRmsObserved,
        hardwareEffectsDisabledDueToZeroSignal = effectsDisabledMidStream,
        switchedToMicSourceFallback = switchedToMicMidStream,
        terminationReason = terminationReason
      )
      lastCaptureDiagnostics = diag
    }
  }

  fun stopListening(): Boolean {
    synchronized(sessionLock) {
      if (!isListeningActive && activeAudioRecord == null && activeRecognizer == null) return false
      return releaseRecordingResourcesLocked(notifyStop = true, flushFinalResult = true)
    }
  }

  fun cancel() {
    synchronized(sessionLock) {
      activeVoskSessionId++
      hasDeliveredFinalForVoskSession = true
      latestPartialTextForSession = ""
      if (!isListeningActive && activeAudioRecord == null && activeRecognizer == null) return
      releaseRecordingResourcesLocked(notifyStop = true, flushFinalResult = false)
    }
  }

  private fun releaseRecordingResourcesLocked(
    notifyStop: Boolean,
    flushFinalResult: Boolean
  ): Boolean {
    val sessionIdAtRelease = activeVoskSessionId
    isListeningActive = false

    val record = activeAudioRecord
    if (record != null) {
      try {
        if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
          record.stop()
        }
      } catch (_: Exception) {}
    }

    val thread = captureThread
    captureThread = null
    if (thread != null && thread != Thread.currentThread()) {
      thread.interrupt()
      try {
        thread.join(400)
      } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
      }
    }

    var flushedText: String = ""
    val rec = activeRecognizer
    activeRecognizer = null
    if (rec != null) {
      if (flushFinalResult && !hasDeliveredFinalForVoskSession) {
        try {
          val finalJson = rec.finalResult
          val extracted = extractTextFromJson(finalJson, "text")
          flushedText = extracted.ifBlank { latestPartialTextForSession.trim() }
        } catch (e: Exception) {
          flushedText = latestPartialTextForSession.trim()
        }
      }
      try {
        rec.close()
      } catch (_: Exception) {}
    }

    releaseAudioEffectsLocked()
    activeAudioRecord = null
    if (record != null) {
      try {
        record.release()
      } catch (_: Exception) {}
    }
    latestPartialTextForSession = ""
    val deliveredNow = if (flushFinalResult && flushedText.isNotBlank() && !hasDeliveredFinalForVoskSession) {
      deliverFinalTextOnce(sessionIdAtRelease, flushedText, source = "flush_final_result")
    } else {
      false
    }
    if (_state.value is OfflineRecognitionState.Listening) {
      _state.value = if (model != null) OfflineRecognitionState.Ready else OfflineRecognitionState.Uninitialized
    }
    if (notifyStop) {
      mainHandler.post {
        onVoiceRmsChanged(0f)
        onListeningStateChanged(false)
      }
    }
    return deliveredNow
  }

  private fun deliverFinalTextOnce(sessionId: Long, rawText: String, source: String): Boolean {
    val clean = rawText.trim()
    if (clean.isBlank()) return false
    synchronized(sessionLock) {
      if (sessionId != activeVoskSessionId || hasDeliveredFinalForVoskSession) {
        return false
      }
      hasDeliveredFinalForVoskSession = true
      isListeningActive = false
    }
    mainHandler.post {
      _state.value = OfflineRecognitionState.Result(clean)
      onTranscriptReady(clean)
    }
    return true
  }

  private fun releaseAudioEffectsLocked() {
    try {
      echoCanceler?.release()
    } catch (_: Exception) {}
    echoCanceler = null
    try {
      noiseSuppressor?.release()
    } catch (_: Exception) {}
    noiseSuppressor = null
    try {
      autoGainControl?.release()
    } catch (_: Exception) {}
    autoGainControl = null
  }

  fun destroy() {
    synchronized(sessionLock) {
      activeVoskSessionId++
      hasDeliveredFinalForVoskSession = true
      releaseRecordingResourcesLocked(notifyStop = true, flushFinalResult = false)
      try {
        model?.close()
      } catch (_: Exception) {}
      model = null
      loadedModelPath = null
      _state.value = OfflineRecognitionState.Uninitialized
    }
  }

  override fun onPartialResult(hypothesis: String?) {
    if (hypothesis.isNullOrBlank()) return
    val text = extractTextFromJson(hypothesis, "partial")
    if (text.isNotBlank()) {
      latestPartialTextForSession = text
      _state.value = OfflineRecognitionState.Partial(text)
      onPartialTranscript(text)
    }
  }

  override fun onResult(hypothesis: String?) {
    if (hypothesis.isNullOrBlank()) return
    val text = extractTextFromJson(hypothesis, "text")
    if (text.isNotBlank()) {
      deliverFinalTextOnce(activeVoskSessionId, text, source = "onResult")
    }
  }

  override fun onFinalResult(hypothesis: String?) {
    if (hypothesis.isNullOrBlank()) return
    val text = extractTextFromJson(hypothesis, "text")
    if (text.isNotBlank()) {
      deliverFinalTextOnce(activeVoskSessionId, text, source = "onFinalResult")
    }
  }

  override fun onError(exception: java.lang.Exception?) {
    val msg = exception?.localizedMessage ?: "Unknown Vosk recognition error"
    Log.e(TAG, "Vosk Recognition error: $msg", exception)
    _state.value = OfflineRecognitionState.Error(msg)
    onListeningStateChanged(false)
  }

  override fun onTimeout() {
    stopListening()
  }

  internal fun extractTextFromJson(jsonStr: String?, key: String): String {
    if (jsonStr.isNullOrBlank()) return ""
    return try {
      val obj = JSONObject(jsonStr)
      obj.optString(key, "").trim()
    } catch (_: Exception) {
      ""
    }
  }
}
