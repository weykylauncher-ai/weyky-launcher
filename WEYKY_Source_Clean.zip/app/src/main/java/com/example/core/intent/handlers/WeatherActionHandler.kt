package com.example.core.intent.handlers

import android.Manifest
import android.content.Context
import com.example.core.intent.ExecutionResult
import com.example.core.intent.WeatherQueryType
import com.example.device.weather.LocationProvider
import com.example.device.weather.WeatherProvider
import com.example.device.weather.WeatherSnapshot
import com.example.rendering.visual_state.CoreVisualState
import java.util.Locale

class WeatherActionHandler(
  private val weatherProvider: WeatherProvider,
  private val locationProvider: LocationProvider
) {

  suspend fun handle(queryType: WeatherQueryType = WeatherQueryType.CURRENT): ExecutionResult {
    val isArabic = Locale.getDefault().language.startsWith("ar")
    if (!locationProvider.hasLocationPermission()) {
      return ExecutionResult.RequiresPermission(
        permission = Manifest.permission.ACCESS_COARSE_LOCATION,
        rationale = if (isArabic) "يلزم إذن الموقع الجغرافي لجلب بيانات الطقس الفعلية لمنطقتك." else "Location permission is required to fetch real weather conditions for your area."
      )
    }
    val w = weatherProvider.fetchWeather()
    if (!w.isAvailable) {
      return ExecutionResult.Unavailable(
        reason = w.statusMessage ?: if (isArabic) "بيانات الطقس غير متوفرة حالياً." else "Weather information is temporarily unavailable.",
        visualState = CoreVisualState.RESPONDING
      )
    }

    val speech = when (queryType) {
      WeatherQueryType.CURRENT -> formatCurrentWeather(w, isArabic)
      WeatherQueryType.HOURLY_EVENING -> formatEveningWeather(w, isArabic)
      WeatherQueryType.RAIN_SOON -> formatRainSoon(w, isArabic)
      WeatherQueryType.WIND_TOMORROW -> formatWindTomorrow(w, isArabic)
      WeatherQueryType.OUTDOOR_SUITABILITY -> formatOutdoorSuitability(w, isArabic)
      WeatherQueryType.COMPARE_TOMORROW -> formatCompareTomorrow(w, isArabic)
      WeatherQueryType.WEEK_RAIN -> formatWeekRain(w, isArabic)
    }
    return ExecutionResult.Success(
      speech = speech,
      actionTaken = "Queried Weather (${queryType.name})",
      visualState = CoreVisualState.RESPONDING
    )
  }

  private fun formatCurrentWeather(w: WeatherSnapshot, isArabic: Boolean): String {
    val temp = w.temperatureCelsius?.let { "${it.toInt()}°" } ?: "--"
    val feels = w.apparentTemperatureCelsius?.let { " (المحسوسة ${it.toInt()}°)" } ?: ""
    val cond = w.condition ?: "معتدل"
    val maxMin = if (w.maxTempToday != null && w.minTempToday != null) {
      " العظمى ${w.maxTempToday.toInt()}° والصغرى ${w.minTempToday.toInt()}°."
    } else ""
    val rainProb = w.rainProbTodayMax?.let { " فرصة الأمطار $it%." } ?: ""
    val wind = if (w.windSpeedKmH != null) {
      val dir = w.windDirectionCompass?.let { " ($it)" } ?: ""
      " وسرعة الرياح ${w.windSpeedKmH.toInt()} كم/ساعة$dir."
    } else ""
    val humidity = w.humidityPercent?.let { " الرطوبة $it%." } ?: ""
    val uv = w.uvIndex?.let { " مؤشر UV: ${String.format(Locale.US, "%.1f", it)}." } ?: ""
    val cacheNote = if (w.isCached) " [آخر تحديث ${w.lastUpdatedFormatted}]." else ""

    return if (isArabic) {
      "الطقس حالياً: $cond وحرارة $temp$feels.$maxMin$rainProb$wind$humidity$uv$cacheNote"
    } else {
      val feelsEn = w.apparentTemperatureCelsius?.let { " (feels like ${it.toInt()}°C)" } ?: ""
      "Current weather: $cond at $temp°C$feelsEn. Rain probability ${w.rainProbTodayMax ?: 0}%. Wind: ${w.windSpeedKmH?.toInt() ?: 0} km/h."
    }
  }

  private fun formatEveningWeather(w: WeatherSnapshot, isArabic: Boolean): String {
    val eveningItems = w.hourlyForecast.filter { item ->
      val hour = item.hourLabel.substringBefore(":").toIntOrNull() ?: -1
      hour in 18..23
    }
    if (eveningItems.isEmpty()) {
      return if (isArabic) {
        "توقعات المساء تشير لدرجات حرارة حول ${w.minTempToday?.toInt() ?: w.temperatureCelsius?.toInt() ?: 20}°م."
      } else {
        "Evening forecast suggests temperatures around ${w.minTempToday?.toInt() ?: 20}°C."
      }
    }
    val avgTemp = eveningItems.map { it.temperature }.average().toInt()
    val maxRain = eveningItems.maxOfOrNull { it.precipitationProbability } ?: 0
    val mainCond = eveningItems.firstOrNull()?.condition ?: "صافٍ"
    return if (isArabic) {
      val rainNote = if (maxRain > 30) " مع احتمالية أمطار $maxRain%." else ""
      "توقعات هذا المساء: $mainCond، والحرارة حول $avgTemp°م$rainNote"
    } else {
      "This evening: $mainCond, temperature around $avgTemp°C with $maxRain% rain chance."
    }
  }

  private fun formatRainSoon(w: WeatherSnapshot, isArabic: Boolean): String {
    val nextHours = w.hourlyForecast.take(3)
    if (nextHours.isEmpty()) {
      val prob = w.rainProbTodayMax ?: 0
      return if (isArabic) {
        if (prob > 40) "احتمال هطول الأمطار اليوم مرتفع بنسبة $prob%." else "لا يتوقع هطول أمطار غزيرة قريباً ($prob%)."
      } else {
        "Rain probability for today is $prob%."
      }
    }
    val maxProb = nextHours.maxOfOrNull { it.precipitationProbability } ?: 0
    val totalPrecip = nextHours.sumOf { it.precipitationMm.toDouble() }.toFloat()
    return if (isArabic) {
      if (maxProb >= 40) {
        "نعم، يتوقع هطول أمطار خلال الساعتين القادمتين باحتمال $maxProb% (كمية متوقعة ~$totalPrecip ملم). خذ مظلة."
      } else {
        "لا أمطار متوقعة خلال الساعتين القادمتين (احتمال ضعيف $maxProb%)."
      }
    } else {
      if (maxProb >= 40) {
        "Yes, rain is likely in the next two hours with $maxProb% probability. Take an umbrella."
      } else {
        "No rain expected in the next couple of hours (probability $maxProb%)."
      }
    }
  }

  private fun formatWindTomorrow(w: WeatherSnapshot, isArabic: Boolean): String {
    val tom = w.dailyForecast.getOrNull(1)
    val maxWind = tom?.maxWindSpeedKmH ?: w.windSpeedTomorrowMax
    val gusts = tom?.maxWindGustsKmH
    return if (isArabic) {
      if (maxWind != null) {
        val gustText = if (gusts != null && gusts > maxWind) " وتصل الهبات إلى ${gusts.toInt()} كم/س." else ""
        "الرياح غداً ستكون بحدود ${maxWind.toInt()} كم/ساعة$gustText"
      } else {
        "بيانات الرياح ليوم غد غير متوفرة حالياً."
      }
    } else {
      "Wind tomorrow will reach around ${maxWind?.toInt() ?: 0} km/h."
    }
  }

  private fun formatOutdoorSuitability(w: WeatherSnapshot, isArabic: Boolean): String {
    val temp = w.temperatureCelsius ?: 25f
    val rainProb = w.rainProbTodayMax ?: 0
    val wind = w.windSpeedKmH ?: 10f
    val isRaining = w.condition?.contains("مطر") == true || rainProb > 50
    return if (isArabic) {
      val sb = StringBuilder()
      if (isRaining) {
        sb.append("الجو ماطر (فرصة الأمطار $rainProb%)، الأفضل اصطحاب مظلة.")
      } else if (wind > 35) {
        sb.append("الرياح قوية نوعاً ما (${wind.toInt()} كم/س).")
      } else if (temp > 38) {
        sb.append("الجو حار نسبياً (${temp.toInt()}°م)، احرص على شرب الماء.")
      } else {
        sb.append("الأجواء ملائمة للخروج، ${w.condition ?: "معتدل"} وحرارة ${temp.toInt()}°م.")
      }
      sb.toString()
    } else {
      if (isRaining) "Weather is rainy ($rainProb% chance), take an umbrella."
      else "Conditions are favorable for going out (${temp.toInt()}°C, $wind km/h wind)."
    }
  }

  private fun formatCompareTomorrow(w: WeatherSnapshot, isArabic: Boolean): String {
    val maxToday = w.maxTempToday?.toInt()
    val minToday = w.minTempToday?.toInt()
    val maxTom = w.maxTempTomorrow?.toInt()
    val minTom = w.minTempTomorrow?.toInt()
    val condToday = w.condition ?: "معتدل"
    val condTom = w.conditionTomorrow ?: "معتدل"
    val rainTom = w.rainProbTomorrowMax ?: 0
    return if (isArabic) {
      if (maxToday != null && maxTom != null) {
        "اليوم: $condToday (العظمى $maxToday° / الصغرى $minToday°). غداً: $condTom (العظمى $maxTom° / الصغرى $minTom°) مع فرصة أمطار $rainTom%."
      } else {
        "اليوم $condToday وغداً $condTom باحتمال أمطار $rainTom%."
      }
    } else {
      "Today: $condToday ($maxToday°C / $minToday°C). Tomorrow: $condTom ($maxTom°C / $minTom°C)."
    }
  }

  private fun formatWeekRain(w: WeatherSnapshot, isArabic: Boolean): String {
    val rainDays = w.dailyForecast.filter { it.precipitationProbabilityMax >= 30 }
    return if (isArabic) {
      if (rainDays.isNotEmpty()) {
        val details = rainDays.joinToString("، ") { "${it.dayLabel} (${it.precipitationProbabilityMax}%)" }
        "يتوقع هطول أمطار في أيام: $details."
      } else {
        "لا توجد فرص أمطار معتبرة خلال الأيام السبعة القادمة."
      }
    } else {
      if (rainDays.isNotEmpty()) {
        "Rain expected on: " + rainDays.joinToString(", ") { "${it.dayLabel} (${it.precipitationProbabilityMax}%)" }
      } else {
        "No significant rain expected this week."
      }
    }
  }
}
