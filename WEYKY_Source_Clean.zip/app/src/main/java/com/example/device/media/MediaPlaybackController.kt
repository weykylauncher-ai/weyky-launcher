package com.example.device.media

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.util.Log
import android.view.KeyEvent
import com.example.device.notifications.NotificationRepository
import com.example.device.notifications.WeykyNotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class ActiveMediaMetadata(
  val title: String? = null,
  val artist: String? = null,
  val album: String? = null,
  val isPlaying: Boolean = false,
  val packageName: String? = null
)

sealed interface MediaControlResult {
  data class Success(val message: String, val isPlaying: Boolean) : MediaControlResult
  object NoActiveSession : MediaControlResult
  data class Error(val message: String) : MediaControlResult
}

class MediaPlaybackController(private val context: Context) {
  private val audioManager =
    context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
  private val mediaSessionManager =
    context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager

  private val _mediaState = MutableStateFlow(ActiveMediaMetadata())
  val mediaState: StateFlow<ActiveMediaMetadata> = _mediaState.asStateFlow()

  private var activeController: MediaController? = null

  private val controllerCallback = object : MediaController.Callback() {
    override fun onPlaybackStateChanged(state: PlaybackState?) {
      updateMediaState()
    }
    override fun onMetadataChanged(metadata: MediaMetadata?) {
      updateMediaState()
    }
    override fun onSessionDestroyed() {
      activeController = null
      _mediaState.value = ActiveMediaMetadata()
      Log.d("WEYKY_MEDIA", "Session destroyed")
    }
  }

  fun updateMediaState() {
    val controller = getActiveMediaController()
    if (controller != null) {
      val state = controller.playbackState?.state
      val isPlaying = state == PlaybackState.STATE_PLAYING
      val meta = controller.metadata
      val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
        ?: controller.metadata?.description?.title?.toString()
      val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
        ?: controller.metadata?.description?.subtitle?.toString()
      val album = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM)

      _mediaState.value = ActiveMediaMetadata(
        title = title,
        artist = artist,
        album = album,
        isPlaying = isPlaying,
        packageName = controller.packageName
      )
      Log.d("WEYKY_MEDIA", "playing=$isPlaying, title=$title, artist=$artist")
    } else {
      val isPlaying = audioManager?.isMusicActive == true
      val mediaNotif = NotificationRepository.activeNotifications.value.firstOrNull { item ->
        val pkg = item.packageName.lowercase(Locale.ROOT)
        item.category == android.app.Notification.CATEGORY_TRANSPORT ||
          pkg.contains("spotify") || pkg.contains("music") || pkg.contains("soundcloud") ||
          pkg.contains("anghami") || pkg.contains("deezer") || pkg.contains("youtube") ||
          pkg.contains("vlc") || pkg.contains("audio") || pkg.contains("player")
      }
      _mediaState.value = ActiveMediaMetadata(
        title = mediaNotif?.title?.ifBlank { null },
        artist = mediaNotif?.text?.ifBlank { null },
        isPlaying = isPlaying,
        packageName = mediaNotif?.packageName
      )
    }
  }

  fun isMediaActive(): Boolean {
    val musicActive = audioManager?.isMusicActive == true
    if (musicActive) return true
    val active = getActiveMediaController()
    return active?.playbackState?.state == PlaybackState.STATE_PLAYING
  }

  fun getActiveMediaController(): MediaController? {
    if (mediaSessionManager == null) return null
    try {
      val notificationListenerComponent = ComponentName(
        context,
        WeykyNotificationListenerService::class.java
      )
      val sessions = mediaSessionManager.getActiveSessions(notificationListenerComponent)
      if (!sessions.isNullOrEmpty()) {
        val found = sessions.firstOrNull { controller ->
          val state = controller.playbackState?.state
          state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_PAUSED
        } ?: sessions.firstOrNull()
        if (found != null && found != activeController) {
          try {
            activeController?.unregisterCallback(controllerCallback)
          } catch (_: Exception) {}
          activeController = found
          try {
            found.registerCallback(controllerCallback)
          } catch (_: Exception) {}
        }
        return found
      }
    } catch (_: SecurityException) {
    } catch (_: Exception) {}
    return null
  }

  fun play(): MediaControlResult {
    val isArabic = Locale.getDefault().language.startsWith("ar")
    val controller = getActiveMediaController()
    if (controller != null) {
      return try {
        controller.transportControls.play()
        updateMediaState()
        val title = controller.metadata?.description?.title?.toString()
        val label = if (!title.isNullOrBlank()) {
          if (isArabic) "تم تشغيل $title." else "Playing $title."
        } else {
          if (isArabic) "تم استئناف التشغيل." else "Resumed playback."
        }
        MediaControlResult.Success(label, isPlaying = true)
      } catch (e: Exception) {
        MediaControlResult.Error(if (isArabic) "خطأ في التشغيل: ${e.message}" else "Playback error: ${e.message}")
      }
    }

    val am = audioManager ?: return MediaControlResult.NoActiveSession
    if (am.isMusicActive) {
      val label = if (isArabic) "الموسيقى قيد التشغيل بالفعل." else "Music is already playing."
      return MediaControlResult.Success(label, isPlaying = true)
    }
    return try {
      val down = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY)
      val up = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY)
      am.dispatchMediaKeyEvent(down)
      am.dispatchMediaKeyEvent(up)
      val label = if (isArabic) "تم إرسال أمر التشغيل." else "Sent play command."
      MediaControlResult.Success(label, isPlaying = true)
    } catch (_: Exception) {
      MediaControlResult.NoActiveSession
    }
  }

  fun pause(): MediaControlResult {
    val isArabic = Locale.getDefault().language.startsWith("ar")
    val controller = getActiveMediaController()
    if (controller != null) {
      return try {
        controller.transportControls.pause()
        updateMediaState()
        val label = if (isArabic) "تم إيقاف الموسيقى مؤقتاً." else "Music paused."
        MediaControlResult.Success(label, isPlaying = false)
      } catch (e: Exception) {
        MediaControlResult.Error(if (isArabic) "خطأ في الإيقاف: ${e.message}" else "Pause error: ${e.message}")
      }
    }

    val am = audioManager ?: return MediaControlResult.NoActiveSession
    if (!am.isMusicActive) {
      return MediaControlResult.NoActiveSession
    }
    return try {
      val down = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE)
      val up = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE)
      am.dispatchMediaKeyEvent(down)
      am.dispatchMediaKeyEvent(up)
      val label = if (isArabic) "تم إيقاف الموسيقى مؤقتاً." else "Music paused."
      MediaControlResult.Success(label, isPlaying = false)
    } catch (_: Exception) {
      MediaControlResult.NoActiveSession
    }
  }

  fun skipToNext(): MediaControlResult {
    val isArabic = Locale.getDefault().language.startsWith("ar")
    val controller = getActiveMediaController()
    if (controller != null) {
      return try {
        controller.transportControls.skipToNext()
        updateMediaState()
        val label = if (isArabic) "تم الانتقال للمقطع التالي." else "Skipped to next track."
        MediaControlResult.Success(label, isPlaying = true)
      } catch (e: Exception) {
        MediaControlResult.Error(if (isArabic) "خطأ في التخطي: ${e.message}" else "Skip error: ${e.message}")
      }
    }

    val am = audioManager ?: return MediaControlResult.NoActiveSession
    if (!am.isMusicActive) {
      return MediaControlResult.NoActiveSession
    }
    return try {
      val down = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT)
      val up = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_NEXT)
      am.dispatchMediaKeyEvent(down)
      am.dispatchMediaKeyEvent(up)
      val label = if (isArabic) "تم الانتقال للمقطع التالي." else "Skipped to next song."
      MediaControlResult.Success(label, isPlaying = true)
    } catch (_: Exception) {
      MediaControlResult.NoActiveSession
    }
  }

  fun skipToPrevious(): MediaControlResult {
    val isArabic = Locale.getDefault().language.startsWith("ar")
    val controller = getActiveMediaController()
    if (controller != null) {
      return try {
        controller.transportControls.skipToPrevious()
        updateMediaState()
        val label = if (isArabic) "تم الرجوع للمقطع السابق." else "Skipped to previous track."
        MediaControlResult.Success(label, isPlaying = true)
      } catch (e: Exception) {
        MediaControlResult.Error(if (isArabic) "خطأ في الرجوع: ${e.message}" else "Previous error: ${e.message}")
      }
    }

    val am = audioManager ?: return MediaControlResult.NoActiveSession
    if (!am.isMusicActive) {
      return MediaControlResult.NoActiveSession
    }
    return try {
      val down = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
      val up = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
      am.dispatchMediaKeyEvent(down)
      am.dispatchMediaKeyEvent(up)
      val label = if (isArabic) "تم الرجوع للمقطع السابق." else "Skipped to previous song."
      MediaControlResult.Success(label, isPlaying = true)
    } catch (_: Exception) {
      MediaControlResult.NoActiveSession
    }
  }

  fun toggle(): MediaControlResult {
    val isPlaying = isMediaActive()
    return if (isPlaying) pause() else play()
  }
}
